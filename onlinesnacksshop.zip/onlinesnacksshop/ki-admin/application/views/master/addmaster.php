<style type="text/css">
.btn1
{
	height: 40px;
	width: 180px;
	
}
td
{
	padding:10px;
}
</style>

<div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
			Add Admin::
          
          </h1>
          <ol class="breadcrumb">
           <li><?php echo anchor('','<i class="fa fa-dashboard"></i> Dashbord'); ?></li>
              <li><?php echo anchor('master/','<i class="fa fa-th fa-th-list"></i>Admin List'); ?></li>
            
            <li class="active">Add Admin</li>
          </ol>
        </section>

        <!-- Main content -->
        <section class="content">
          <div class="row">
            <div class="col-xs-12">
              <!-- /.box -->

              <div class="box">
                <div class="box-header">
								<h4><?php echo anchor('master/',"<i class='fa fa-fw fa-arrow-left'></i>&nbsp;Back To Admin List",'class="btn btn-primary"'); ?></h4>
                </div><!-- /.box-header -->
               
            
			
		<span>&nbsp;</span>
        <span>&nbsp;</span>
               
                
                  <?php
			if($this->session->userdata('imgerr'))
			{
				?>
                 <div class="alert alert-danger alert-dismissable">
                 <h4><i class="icon fa fa-ban"></i>Alert!</h4>
				    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                  <span style="font-size:16px;"><?php echo $this->session->userdata('imgerr'); ?>
                  </span>
                  </div>
                  
				<?php
				$this->session->unset_userdata('imgerr');
				
			}
			?>
                  
                <div class="box-body">
  				<?php echo form_open_multipart('master/addnew'); ?>
				<table > 
				<tr>
					<td>
								<label>First Name:- <span style="color:#f00">(Required Field)</span></label>
					</td>
					<td>

									<input type="text" required="required" class="form-control" value="<?php echo $this->input->post('master_fname'); ?>" name="master_fname" />
                               
                      <?php
                                      if(form_error('master_fname'))
					{
						?>
                         <div class="alert alert-danger ">
				    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                  <span style="font-size:16px;"><?php echo  form_error('master_fname'); ?>
                  </span>
                  </div>
                 
                        <?php 
							
					}
					?>
                   
					</td>
				</tr>
				<tr>
                <tr>
					<td>
								<label>Last Name:- <span style="color:#f00">(Required Field)</span></label>
					</td>
					<td>

									<input type="text" required="required" class="form-control" value="<?php echo $this->input->post('master_lname'); ?>" name="master_lname" />
                               
                      <?php
                                      if(form_error('master_lname'))
					{
						?>
                         <div class="alert alert-danger ">
				    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                  <span style="font-size:16px;"><?php echo form_error('master_lname'); ?>
                  </span>
                  </div>
                 
                        <?php 
							
					}
					?>
                   
					</td>
				</tr>
				<tr>
					<td>
								<label>Username:- <span style="color:#f00">(Required Field)</span></label>
					</td>
					<td>

									<input type="text" required="required" class="form-control" value="<?php echo $this->input->post('master_username'); ?>" name="master_username" />
                                        
                      <?php
                                      if(form_error('master_username'))
					{
						?>
                         <div class="alert alert-danger ">
				    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                  <span style="font-size:16px;"><?php echo form_error('master_username'); ?>
                  </span>
                  </div>
                 
                        <?php 
							
					}
					?>
                   
					</td>
				</tr>
                <tr>
					<td>
								<label>Email:- <span style="color:#f00">(Required Field)</span></label>
					</td>
					<td>

									<input type="text" required="required" class="form-control" value="<?php echo $this->input->post('master_email'); ?>" name="master_email" />
                                                       
                      <?php
                       if(form_error('master_email'))
					{
						?>
                         <div class="alert alert-danger ">
				    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                  <span style="font-size:16px;"><?php echo form_error('master_email'); ?>
                  </span>
                  </div>
                 
                        <?php 
							
					}
					?>
                   
					</td>
				</tr>

				<tr>
					<td>
								<label>Password:- <span style="color:#f00">(Required Field)</span></label>
					</td>
					<td>

									<input type="text" required="required" class="form-control" value="<?php echo $this->input->post('master_password'); ?>" name="master_password" />
                                           
                      <?php
                                      if(form_error('master_password'))
					{
						?>
                         <div class="alert alert-danger ">
				    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                  <span style="font-size:16px;"><?php echo form_error('master_password'); ?>
                  </span>
                  </div>
                 
                        <?php 
							
					}
					?>
                   
					</td>
				</tr>
				</table>		
							
							
							<input type="submit" class="btn1 bg-purple margin" value="Add" />

					<?php echo form_close(); ?>
                
                </div><!-- /.box-body -->
              </div><!-- /.box -->
            </div><!-- /.col -->
          </div><!-- /.row -->
        </section><!-- /.content -->
      </div>
					<div>
						
