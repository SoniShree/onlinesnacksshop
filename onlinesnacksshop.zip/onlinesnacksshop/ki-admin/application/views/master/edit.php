<style type="text/css">	
.btn
{
	height: 40px;
	width: 180px;
	
}
td
{
	padding:5px;
}
</style>
<div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
			Edit Admin::
          
          </h1>
          <ol class="breadcrumb">
         <li><?php echo anchor('','<i class="fa fa-dashboard"></i> Dashbord'); ?></li>
              <li><?php echo anchor('master','<i class="fa fa-th fa-th-list"></i>Admin List'); ?></li>
            <li class="active">Edit Admin </li>
          </ol>
        </section>

        <!-- Main content -->
        <section class="content">
          <div class="row">
            <div class="col-xs-12">
              <!-- /.box -->

              <div class="box">
                <div class="box-header">
				<h4><?php echo anchor('master',"<i class='fa fa-fw fa-arrow-left'></i>&nbsp;Back To Admin List",'class="btn btn-primary"'); ?></h4>
                </div><!-- /.box-header -->
               
            
			
		<span>&nbsp;</span>
        <span>&nbsp;</span>
               
                
                  <?php
				  if(validation_errors())
					{
						?>
                         <div class="alert alert-danger ">
                         <h4><i class="icon fa fa-ban"></i>Alert!</h4>
                         
				    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                  <span style="font-size:16px;"><?php echo validation_errors(); ?>
                  </span>
                  </div>
                 
                        <?php 	
					}
					?>
			    <div class="box-body">
<?php echo form_open('master/edit/'."$master_item->id"); ?>
						
						<?php echo form_hidden('id',$master_item->id); ?>
					<table > 
				<tr>
					<td>
								<label>First Name:- <span style="color:#f00">(Required Field)</span></label>
					</td>
					<td>

									<input type="text" required="required" class="form-control" value="<?php echo $master_item->first_name;?>" name="master_fname" />
                               
                      <?php
                                      if(form_error('master_fname'))
					{
						?>
                         <div class="alert alert-danger ">
				    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                  <span style="font-size:16px;"><?php echo  form_error('master_fname'); ?>
                  </span>
                  </div>
                 
                        <?php 
							
					}
					?>
                   
					</td>
				</tr>
				<tr>
                <tr>
					<td>
								<label>Last Name:- <span style="color:#f00">(Required Field)</span></label>
					</td>
					<td>

									<input type="text" required="required" class="form-control" value="<?php echo $master_item->last_name; ?>" name="master_lname" />
                               
                      <?php
                                      if(form_error('master_lname'))
					{
						?>
                         <div class="alert alert-danger ">
				    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                  <span style="font-size:16px;"><?php echo form_error('master_lname'); ?>
                  </span>
                  </div>
                 
                        <?php 
							
					}
					?>
                   
					</td>
				</tr>
				<tr>
					<td>
								<label>Username:- <span style="color:#f00">(Required Field)</span></label>
					</td>
					<td>

									<input type="text" required="required" class="form-control" value="<?php echo $master_item->username; ?>" name="master_username" />
                                        
                      <?php
                                      if(form_error('master_username'))
					{
						?>
                         <div class="alert alert-danger ">
				    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                  <span style="font-size:16px;"><?php echo form_error('master_username'); ?>
                  </span>
                  </div>
                 
                        <?php 
							
					}
					?>
                   
					</td>
				</tr>
                <tr>
					<td>
								<label>Email:- <span style="color:#f00">(Required Field)</span></label>
					</td>
					<td>

									<input type="text" required="required" class="form-control" value="<?php echo $master_item->email; ?>" name="master_email" />
                                                       
                      <?php
                       if(form_error('master_email'))
					{
						?>
                         <div class="alert alert-danger ">
				    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                  <span style="font-size:16px;"><?php echo form_error('master_email'); ?>
                  </span>
                  </div>
                 
                        <?php 
							
					}
					?>
                   
					</td>
				</tr>

				<tr>
					<td>
								<label>Password:- <span style="color:#f00">(Required Field)</span></label>
					</td>
					<td>

									<input type="text" required="required" class="form-control" value="<?php echo $master_item->password; ?>" name="master_password"  size="32"/>
                                           
                      <?php
                                      if(form_error('master_password'))
					{
						?>
                         <div class="alert alert-danger ">
				    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                  <span style="font-size:16px;"><?php echo form_error('master_password'); ?>
                  </span>
                  </div>
                 
                        <?php 
							
					}
					?>
                   
					</td>
				</tr>
				</table>	
							
							
					<input type="submit" class="btn bg-purple margin" value="Edit" />
					<?php echo form_close(); ?>
                
                </div><!-- /.box-body -->
              </div><!-- /.box -->
            </div><!-- /.col -->
          </div><!-- /.row -->
        </section><!-- /.content -->
   </div>
