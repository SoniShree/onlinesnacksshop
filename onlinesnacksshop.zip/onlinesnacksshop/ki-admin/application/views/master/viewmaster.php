<style>
tbl
{
	width:250px;
	float:left;
}
tbl1
{
		width:250px;
	float:left;
}
td
{
	padding:10px;
}
</style>


    
<div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
			Admin Section::
          
          </h1>
          <ol class="breadcrumb">
          <li><?php echo anchor('','<i class="fa fa-dashboard"></i> Dashbord'); ?></li>
              <li><?php echo anchor('master','<i class="fa fa-th fa-th-list"></i>Admin'); ?></li>
            <li class="active">master List</li>
          </ol>
        </section>

        <!-- Main content -->
        <section class="content">
          <div class="row">
            <div class="col-xs-12">
              <!-- /.box -->

              <div class="box">
                <div class="box-header">
					<h4><?php echo anchor('master/',"<i class='fa fa-fw fa-arrow-left'></i>&nbsp;Back To Admin List",'class="btn btn-primary"'); ?></h4>
                </div><!-- /.box-header -->
               
                 
                <div class="box-body">
						
			<div id="tbl1">

					<table cellspacing="40">
					<tr>
							<td><span>Admin Id :-</span></td>
							<td><span><?php echo $master_item->id ?></span></td>
						</tr>
						<tr>
							<td><span>First Name :-</span></td>
							<td><span><?php echo $master_item->first_name ?></span></td>
						</tr>
                        <tr>
							<td><span>Last Name :-</span></td>
							<td><span><?php echo $master_item->last_name ?></span></td>
						</tr>
						<tr>
							<td><span>Username :-</span></td>
							<td><span><?php echo $master_item->username ?></span></td>
						</tr>
						<tr>
							<td><span>Email  :-</span></td>
							<td><span><?php echo $master_item->email ?></span></td>
						</tr>
						<tr>
							<td><span>Password :-</span></td>
							<td><span><?php echo $master_item->password ?></span></td>
						</tr>
						<tr>
							<td><span>Last Login :-</span></td>
							<td><span><?php echo $master_item->last_login ?></span></td>
						</tr>
					</table>	
</div>                  
                </div><!-- /.box-body -->
              </div><!-- /.box -->
            </div><!-- /.col -->
          </div><!-- /.row -->
        </section><!-- /.content -->
      </div>