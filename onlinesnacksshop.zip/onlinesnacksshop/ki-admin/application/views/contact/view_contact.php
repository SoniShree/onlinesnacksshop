<style>
.left
{
	
float: left;
}
</style>

<div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
			Edit News::
          
          </h1>
          <ol class="breadcrumb">
           <li><?php echo anchor('','<i class="fa fa-dashboard"></i> Dashbord'); ?></li>
              <li class="active"><?php echo anchor('contact/contact','<i class="fa fa-th fa-th-list"></i>Contact'); ?></li>
           
          </ol>
        </section>

        <!-- Main content -->
        <section class="content">
          <div class="row">
            <div class="col-xs-12">
              <!-- /.box -->

              <div class="box">
                <div class="box-header">
				<h4><?php echo anchor('contact/contact/',"<i class='fa fa-fw fa-arrow-left'></i>&nbsp;Back To Users",'class="btn btn-primary left"'); ?>
                
                                    <?php $id=$result->contact_id; echo form_open("contact/contact/changestatus/$id"); ?>
								<?php echo nbs(8); ?><label>Status: </label>
								<select name="status" required="required"  style="width:200px;font-size:14px;height:40px;" >
								<option value="0" <?php if($result->status==0) { echo "selected"; } ?>>Disabled</option><option  value="1" <?php if($result->status==1) { echo "selected"; } ?>>Enabled</option></select>
                               <?php echo nbs(1); ?>
							<input type="submit" class="btn" value="Edit" />
					<?php form_close() ?>
                </h4>
                </div><!-- /.box-header -->
               
            
			
	
      
                       
                <div class="box-body">
						 

	
								
                    <table cellspacing="40">
                            <tr>
                                <td><span>First Name :-&nbsp; </span></td>
                                <td><span><?php echo $result->contact_fname ?></span></td>
                            </tr>
                            <tr>
                                <td><span>First Name :-&nbsp; </span></td>
                                <td><span><?php echo $result->contact_lname ?></span></td>
                            </tr>
                            <tr>
                                <td><span>Mobile No :-&nbsp; </span></td>
                                <td><span><?php echo $result->contact_mobile ?></span></td>
                            </tr>
                           
                            <tr>
                                <td><span>Email :-&nbsp; </span></td>
                                <td><span><?php echo $result->contact_email ?></span></td>
                            </tr>
                            <tr>
                               	<td valign="top">Comment :-</td>
                                <td><span><?php echo $result->contact_message ?></span></td>
                            </tr>
                            <tr>
                                <td><span>Created :-&nbsp; </span></td>
                                <td><span><?php echo $result->created ?></span></td>
                            </tr>
                            
                        </table>
						                
                </div><!-- /.box-body -->
              </div><!-- /.box -->
            </div><!-- /.col -->
          </div><!-- /.row -->
        </section><!-- /.content -->
   </div>
                            