<style>
tbl
{
	width:250px;
	float:left;
}
tbl1
{
		width:250px;
	float:left;
}
</style>
<div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
			News Section::
          
          </h1>
          <ol class="breadcrumb">
            <li><?php echo anchor('','<i class="fa fa-dashboard"></i> Dashbord'); ?></li>
              <li><?php echo anchor('cms/cms','<i class="fa fa-files-o"></i>CMS'); ?></li>
            <li class="active">Page View</li>
          </ol>
        </section>

        <!-- Main content -->
        <section class="content">
          <div class="row">
            <div class="col-xs-12">
              <!-- /.box -->

              <div class="box">
                <div class="box-header">
				<h4><?php echo anchor('cms/cms/','<span><i class="fa fa-arrow-left"></i>&nbsp;Back to CMS</span>','class="btn btn-primary"'); ?></h4>
                </div><!-- /.box-header -->
               
                 
                <div class="box-body">
						

					<table>
						<tr>
							<td><span>Title :-</span></td>
							<td><span><?php echo $cms_item->cms_title ?></span></td>
						</tr>
						<tr>
								<td valign="top">Content :-</td>
							<td><span><?php echo $cms_item->content ?></span></td>
						</tr>
                        <tr>
								<td valign="top">Testimonial :-</td>
							<td><span><?php echo $cms_item->testimonial ?></span></td>
						</tr>
						<tr>
							<td><span>Meta Keywords:-</span></td>
							<td><span><?php echo $cms_item->meta_keywords ?></span></td>
						</tr>
						<tr>
							<td><span>Status :-</span></td>
							<td><span><?php if($cms_item->cms_status =="0") { echo "Disabled"; } else { echo "Enabled"; } ?></span></td>
						</tr>
						<tr>
							<td><span>Meta Description:-</span></td>
							<td><span><?php echo $cms_item->meta_desc ?></span></td>
						</tr>
						<tr>
							<td><span>Created:-</span></td>
							<td><span><?php echo $cms_item->cms_created ?></span></td>
						</tr>
						

					</table>	
                </div><!-- /.box-body -->
              </div><!-- /.box -->
            </div><!-- /.col -->
          </div><!-- /.row -->
        </section><!-- /.content -->
      </div>

