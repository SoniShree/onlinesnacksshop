 <!--redactor -->
<style type="text/css">
input[type='text']    
{
	height: 35px;
	width: 180px;
	
}
.textarea    
{
	height: 65px;
	width: 180px;

}
.upload    
{
	height: 35px;
	width: 200px;
	
}
.drpdwn
{
	height: 35px;
	width: 180px;
	
}
.btn
{
	height: 40px;
	width: 180px;
	
}
td
{
	padding:5px;
}
</style>
<div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
			Add Page::
          
          </h1>
          <ol class="breadcrumb">
            <li><?php echo anchor('','<i class="fa fa-dashboard"></i> Dashbord'); ?></li>
              <li><?php echo anchor('cms/cms','<i class="fa fa-files-o"></i>CMS'); ?></li>
            <li class="active">Add Page</li>
          </ol>
        </section>

        <!-- Main content -->
        <section class="content">
          <div class="row">
            <div class="col-xs-12">
              <!-- /.box -->

              <div class="box">
                <div class="box-header">
				<h4><?php echo anchor('cms/cms/','<span><i class="fa fa-arrow-left"></i>&nbsp;Back To CMS</span>','class="btn btn-primary"'); ?></h4>
                </div><!-- /.box-header -->
               
            
			
		<span>&nbsp;</span>
        <span>&nbsp;</span>
               
                
                  <?php
				 
			if($this->session->userdata('imgerr'))
			{
				?>
                 <div class="alert alert-danger alert-dismissable">
                 <h4><i class="icon fa fa-ban"></i>Alert!</h4>
				    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                  <span style="font-size:16px;"><?php echo $this->session->userdata('imgerr'); ?>
                  </span>
                  </div>
                  
				<?php
				$this->session->unset_userdata('imgerr');
				
			}
			?>
                  
                <div class="box-body">
				<?php echo form_open_multipart('cms/cms/addnew'); ?>
				<table cellpadding="5">
				<tr>
					<td valign="top">
								<label>Title <span style="color:#f00">(Required Field)</span></label>
					</td>
					<td>

									<input type="text" value="<?php echo $this->input->post('cms_title'); ?>" name="cms_title" class="form-control" Required />									 <?php if(form_error('cms_title'))
					{
						?> 
                                     <div class="alert alert-danger ">
				    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                  <span style="font-size:14px;"><?php  echo form_error('cms_title'); ?>
                  </span>
                  </div>
                                  <?php } ?>
					</td>
				</tr>
                <tr>
					<td valign="top">
								<label>Url Key<span style="color:#f00">(Unique Field)</span></label>
					</td>
					<td>
								<input type="text" value="<?php echo $this->input->post('url_key'); ?>" name="url_key" class="form-control" Required />
								 <?php if(form_error('url_key'))
					{
						?> 
                                     <div class="alert alert-danger ">
				    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                  <span style="font-size:14px;"><?php  echo form_error('url_key'); ?>
                  </span>
                  </div>
                                  <?php } ?>
					</td>
				</tr>
                
				<tr>
					<td valign="top">
								<label>Status <span style="color:#f00">(Required Field)</span></label>
					</td>
					<td>
					
					<?php $options = array(
								                  '1'    => 'Enable',
								                  '0'  => 'Disable',
								                  ); ?>
								<?php echo form_dropdown('cms_status',$options, '1',' class="drpdwn form-control"'); ?>
					</td>
				</tr>
				<tr>
					<td valign="top">
						<label >Meta keyword <span style="color:#f00">(Required Field)</span></label>


					</td>
					<td>
					<textarea class="redactor form-control" name="meta_keywords" rows="10" cols="60" ><?php echo $this->input->post('meta_keywords'); ?></textarea>
                    <?php if(form_error('meta_keywords'))
					{
						?> 
                                     <div class="alert alert-danger ">
				    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                  <span style="font-size:14px;"><?php  echo form_error('meta_keywords'); ?>
                  </span>
                  </div>
                                  <?php } ?>
					</td>
				</tr>
                <tr>
					<td valign="top">
									<label >Meta Description <span style="color:#f00">(Required Field)</span></label>


					</td>
					<td>
									<textarea class="redactor form-control" name="meta_desc" rows="10" cols="60" ><?php echo $this->input->post('meta_desc'); ?></textarea>
                                     <?php if(form_error('meta_desc'))
					{
						?> 
                                     <div class="alert alert-danger ">
				    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                  <span style="font-size:14px;"><?php  echo form_error('meta_desc'); ?>
                  </span>
                  </div>
                                  <?php } ?>
					</td>
				</tr>
              
				<tr>
					<td valign="top">
      									<label >Content <span style="color:#f00">(Required Field)</span></label>


					</td>
					<td>
							<textarea class="form-control redactor" name="cms_desc" rows="40" cols="60" ><?php echo $this->input->post('cms_desc'); ?></textarea>
                            
                                     <?php if(form_error('cms_desc'))
					{
						?> 
                                     <div class="alert alert-danger ">
				    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                  <span style="font-size:14px;"><?php  echo form_error('cms_desc'); ?>
                  </span>
                  </div>
                                  <?php } ?>
					</td>
				</tr>
				</table>		
							
							
							<input type="submit" class="btn bg-purple margin" value="Add" />

					<?php echo form_close(); ?>
                </div><!-- /.box-body -->
              </div><!-- /.box -->
            </div><!-- /.col -->
          </div><!-- /.row -->
        </section><!-- /.content -->
      </div>
