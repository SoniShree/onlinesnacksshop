
    
<div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
			CMS Section::
          
          </h1>
          <ol class="breadcrumb">
         
				<li><?php echo anchor('','<i class="fa fa-dashboard"></i> Dashbord'); ?></li>
              <li class="active"><?php echo anchor('cms/cms','<i class="fa fa-files-o"></i>CMS'); ?></li>
                           
          </ol>
        </section>

        <!-- Main content -->
        <section class="content">
          <div class="row">
            <div class="col-xs-12">
              <!-- /.box -->

              <div class="box">
                <div class="box-header">
				<h4><?php echo anchor('cms/cms/addcms','<span><i class="fa fa-th fa-plus"></i>&nbsp;Add Page</span>','class="btn btn-primary"'); ?></h4>
                </div><!-- /.box-header -->
               
                   <?php
			if($this->session->userdata('insert'))
			{
				?>
				 <div class="alert alert-success alert-dismissable">
                                  <h4><i class="icon fa fa-check"></i>Alert!</h4>
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                   <span style="font-size:16px; color:#000"> &nbsp;&nbsp;<?php echo $this->session->userdata('insert'); ?>
                   </span></div>
				<?php
				$this->session->unset_userdata('insert');
			
			}
		    if($this->session->userdata('del'))
			{
				?>
								 <div class="alert alert-success alert-dismissable">
                                                  <h4><i class="icon fa fa-check"></i>Alert!</h4>
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                   <span style="font-size:16px; color:#000"><?php echo $this->session->userdata('del'); ?>
                   </span></div>
				<?php
				$this->session->unset_userdata('del');
				echo "</p>";
			}
			if($this->session->userdata('edit'))
			{
				?>
								 <div class="alert alert-success alert-dismissable">
                                                  <h4><i class="icon fa fa-check"></i>Alert!</h4>
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                   <span style="font-size:16px; color:#000"><?php echo $this->session->userdata('edit'); ?>
                   </span></div>
				<?php

				$this->session->unset_userdata('edit');
				echo "</p>";
			}
		
			
		?>
		<span>&nbsp;</span>
        <span>&nbsp;</span>
               
                
                  <?php
			if($this->session->userdata('notfound'))
			{
				?>
                 <div class="alert alert-danger alert-dismissable">
                   <h4><i class="icon fa fa-ban"></i>Alert!</h4>
				    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                  <span style="font-size:16px;"><?php echo $this->session->userdata('notfound'); ?>
                  </span>
                  </div>
                  
				<?php
				$this->session->unset_userdata('notfound');
				
			}
			?>
                  
                <div class="box-body">
                  <table id="example1" class="table table-bordered table-striped">
                    
                    	<thead>
						<tr >
							
								<th>Id</th>
								<th>Title</th>
								<th style="background:#fff;">Url Key</th>
								<th>Status</th>
								<th>Created</th>
								<th style="background:#fff;">Content Control</th>
							</tr>
						</thead>
                    <tbody>
							<?php foreach ($cms as $cms_item){ ?>
							<tr>
							
								<td><?php echo $cms_item->cms_id ?></td>
								<td><?php echo $cms_item->cms_title ?></td>
								<td><?php echo $cms_item->url_key ?></td>
								<td><?php if($cms_item->cms_status =="0"){ echo "<span style='color:red'>Disabled</span>"; } else { echo "<span style='color:green'>Enabled</span>"; }?></td>
								<td><?php echo $cms_item->cms_created ?></td>
                                <td><a href="<?php echo site_url('cms/cms/delete').'/'. $cms_item->cms_id ?>" onclick="return confirm('Are You Sure?');"><img src="<?php echo base_url('/images/delete.gif'); ?>" height="40" width="60" /></a>&nbsp;
								 

								 <a href="<?php echo site_url('cms/cms/edit').'/'. $cms_item->cms_id ?>"><img src="<?php echo base_url('/images/edit.gif'); ?>" height="40" width="60" /></a>&nbsp;</a>&nbsp;&nbsp;<a href="<?php echo site_url('cms/cms/view').'/'. $cms_item->cms_id ?>"><img src="<?php echo base_url('/images/view.gif'); ?>" height="40" width="60" /></a></td>
								
                         	</tr>
							<?php } ?>
                         </tbody>
                                     </table>
                </div><!-- /.box-body -->
              </div><!-- /.box -->
            </div><!-- /.col -->
          </div><!-- /.row -->
        </section><!-- /.content -->
      </div>
   