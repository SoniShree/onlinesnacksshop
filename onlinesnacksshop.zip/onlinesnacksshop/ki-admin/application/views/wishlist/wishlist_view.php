
    
    
<div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
			Wishlist Section::
          
          </h1>
          <ol class="breadcrumb">
             <li><?php echo anchor('','<i class="fa fa-dashboard"></i> Dashbord'); ?></li>
             <li class="active"><?php echo anchor('customer/customer','<i class="fa fa-th fa-th-large"></i>Customer'); ?></li>
              <li class="active"><?php echo anchor('wishlist/wishlist','<i class="fa fa-th fa-th-large"></i>wishlist'); ?></li>
           
          </ol>
        </section>

        <!-- Main content -->
        <section class="content">
          <div class="row">
            <div class="col-xs-12">
              <!-- /.box -->

              <div class="box">
                <div class="box-header">
                <h4><?php echo anchor('customer/customer/',"<i class='fa fa-fw fa-arrow-left'></i>&nbsp;Back To Customer",'class="btn btn-primary"'); ?></h4>
				 <?php //echo form_open('product/product/checkbox');?>
				<h4><?php //echo anchor('product/product/addproduct',"<span>Add Product</span>",'class="btn btn-primary"'); ?>
                 
                </h4>

                </div><!-- /.box-header -->
               
                   <?php
			if($this->session->userdata('insert'))
			{
				?>
				 <div class="alert alert-success alert-dismissable">
                                  <h4><i class="icon fa fa-check"></i>Alert!</h4>
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                   <span style="font-size:16px; color:#000"> &nbsp;&nbsp;<?php echo $this->session->userdata('insert'); ?>
                   </span></div>
				<?php
				$this->session->unset_userdata('insert');
			
			}
		    if($this->session->userdata('del'))
			{
				?>
								 <div class="alert alert-success alert-dismissable">
                                                  <h4><i class="icon fa fa-check"></i>Alert!</h4>
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                   <span style="font-size:16px; color:#000"><?php echo $this->session->userdata('del'); ?>
                   </span></div>
				<?php
				$this->session->unset_userdata('del');
				echo "</p>";
			}
			if($this->session->userdata('edit'))
			{
				?>
								 <div class="alert alert-success alert-dismissable">
                                                  <h4><i class="icon fa fa-check"></i>Alert!</h4>
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                   <span style="font-size:16px; color:#000"><?php echo $this->session->userdata('edit'); ?>
                   </span></div>
				<?php

				$this->session->unset_userdata('edit');
				echo "</p>";
			}
		
			
		?>
		<span>&nbsp;</span>
        <span>&nbsp;</span>
               
                
                  <?php
			if($this->session->userdata('notfound'))
			{
				?>
                 <div class="alert alert-danger alert-dismissable">
                   <h4><i class="icon fa fa-ban"></i>Alert!</h4>
				    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                  <span style="font-size:16px;"><?php echo $this->session->userdata('notfound'); ?>
                  </span>
                  </div>
                  
				<?php
				$this->session->unset_userdata('notfound');
				
			}
			?>
                  
                <div class="box-body">
                  <table id="example1" class="table table-bordered table-striped">
                    <thead >
                      <tr>
                      
                       <th >Wishlist Id</th>
                        <th>Customer Id</th>
                        <th style="background:#fff">Product Id</th>
						<th>Created</th>
                        <th>Updated</th>
                        <!--<th style="background:#fff">Content Control</th>-->
                      </tr>
                    </thead>
                    <tbody >
                      <?php 
					  if($wishlist)
					  {
					  	foreach ($wishlist as $wishlist){ ?>
							<tr >
					
								<td><?php echo $wishlist->wishlist_id ?></td>
								<td><?php echo $wishlist->customer_id ?></td>
                                <td><?php echo $wishlist->product_id ?></td>
								<td><?php echo $wishlist->created ?></td>
								<td><?php echo $wishlist->updated ?></td>
                                <!--<td align="center"><a href="<?php //echo site_url('wishlist/wishlist/view').'/'. $wishlist->wishlist_id ?>"><img src="<?php //echo base_url('/images/view.gif'); ?>" height="40" width="60" /></a></td>-->
							</tr>
							<?php } 
							
						}
						else
						{
							?>
							<td colspan="5" align="center">No Records Found...</td>
                            <?php
						}
							
							?>
                      
                    </tbody>
                   
                  </table>
                  </form>
                </div><!-- /.box-body -->
              </div><!-- /.box -->
            </div><!-- /.col -->
          </div><!-- /.row -->
        </section><!-- /.content -->
      </div>
     
