<style>
tbl
{
	width:250px;
	float:left;
}
tbl1
{
		width:250px;
	float:left;
}
</style>


    
<div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
			My Wishlist::
          
          </h1>
          <ol class="breadcrumb">
          <li><?php echo anchor('','<i class="fa fa-dashboard"></i> Dashbord'); ?></li>
              <li><?php echo anchor('customer/customer','<i class="fa fa-th fa-th-list"></i>Customer'); ?></li>
            <li class="active">My Wishlist</li>
          </ol>
        </section>

        <!-- Main content -->
        <section class="content">
          <div class="row">
            <div class="col-xs-12">
              <!-- /.box -->

              <div class="box">
                <div class="box-header">
					<h4><?php echo anchor('customer/customer/',"<i class='fa fa-fw fa-arrow-left'></i>&nbsp;Back To Customer",'class="btn btn-primary"'); ?></h4>
                </div><!-- /.box-header -->
               
                 
                <div class="box-body">
						<div id="tbl">
	
						
</div>
<div id="tbl1">

					<table cellspacing="40" id="example1" class="table table-bordered table-striped">
                    <thead>
                    <tr>
                    <th>Wishlist Id</th>
                    <th>Customer Id</th>
                    <th>Customer Name</th>
                    <th>Product Name</th>
                    <th style="background:#fff;">Product Image</th>
                    <th>Product Price</th>
                    
                    </tr>
                    </thead>
                    <?php 
					if($Wishlist_item)
					{
						foreach ($Wishlist_item as $Wishlist_item)
						{
						?>
                   <tbody>
						<tr>
							
							<td><span><?php echo $Wishlist_item->wishlist_id;?></span></td>
                            <td><span><?php echo $Wishlist_item->customer_id;?></span></td>
                            <td><span><?php echo $Wishlist_customer->customer_fname  ?></span></td>
                            <td><span><?php	 echo $Wishlist_item->product_title  ?></span></td>
                            
                            <td><img src="<?php echo base_url("../uploads/product_image/").'/'.$Wishlist_item->product_img ?>" height="50" width="70" alt="<?php echo $Wishlist_item->product_title; ?>" /></td>
                            
							<td><span><?php echo $Wishlist_item->product_price ?></span></td>
						</tr>
                     <?php    
                    }
					}?>
						
						</tbody>
					</table>	
</div>                  
                </div><!-- /.box-body -->
              </div><!-- /.box -->
            </div><!-- /.col -->
          </div><!-- /.row -->
        </section><!-- /.content -->
      </div>


