<style type="text/css">
	
input[type='password']    
{
	height: 35px;
	width: 180px;
	margin-left: 15px;
}
input[type='text']    
{
	height: 35px;
	width: 180px;
	margin-left: 15px;
}

td
{
	padding:5px;
}


</style>
<div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
			Change Password::
          
          </h1>
          <ol class="breadcrumb">
           <li><?php echo anchor('','<i class="fa fa-dashboard"></i> Dashbord'); ?></li>
              <li><?php echo anchor('website/setting','<i class="fa fa-gear"></i>Admin Setting'); ?></li>
        
            <li class="active">Change Password</li>
          </ol>
        </section>

        <!-- Main content -->
        <section class="content">
          <div class="row">
            <div class="col-xs-12">
              <!-- /.box -->

              <div class="box">
                <div class="box-header">
								<p align="right" style="padding-right:30px;"><?php echo anchor('website/settings',"&nbsp;Change Profile",'class="btn btn-primary"'); ?>&nbsp;&nbsp;
                                <?php echo anchor('website/chngpwd/',"&nbsp;Change Password",'class="btn btn-primary"'); ?></p>
                </div><!-- /.box-header -->
                  <?php
				  if(validation_errors())
					{
						?>
                         <div class="alert alert-danger ">
                         <h4><i class="icon fa fa-ban"></i>Alert!</h4>
                         
				    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                  <span style="font-size:16px;"><?php echo validation_errors(); ?>
                  </span>
                  </div>
                 
                        <?php 
							
					}
			if($this->session->userdata('err1pwd'))
			{
				?>
                 <div class="alert alert-danger alert-dismissable">
                 <h4><i class="icon fa fa-ban"></i>Alert!</h4>
				    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                  <span style="font-size:16px;"><?php echo $this->session->userdata('err1pwd'); ?>
                  </span>
                  </div>
                  
				<?php
				$this->session->unset_userdata('err1pwd');
				
			}
			if($this->session->userdata('cpwd'))
			{
				?>
								 <div class="alert alert-success alert-dismissable">
                                                  <h4><i class="icon fa fa-check"></i>Alert!</h4>
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                   <span style="font-size:16px; color:#000"><?php echo $this->session->userdata('cpwd'); ?>
                   </span></div>
				<?php

				$this->session->unset_userdata('cpwd');
			}
		
			?>
                  
        <div class="box-body">         
		</div>
        
       <div id="pwd">
				<table>
					<?php echo form_open('website/chngpwd');  ?>
					<?php echo form_hidden('id',$admin_profile->id); ?>
							<tr>
								<td>
								Current Password:
								</td>
								<td>
								<?php echo form_password('cpassword','','placeholder="Current Password" required class="form-control"'); ?>
								</td>
							</tr>
							<tr>
								<td>
								New Password:
								</td>
								<td>
								<?php echo form_password('npassword','','placeholder="New Password" required class="form-control"'); ?>
								</td>
							</tr>
							<tr>
								<td>
								Confirm Password:
								</td>
								<td>
								<?php echo form_password('cnpassword','','placeholder="Confirm Password" required class="form-control"'); ?>
                                </td>
							</tr>

							<tr>
								<td colspan="2">
								<?php echo form_submit('submit','Change Password','class="btn bg-purple margin"'); ?>
                                <?php echo form_close(); ?>
								</td>
							</tr>
							</table>					
						
                </div>
                </div><!-- /.box-body -->
              </div><!-- /.box -->
            </div><!-- /.col -->
          </div><!-- /.row -->
        </section><!-- /.content -->
      </div>						
