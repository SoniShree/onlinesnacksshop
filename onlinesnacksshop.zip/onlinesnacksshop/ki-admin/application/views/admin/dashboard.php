

      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
            Dashboard
            <small>Control panel</small>
          </h1>
          <ol class="breadcrumb">

            <li class="active"><i class="fa fa-dashboard"></i> &nbsp;Dashboard</li>
          </ol>
        </section>

        <!-- Main content -->
        <section class="content">
          <!-- Small boxes (Stat box) -->
          <div class="row">
            <!--<div class="col-lg-3 col-xs-6">
              <!-- small box -->
              <!--<div class="small-box bg-aqua">
                <div class="inner">
                  <h3>150</h3>
                  <p>New Orders</p>
                </div>
                <div class="icon">
                  <i class="ion ion-bag"></i>
                </div>
                <a href="#" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
              </div>
            </div><!-- ./col -->
            <div class="col-lg-3 col-xs-6">
              <!-- small box -->
              <div class="small-box bg-blue">
                <div class="inner">
                 <h3><?php echo $latestsub ?></h3>
                  <p>Email Subscribers</p>
                   <h4>Total Subscribers : &nbsp;<?php echo $total_sub; ?></h4>
                </div>
                <div class="icon">
                  <i class="fa fa-envelope"></i>
                </div>
                <?php echo anchor('newsletter','More info <i class="fa fa-arrow-circle-right"></i>','class="small-box-footer"'); ?>
              </div>
            </div><!-- ./col -->
            <div class="col-lg-3 col-xs-6">
              <!-- small box -->
              <div class="small-box bg-yellow">
                <div class="inner">
                  <h3><?php echo $latestusers ?></h3>
                  <p>User Registrations</p>
                  <h4>Total Customer : &nbsp;<?php echo $total; ?></h4>
                </div>
                <div class="icon">
                  <i class="ion ion-person-add"></i>
                </div>
                  <?php echo anchor('customer/customer','More info <i class="fa fa-arrow-circle-right"></i>','class="small-box-footer"'); ?>
                
              </div>
            </div><!-- ./col -->
            <div class="col-lg-3 col-xs-6">
              <!-- small box -->
              <div class="small-box bg-red" style="background-color: #DD4B39 !important;color:#fff !important;">
                <div class="inner">
                  <h3><?php echo $latestcontact;  ?></h3>
                  <p>Feedback</p>
                   <h4>Total Feedback : &nbsp;<?php echo $total_contact; ?></h4>
                </div>
                <div class="icon">
                  <i class="ion ion-pie-graph"></i>
                </div>
                <?php echo anchor('contact/contact','More info <i class="fa fa-arrow-circle-right"></i>','class="small-box-footer"'); ?>
                
              </div>
            </div><!-- ./col -->
            <div class="col-lg-3 col-xs-6">
              <!-- small box -->
              <div class="small-box bg-aqua">
                <div class="inner">
                  <h3><?php echo $latestorder; ?></h3>
                  <p>New Orders</p>
                  <h4>Total Orders : &nbsp;<?php echo $total_orders; ?></h4>
                </div>
                <div class="icon">
                  <i class="ion ion-bag"></i>
                </div>
                   <?php echo anchor('sales/orders','More info <i class="fa fa-arrow-circle-right"></i>','class="small-box-footer"'); ?>
              </div>
            </div>
          </div><!-- /.row -->
          <!-- Main row -->
        
         
		
          <div class="row">
            <div class="col-md-8">
              <!-- TABLE: LATEST ORDERS -->
              <div class="box box-info">
                <div class="box-header with-border">
                  <h3 class="box-title">Recent 10 Orders</h3>
                  <div class="box-tools pull-right">
                    <button class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
                    <button class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
                  </div>
                </div><!-- /.box-header -->
                
                
                <div class="box-body">
                  <div class="table-responsive">
                  <table class="table no-margin">
                    <thead >
                      <tr >
                   
                       <th >Id</th>
                        <th>Bill To</th>
                        <th style="background:#fff">Ship To</th>
                        <th style="background:#fff">Order On</th>
                        <th>Status</th>
                        <th style="background:#fff">Total</th>
                        <th style="background:#fff">View Order</th>
                      </tr>
                    </thead>
                    <?php
					
			   foreach($orders as $order)
			   {
				  
			    ?>
                    <tbody>
                      <td><?php echo $order->id; ?></td>
                      <td><?php echo $order->bill_firstname; echo nbs();echo $order->bill_lastname; ?></td>
                      <td><?php echo $order->ship_firstname; echo nbs();echo $order->ship_lastname; ?></td>
                      <td><?php echo $order->ordered_on; ?></td>
                      <td><?php echo $order->status; ?></td>
                   <!-- <td>
                       <?php if($order->status=="orderplaced")
					   {
						    echo "<span class='label label-info>Order Placed</span>";
					   }
					   elseif($order->status=="pending")
					   {
						    echo "<span class='label label-warning>Pending</span>";
					   }
					   
					   elseif($order->status=="processing")
					   {
						    echo "<span class='label label-info>Processing</span>";
					   }
					   elseif($order->status=="shipped")
					   {
						    echo "<span class='label label-success>Shipped</span>";
					   }
						else if($order->status=="cancelled")
						{
							 echo "<span class='label label-warnin>Cancelled</span>";
					 } 
					 else if($order->status=="delivered")
					 {
						  echo "<span class='label label-danger>Delivered</span>";
				     }
					  else
					   {
						    echo "";
					   }
					    ?>
					  </td>-->
                      <td><?php echo $order->g_total; ?>&nbsp;&nbsp;<i class="fa fa-rupee"></i></td>
                      <td>
                      
                      <a href="<?php echo site_url('sales/orders/invoice').'/'.$order->id; ?>">
                      
                      <img src="<?php echo base_url('/images/view.gif'); ?>" height="40" width="60" /></a>
                      
                      
                      </td>
                    </tbody>
                <?php } ?>
                  </table>
                 
                  </div><!-- /.table-responsive -->
                </div><!-- /.box-body -->
                <div class="box-footer clearfix">
                 
                  <a href="<?php echo site_url('sales/orders/'); ?>" class="btn btn-sm btn-default btn-flat pull-right">View All Orders</a>
                </div><!-- /.box-footer -->
              </div><!-- /.box -->
            </div><!-- /.col -->
            <div class='col-md-4'>
              <!-- USERS LIST -->
              <div class="box box-danger">
                <div class="box-header with-border">
                  <h3 class="box-title">Latest Members</h3>
                  <div class="box-tools pull-right">
                    <span class="label label-danger">8 &nbsp;	 New Members</span>
                    <button class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
                    <button class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
                  </div>
                </div><!-- /.box-header -->
                <div class="box-body no-padding">
                  <ul class="users-list clearfix">
                    <?php 
					if($customer)
					{
					foreach ($customer as $cust) {
                    ?>
                    	<li>
                      <img src="<?php echo base_url();?>bootstrap/dist/img/avatar.png" alt="User Image"/>


                      <a class="users-list-name" href="#"><?php echo ucfirst($cust->customer_fname);?></a>
                      <span class="users-list-date"><?php echo $cust->customer_created ?></span>
                    </li>
                    
                    <?php 	
                    } 
					}?> 
                    
                  </ul><!-- /.users-list -->
                </div><!-- /.box-body -->
                <div class="box-footer text-center">
                  <?php echo anchor('customer/customer','View All Customers','class="uppercase"'); ?>
                  
                </div><!-- /.box-footer -->
              </div><!--/.box -->
            </div>
            <div class="col-md-4">
              <!-- PRODUCT LIST -->
              <div class="box box-primary">
                <div class="box-header with-border">
                  <h3 class="box-title">Recently Added Products</h3>
                  <div class="box-tools pull-right">
                    <button class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
                    <button class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
                  </div>
                </div><!-- /.box-header -->
                <div class="box-body">
                  <ul class="products-list product-list-in-box">
                  <?php foreach ($product as $prodcut_item) {
                  	?>
                  	<li class="item">
                     <div class="product-img">
                     <img src="
								<?php
								if(file_exists("../uploads/product_image/thumbs/$prodcut_item->product_img"))
								{?>
								 <?php echo base_url("../uploads/product_image/thumbs/$prodcut_item->product_img")?>
								<?php 
								}
								else
								{
									?>
                                     <?php echo base_url("images/comingsoon.jpg")?>
                                    <?php 
								
								}
								?>
								"style="height:60px;width:60px" />
                     
                     
                        
                      </div>
                      <div class="product-info" style="margin-left: 70px;
margin-top: 10px;">
                        <a href="javascript::;" class="product-title"><?php echo $prodcut_item->product_title; ?> <span class="label label-warning pull-right"><?php echo "Rs."; echo $prodcut_item->product_price ?></span></a>
                        <span class="product-description">
                          <?php echo substr($prodcut_item->product_desc, 0,25); echo "&nbsp;....." ?>
                        </span>
                      </div>
                    </li><!-- /.item -->
                  	<?php
                  } ?> 
                    
                    
                  </ul>
                </div><!-- /.box-body -->
                <div class="box-footer text-center">
                 <?php echo anchor('product/product','View All Prodcuts','class="uppercase"'); ?>
                </div><!-- /.box-footer -->
              </div><!-- /.box -->
            </div><!-- /.col -->

          </div><!-- /.row (main row) -->

        </section><!-- /.content -->
      </div><!-- /.content-wrapper -->
      