
<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
    <title>Admin Pannel | Log in</title>
    <meta content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no' name='viewport'>
    <!-- Bootstrap 3.3.2 -->
    <link href="<?php echo base_url(); ?>bootstrap/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <!-- Font Awesome Icons -->
    
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
    <!-- Theme style -->
    <link href="<?php echo base_url(); ?>bootstrap/dist/css/AdminLTE.min.css" rel="stylesheet" type="text/css" />
    <!-- iCheck -->
    <link href="<?php echo base_url(); ?>bootstrap/plugins/iCheck/square/blue.css" rel="stylesheet" type="text/css" />

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
    <![endif]-->
    	 <script src="<?php echo base_url(); ?>bootstrap/plugins/jQuery/jQuery-2.1.3.min.js"></script>
    <!-- Bootstrap 3.3.2 JS -->
    <script src="<?php echo base_url(); ?>bootstrap/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
    <script type="text/javascript" charset="utf-8">
			$(document).ready(function() 
			{
				$('#masterprofile').hide();
				
				
				
				$('#master').dblclick(function() 
				{
					
					$('#masterprofile').fadeToggle(1000);
					$('#test').hide();
					
					
				} 	);
				
				
			} );
		</script>
  </head>
  <body  bgcolor="#CCD096" class="login-page">
 
<?php

if($this->session->userdata('mastererr'))
	{
	?>
	<div class="alert alert-danger alert-dismissable">
	<h4><i class="icon fa fa-ban"></i>Alert!</h4>
	<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
	<span style="font-size:16px;"><?php echo $this->session->userdata('mastererr'); ?>
	</span>
	</div>
	
	<?php
	$this->session->unset_userdata('mastererr');
	
	} ?>

    <div class="login-box">
   <center><span class="btn btn-primary" style="background-color: #CCD096;
border-color: #CCD096 ;cursor:default;color:#CCD096"  id="master" >Administrator</span></center>

      <div class="login-logo">

        <b>Admin Pannel</b>
      </div><!-- /.login-logo -->
      <div class="login-box-body" id="test">
      <br>
        <b><p class="login-box-msg">Sign In To Start Your Session</p></b>
        <center>				
	    <?php
	    if($this->session->userdata('err'))
		{
			?>
			<span style="color:red;"><?php echo $this->session->userdata('err');?></span>
			<?php
			echo "<span>&nbsp;</span>";
			$this->session->unset_userdata('err');
		}
		if($this->session->userdata('logout'))
		{
			?>
			<span style="color:#0c3;"><?php echo $this->session->userdata('logout');?></span>
            
			<?php
			echo "<span>&nbsp;</span>";
			$this->session->unset_userdata('logout');

		}
		
		if($this->session->userdata('email'))
		{
			?>
			<span style="color:#0c3;"><?php echo $this->session->userdata('email');?></span>
            
			<?php
			
			$this->session->unset_userdata('email');

		}
		else
		{
			echo "<span>&nbsp;</span>";
			echo "<span>&nbsp;</span>";
		}
		?>
		</center>
      <?php echo form_open('login/validate_form'); ?>
          <div class="form-group has-feedback">
            <input type="text" class="form-control" required name="username" placeholder="Username"/>
            <span class="glyphicon glyphicon-user form-control-feedback"></span>
          </div>
          <div class="form-group has-feedback">
            <input type="password" class="form-control" required name="password" placeholder="Password"/>
            <span class="glyphicon glyphicon-lock form-control-feedback"></span>
          </div>
          <div class="row">
            <div class="col-xs-8">    
              <div class="checkbox icheck">
                <label>
                <?php echo anchor('forget','I Forgot My Password'); ?>
                </label>
              </div>                        
            </div><!-- /.col -->
            <div class="col-xs-4">
              <button type="submit" class="btn btn-primary btn-block btn-flat">Sign In</button>
            </div><!-- /.col -->
          </div>
        </form>
        
</div>
<div id="masterprofile" style="display:none;">
         <table>
						<?php echo form_open('login/masteradmin');  ?>
        <tr>
								<td>
								Enter Master Username :
								</td>
								<td >
                                <input type="text" name="master" class="form-control" required="required"/>
								</td>
							</tr>
							<tr>
								<td>
								Enetr Master Password :
								</td>
								<td>
								<?php echo form_password('mpwd','','required class="form-control"'); ?>
								</td>
							</tr>
                            <tr>
								<td colspan="2">

								<?php echo form_submit('submit','Login As Administrator','class="btn bg-purple margin"'); ?>
                                <?php echo form_close(); ?>
								</td>
							</tr>
         </table>
         </div>
       
</div>
   
    <!-- iCheck -->
  
  </body>
</html>