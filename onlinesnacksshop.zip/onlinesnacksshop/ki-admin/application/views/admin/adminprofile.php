
<style type="text/css">
	
input[type='password']    
{
	height: 35px;
	width: 200px;
	margin-left: 15px;
}
input[type='text']    
{
	height: 35px;
	width: 200px;
	margin-left: 15px;
}
label
{
	height: 35px;
	width: 180px;
	margin-left: 15px;
}

td
{

	padding:5px;
		padding-left:10px;
}


</style>
<div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
			Change Profile::
          
          </h1>
          <ol class="breadcrumb">
          <li><?php echo anchor('','<i class="fa fa-dashboard"></i> Dashbord'); ?></li>
              <li><?php echo anchor('website/dashbord','<i class="fa fa-gear"></i>Admin Setting'); ?></li>
            
           <li class="active">Change Profile</li>
          </ol>
        </section>

        <!-- Main content -->
        <section class="content">
          <div class="row">
            <div class="col-xs-12">
              <!-- /.box -->

              <div class="box">
                <div class="box-header">
								<p align="right" style="padding-right:30px;">
                               
								<?php echo anchor('website/settings',"&nbsp;Change Profile",'class="btn btn-primary"'); ?>&nbsp;&nbsp;
                                <?php echo anchor('website/chngpwd/',"&nbsp;Change Password",'class="btn btn-primary"'); ?></p>
                </div><!-- /.box-header -->
					 <?php
 if(validation_errors())
	{
	?>
	<div class="alert alert-danger ">
	<h4><i class="icon fa fa-ban"></i>Alert!</h4>
	
	<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
	<span style="font-size:16px;"><?php echo validation_errors(); ?>
	</span>
	</div>
	
	<?php 
	
	}
	if($this->session->userdata('err1'))
	{
	?>
	<div class="alert alert-danger alert-dismissable">
	<h4><i class="icon fa fa-ban"></i>Alert!</h4>
	<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
	<span style="font-size:16px;"><?php echo $this->session->userdata('err1'); ?>
	</span>
	</div>
	
	<?php
	$this->session->unset_userdata('err1');
	
	}
	
	if($this->session->userdata('update'))
	{
	?>
	 <div class="alert alert-success alert-dismissable">
					  <h4><i class="icon fa fa-check"></i>Alert!</h4>
	<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
	<span style="font-size:16px; color:#000"><?php echo $this->session->userdata('update'); ?>
	</span></div>
	<?php
	
	$this->session->unset_userdata('update');
	}
?>	 
<?php 
	if($this->session->userdata('mastererr'))
	{
	?>
	<div class="alert alert-danger alert-dismissable">
	<h4><i class="icon fa fa-ban"></i>Alert!</h4>
	<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
	<span style="font-size:16px;"><?php echo $this->session->userdata('mastererr'); ?>
	</span>
	</div>
	
	<?php
	$this->session->unset_userdata('mastererr');
	}?>
        <div class="box-body">         
		</div>
        
       <div id="profile">
        <table>
					<?php echo form_open('website/updateadmin');  ?>
					<?php echo form_hidden('id',$admin_profile->id); ?>
							<tr>
								<td>
								Username:
								</td>
								<td >
								
                                <input type="text" disabled="disabled" value="<?php echo $admin_profile->username ?>"  class="form-control"/>
	
								</td>
							</tr>
							<tr>
								<td>
								First Name:
								</td>
								<td>
								<?php echo form_input('first_name',$admin_profile->first_name,'required class="form-control"'); ?>
								</td>
							</tr>
							<tr>
								<td>
								Last Name:
								</td>
								<td>
								<?php echo form_input('last_name',$admin_profile->last_name,'required class="form-control"'); ?>
								</td>
							</tr>
							<tr>
								<td>
								Email:
								</td>
								<td>
								<?php echo form_input('email',$admin_profile->email,'required class="form-control"'); ?>
								</td>
							</tr>
							<tr>
								<td colspan="2">

								<?php echo form_submit('submit','Update Profile','class="btn bg-purple margin"'); ?>
                                <?php echo form_close(); ?>
								</td>
							</tr>
							</table>					
				
        </div>
         
        
                </div><!-- /.box-body -->
              </div><!-- /.box -->
            </div><!-- /.col -->
         
        </section><!-- /.content -->
      </div>						

