<body class="skin-purple">
    <div class="wrapper">
      
      <header class="main-header">
        <!-- Logo -->
        <span class="logo"><b>Admin Pannel</b></span>
        <!-- Header Navbar: style can be found in header.less -->
        <nav class="navbar navbar-static-top" role="navigation">
          <!-- Sidebar toggle button-->
          <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
            <span class="sr-only">Toggle navigation</span>
          </a>
          <div class="navbar-custom-menu">
            <ul class="nav navbar-nav">
              <!-- Messages: style can be found in dropdown.less-->
              
              <!-- User Account: style can be found in dropdown.less -->
              <li class="dropdown user user-menu">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                  <img src="<?php echo base_url();?>bootstrap/dist/img/avatar5.png" class="user-image" alt="User Image"/>
                  <span class="hidden-xs">Welcome,
				<?php if($this->session->userdata('username'))
				{
					echo ucfirst($this->session->userdata('username'));
					
				}  ?></span>
                </a>
                <ul class="dropdown-menu">
                  <!-- User image -->
                  <li class="user-header">
                    <img src="<?php echo base_url();?>bootstrap/dist/img/avatar5.png" class="img-circle" alt="User Image" />
                    <p style="color:#000">
                     <i><?php echo ucfirst($this->session->userdata('username')); ?></i>
                      <i><small><p  style="color:#000">Last Login : <?php echo $this->session->userdata('last_login'); ?></p></small></i>
                    </p>
                  </li>
                  <!-- Menu Body -->
                 <!-- <li class="user-body">
                    <div class="col-xs-4 text-center">
                      <a href="#">Followers</a>
                    </div>
                    <div class="col-xs-4 text-center">
                      <a href="#">Sales</a>
                    </div>
                    <div class="col-xs-4 text-center">
                      <a href="#">Friends</a>
                    </div>
                  </li>
                  <!-- Menu Footer-->
                  <li class="user-footer">
                    <div class="pull-left">
                      <a href="<?php echo site_url('website/settings'); ?>" class="btn btn-default btn-flat">Profile</a>
                    </div>
                    <div class="pull-right">
                      <a href="<?php echo site_url('website/logout'); ?>" class="btn btn-default btn-flat">Sign out</a>
                    </div>
                  </li>
                </ul>
              </li>
            </ul>
          </div>
        </nav>
      </header>
      <!-- Left side column. contains the logo and sidebar -->
      <aside class="main-sidebar">
        <!-- sidebar: style can be found in sidebar.less -->
        <section class="sidebar">
          <!-- Sidebar user panel -->
          <div class="user-panel">
            <div class="pull-left image">
              <img src="<?php echo base_url();?>bootstrap/dist/img/avatar5.png" class="img-circle" alt="User Image" />
            </div>
            <div class="pull-left info">
              <p><i><?php echo ucfirst($this->session->userdata('username'))?></i></p>

              <a href="#"><i class="fa fa-circle text-success"></i> <i>Online</i></a>
            </div>
          </div>
          <!-- search form -->
         <!-- <form action="#" method="get" class="sidebar-form">
            <div class="input-group">
              <input type="text" name="q" class="form-control" placeholder="Search..."/>
              <span class="input-group-btn">
                <button type='submit' name='search' id='search-btn' class="btn btn-flat"><i class="fa fa-search"></i></button>
              </span>
            </div>
          </form>
          <!-- /.search form -->
          <!-- sidebar menu: : style can be found in sidebar.less -->
          <ul class="sidebar-menu">
            <li class="header">MENUS</li>
            <li <?php echo $this->uri->segment(2)=='dashbord'?"class='active'":"";?>>
            <?php echo anchor('website/dashbord','<i class="fa fa-dashboard"></i><span>Dashboard</span>',active_link('website')); ?>

            </li>
           
            <li <?php echo $this->uri->segment(1)=='cms'?"class='active'":"";?>>
            <?php echo anchor('cms/cms','<i class="fa fa-files-o"></i><span>CMS</span>',active_link('cms')); ?>
            </li>
            <li  <?php echo $this->uri->segment(1)=='category'?"class='active'":"";?>>
             <?php echo anchor('category/category','<i class="fa fa-th fa fa-table"></i><span>Category</span>',active_link('category')); ?>              
            </li>
             <li  <?php echo $this->uri->segment(1)=='product'?"class='active'":"";?>>
             <?php echo anchor('product/product','<i class="fa fa-th fa-th-large"></i><span>Products</span>',active_link('product')); ?>
              
              </a>
            </li >
             <li  <?php echo $this->uri->segment(1)=='namkeen'?"class='active'":"";?>>
             <?php echo anchor('namkeen/namkeen','<i class="fa fa-th fa-th-large"></i><span>Namkeen</span>',active_link('namkeen')); ?>
              
              </a>
            </li >
            
         <!--    <li  <?php echo $this->uri->segment(1)=='backup'?"class='active'":"";?>>
             <?php echo anchor('backup','<i class="fa fa-th fa-rotate-right"></i><span>Backup</span>',active_link('backup')); ?>
              
              </a>
            </li >-->
            
           <li  <?php echo $this->uri->segment(1)=='news'?"class='active'":"";?>>
           <?php echo anchor('news/news','<i class="fa fa-th fa-th-list"></i><span>News</span>',active_link('news')); ?>
            </li>
             <li <?php echo $this->uri->segment(1)=='newsletter'?"class='active'":"";?>>
            <?php echo anchor('newsletter','<i class="fa fa-files-o"></i><span>News Letter</span>',active_link('newsletter')); ?>
            </li>
             <li  <?php echo $this->uri->segment(2)=='orders'?"class='active'":"";?>>
           <?php echo anchor('sales/orders','<i class="fa fa-circle-o"></i><span>Orders</span>'); ?>
            </li>
            <li  <?php echo $this->uri->segment(1)=='customer'?"class='active'":"";?>><?php echo anchor('customer/customer','<i class="fa fa-group"></i><span>Customer</span>'); ?></li>
	       
           <!--  <li class="treeview">
              <a href="#">
                <i class="fa fa-envelope"></i> <span>Reports</span>
                <i class="fa fa-angle-left pull-right"></i>
              </a>
             <!-- <ul class="treeview-menu">
                <li>
                <?php echo anchor('reports/sales','<i class="fa fa-circle-o"></i><span>Sales_Report</span>'); ?>
				</li>
                 <li  <?php echo $this->uri->segment(1)=='customer_reports'?"class='active'":"";?>><?php echo anchor('reports/customer_reports','<i class="fa fa-group"></i><span>Customer_Reports</span>'); ?></li>
                <li>
                  <li><?php echo anchor('reports/product_reports','<i class="fa fa-envelope"></i><span>Product_Reports</span>'); ?></li>
                   
              </ul>-->
            </li>
            
            
              <li  <?php echo $this->uri->segment(1)=='banner'?"class='active'":"";?>>
             <?php echo anchor('banner/banner','<i class="fa fa-th fa-th-large"></i><span>Banner</span>',active_link('banner')); ?>
         
              </a>
            </li >
          <!--  <li  <?php echo $this->uri->segment(1)=='customer'?"class='active'":"";?>>
                       <?php echo anchor('customer/customer','<i class="fa fa-group"></i> <span>Customers</span>',active_link('customer')); ?>

            </li>-->
            <li  <?php echo $this->uri->segment(1)=='contact'?"class='active'":"";?>>
             <?php echo anchor('contact/contact','<i class="fa fa-envelope"></i> <span>Feedbacks</span>',active_link('contact')); ?>

            </li>

             <li  <?php echo $this->uri->segment(2)=='settings'?"class='active'":"";?> <?php echo $this->uri->segment(2)=='chngpwd'?"class='active'":"";?>>
             <?php echo anchor('website/settings','<i class="fa fa-gear"></i> <span>Admin Setting</span>',active_link('contact')); ?>

            </li>
            <?php 
			if($this->session->userdata('master'))
			{
				?>
                <li  <?php echo $this->uri->segment(1)=='master'?"class='active'":"";?> <?php echo $this->uri->segment(1)=='master'?"class='active'":"";?>>
             <?php echo anchor('website/mastermenu','<i class="fa fa-gear"></i> <span>Master Admin Menu</span>',active_link('contact')); ?>

            </li>
                <?php
			}
			?>
            
          </ul>
        </section>
        <!-- /.sidebar -->
      </aside>