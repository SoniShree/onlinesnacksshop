<?php
	$this->load->view('templates/header');
	$this->load->view('templates/menu');
	$this->load->view($page);
	$this->load->view('templates/footer');
?>