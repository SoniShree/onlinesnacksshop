<style type="text/css">
	
input[type='text']    
{
	height: 35px;
	width: 200px;
	margin-left: 15px;
}
.textarea    
{
	height: 65px;
	width: 200px;
	margin-left: 15px;
}
.upload    
{
	height: 35px;
	width: 200px;
	margin-left: 15px;
}
.drpdwn
{
	height: 35px;
	width: 200px;
	margin-left: 15px;
}
.btn
{
	height: 40px;
	width: 180px;
	
}
td
{
	padding:5px;
}
</style>

<div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
			Add Namkeen::
          
          </h1>
          <ol class="breadcrumb">
           <li><?php echo anchor('','<i class="fa fa-dashboard"></i> Dashbord'); ?></li>
              <li><?php echo anchor('namkeen/namkeen','<i class="fa fa-th fa-th-list"></i>namkeen'); ?></li>
            
            <li class="active">Add Namkeen</li>
          </ol>
        </section>

        <!-- Main content -->
        <section class="content">
          <div class="row">
            <div class="col-xs-12">
              <!-- /.box -->

              <div class="box">
                <div class="box-header">
								<h4><?php echo anchor('namkeen/namkeen/',"<i class='fa fa-fw fa-arrow-left'></i>&nbsp;Back To Namkeen",'class="btn btn-primary"'); ?></h4>
                </div><!-- /.box-header -->
               
            
			
		<span>&nbsp;</span>
        <span>&nbsp;</span>
               
                
                  <?php
				  if(validation_errors())
					{
						?>
                         <div class="alert alert-danger ">
                         <h4><i class="icon fa fa-ban"></i>Alert!</h4>
                         
				    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                  <span style="font-size:16px;"><?php echo validation_errors(); ?>
                  </span>
                  </div>
                 
                        <?php 
							
					}
			if($this->session->userdata('imgerr'))
			{
				?>
                 <div class="alert alert-danger alert-dismissable">
                 <h4><i class="icon fa fa-ban"></i>Alert!</h4>
				    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                  <span style="font-size:16px;"><?php echo $this->session->userdata('imgerr'); ?>
                  </span>
                  </div>
                  
				<?php
				$this->session->unset_userdata('imgerr');
				
			}
			?>
                  
                <div class="box-body">
  				<?php echo form_open_multipart('namkeen/namkeen/addnew'); ?>
				<table cellpadding="5">
				<tr>
					<td valign="top">
								<label>Title <span style="color:#f00">(Required Field)</span></label>
					</td>
					<td>

									<input type="text" required="required" value="<?php echo $this->input->post('namkeen_title'); ?>" name="namkeen_title" class="form-control" />
					</td>
				</tr>
                <tr>
					<td valign="top">
								<label>Price /Kg. <span style="color:#f00">(Required Field)</span></label>
					</td>
					<td>

									<input type="text" required="required" value="<?php echo $this->input->post('namkeen_price'); ?>" name="namkeen_price" class="form-control" />
					</td>
				</tr>
                <tr>
					<td valign="top">
								<label>Quantity (In kg)<span style="color:#f00">(Required Field)</span></label>
					</td>
					<td>

									<input type="text" required="required" value="<?php echo $this->input->post('namkeen_qty'); ?>" name="namkeen_qty" class="form-control" />
					</td>
				</tr>
                <tr>
					<td valign="top">
								<label>Image <span style="color:#f00">(Required Field)</span></label>
					</td>
					<td >
					
								<?php echo form_upload('namkeen_images','',' class="upload"'); ?>
					</td>
				</tr>
                <tr>
					<td valign="top">
								<label>Status <span style="color:#f00">(Required Field)</span></label>
					</td>
					<td >
					
					<?php $options = array(
								                  '1'    => 'Enable',
								                  '0'  => 'Disable',
								                  ); ?>
								<?php echo form_dropdown('namkeen_status',$options, set_value('namkeen_status'),' class="drpdwn form-control"'); ?>
					</td>
				</tr>
                <tr>
					<td valign="top">
								<label>Sort Description: <span style="color:#f00">(Required Field)</span></label>
					</td>
					<td >

									<textarea class="form-control" required="required" name="namkeen_sort" rows="10" cols="60"><?php echo $this->input->post('namkeen_sort'); ?></textarea>
					</td>
				</tr>
                <tr>
					<td valign="top">
								<label>Long Description: <span style="color:#f00">(Required Field)</span></label>
					</td>
					<td >

									<textarea class="form-control" required="required" name="namkeen_long" rows="10" cols="60"><?php echo $this->input->post('namkeen_long'); ?></textarea>
					</td>
				</tr>
				
				
				
				</table>		
							
							
							<input type="submit" class="btn bg-purple margin" value="Add" />

					<?php echo form_close(); ?>
                
                </div><!-- /.box-body -->
              </div><!-- /.box -->
            </div><!-- /.col -->
          </div><!-- /.row -->
        </section><!-- /.content -->
      </div>


			
					<div >
						
