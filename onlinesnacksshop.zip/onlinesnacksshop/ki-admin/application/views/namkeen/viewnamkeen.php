<style>
tbl
{
	width:250px;
	float:right;
}
tbl1
{
		width:250px;
	float:right;
}
#content
{
	min-height:500px;
}
.li-img img {
  display: block;
  width: 15%;
  margin: 5px 5px 5px 5px;

  height: auto;
  float:left;
  min-height:100px;
  max-height:100px;
  min-width:100px;
  max-width:100px;
  border:solid 10px #63C;
  
}
.li-img a {
	margin-left:25px;
	margin-top:-10px;
}


</style>

<script type="text/javascript" charset="utf-8">
			$(document).ready(function() 
			{
				$('#addform').hide();
				
				
				
				$('#addgallery').click(function() 
				{
					
					$('#addform').fadeIn(1000);
					$('#gallery').hide(1000);
				} 	);
				$('#showgallery').click(function() 
				{
					$('#addform').hide(1000);
					$('#gallery').fadeIn(1000);
					
				} 	);
				
			} );
		</script>
    
<div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
			Namkeen Section::
          
          </h1>
          <ol class="breadcrumb">
            <li><?php echo anchor('','<i class="fa fa-dashboard"></i> Dashbord'); ?></li>
              <li><?php echo anchor('namkeen/namkeen','<i class="fa fa-th fa-th-large"></i>namkeen'); ?></li>
            <li class="active">Namkeen List</li>
          </ol>
        </section>

        <!-- Main content -->
        <section class="content">
          <div class="row">
            <div class="col-xs-12">
              <!-- /.box -->

              <div class="box">
                <div class="box-header">
				<?php echo anchor('namkeen/namkeen/',"<span><span><i class='fa fa-fw fa-arrow-left'></i>&nbsp;Back to namkeen</span>",'class="btn btn-primary"'); ?>
                <input type="button" id="addgallery"  class="add-image" value="Add Images" style="height:35px;width:100px;;background:#3C8DBC;color:#FFF;"/>
                <input type="button" id="showgallery"  class="show-gallery" value="Show Gallary" style="height:35px;background:#3C8DBC;color:#FFF;"/>
				
                </div>
                 
                <div class="box-body">
						<div id="tbl">
	

							<img src="<?php echo  base_url("../uploads/product_image/thumbs/").'/'.$namkeen_item->namkeen_images ?>" alt="<?php echo $namkeen_item->namkeen_images; ?>" width="200" />
						
</div>
<div id="tbl1">

					<table cellspacing="40" >
						<tr>
							<td valign="top"><span><b>Title :-</b></span></td>
							<td><span><?php echo $namkeen_item->namkeen_title ?></span></td>
						</tr>
                        <tr>
							<td valign="top"><span><b>Price :-</b></span></td>
							<td><span><?php echo $namkeen_item->namkeen_price ?></span></td>
						</tr>
                        <tr>
							<td valign="top"><span><b>Quantity :-</b></span></td>
							<td><span><?php echo $namkeen_item->namkeen_qty ?></span></td>
						</tr>
						<tr>
							<td valign="top"><span><b>Sort Description :-</b></span></td>
							<td><span><?php echo $namkeen_item->namkeen_sort ?></span></td>
						</tr>
                        <tr>
							<td valign="top"><span><b>Long Description :-</b></span></td>
							<td><span><?php echo $namkeen_item->namkeen_long ?></span></td>
						</tr>
					
						<tr>
							<td valign="top"><span><b>Status :-</b></span></td>
						<td><span><?php if($namkeen_item->namkeen_status =="0") { echo "Disabled"; } else { echo "Enabled"; } ?></span></td>
						</tr>
						
						
					</table>	
</div>
<div id="content">
				<div id="gallery" class="timeline-body">
                   
                        <?php 
						 foreach($image as $img)
                         {
                             ?>
                             <div class="li-img" >
                             	<div style="height:100px;width:100px;" >
                                <a href="<?php echo base_url('../uploads/product_image/thumbs/'.$img->namkeen_id.'/full').'/'.$img->long_name; ?>">
                            		<img src="<?php echo base_url('../uploads/product_image/thumbs/'.$img->namkeen_id.'/thumbs').'/'.$img->long_name; ?>"  alt="Image Alt Text" class="margin"/></a>
                                </div>
                               
                                <div style="height:100px;width:100px;">
                                	 	
                                <?php
									echo anchor('namkeen/namkeen/imgdel/'.$img->namkeen_id.'/'.$img->photo_id,'Delete','onclick="return window.confirm(\'Are You Sure?\');"');
								?>
                                	
                                </div>
                            </div>
                         <?php }?>
               
                </div>
                <div id="addform">
                   <center>
               
                    	 <?php echo form_open_multipart('namkeen/namkeen/addgallery/'. $namkeen_item->namkeen_id) ?>
						<div class="form">
								<p>
									<input type="hidden" value="<?php echo $namkeen_item->namkeen_id; ?>" name="namkeen_id"  />
									<label>namkeen Name</label>
                                    <center>
									<input type="text" class="form-control"  style=" width:200px;text-align:center;" readonly="readonly" value="<?php echo $namkeen_item->namkeen_title; ?>" required="required" name="p_name" style="text-align:center;"/>
                                    </center>
								</p>
                                <p>
                                	<label>Images</label>
                                    
                                    	 <?php echo form_upload('userfile[]','','multiple=TRUE')  ?>
                                </p>	
								
						</div>
						
						<div class="buttons">
							<center>
							<input type="submit" class="button" value="Add Images" />
                            </center>
						</div>

					</form>
     
                </center> 
                    </div>
                    </div>
                
                <div class="box-content">
            			
                        <!--<span id="addgallery"  class="add-image" style=" width:110px;">Add Images</span><br /><br />
                        <span id="showgallery"  class="show-gallery" style=" width:110px;">Show Gallery</span>-->
						<div class="cl">&nbsp;</div>
						
						<!-- Sort -->
						
					</div><!-- /.box-body -->
              </div><!-- /.box -->
            </div><!-- /.col -->
          </div><!-- /.row -->
        </section><!-- /.content -->
      </div>


