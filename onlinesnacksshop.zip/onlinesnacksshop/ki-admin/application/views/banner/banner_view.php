
    
<div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
			banner Section::
          
          </h1>
          <ol class="breadcrumb">
             <li><a href=""><i class="fa fa-dashboard"></i> Dashbord</a></li>
            <li><a href="<?php echo base_url('banner/banner'); ?>"><i class="fa fa-th fa-th-large"></i>banner</a></li>
           <li class="active">banner List</li>
          </ol>
        </section>

        <!-- Main content -->
        <section class="content">
          <div class="row">
            <div class="col-xs-12">
              <!-- /.box -->

              <div class="box">
                <div class="box-header">
				<h4><?php echo anchor('banner/banner/addbanner',"<span>Add banner</span>",'class="btn btn-primary"'); ?></h4>
                </div><!-- /.box-header -->
               
                   <?php
			if($this->session->userdata('insert'))
			{
				?>
				 <div class="alert alert-success alert-dismissable">
                                  <h4><i class="icon fa fa-check"></i>Alert!</h4>
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                   <span style="font-size:16px; color:#000"> &nbsp;&nbsp;<?php echo $this->session->userdata('insert'); ?>
                   </span></div>
				<?php
				$this->session->unset_userdata('insert');
			
			}
		    if($this->session->userdata('del'))
			{
				?>
								 <div class="alert alert-success alert-dismissable">
                                                  <h4><i class="icon fa fa-check"></i>Alert!</h4>
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                   <span style="font-size:16px; color:#000"><?php echo $this->session->userdata('del'); ?>
                   </span></div>
				<?php
				$this->session->unset_userdata('del');
				echo "</p>";
			}
			if($this->session->userdata('edit'))
			{
				?>
								 <div class="alert alert-success alert-dismissable">
                                                  <h4><i class="icon fa fa-check"></i>Alert!</h4>
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                   <span style="font-size:16px; color:#000"><?php echo $this->session->userdata('edit'); ?>
                   </span></div>
				<?php

				$this->session->unset_userdata('edit');
				echo "</p>";
			}
		
			
		?>
		<span>&nbsp;</span>
        <span>&nbsp;</span>
               
                
                  <?php
			if($this->session->userdata('notfound'))
			{
				?>
                 <div class="alert alert-danger alert-dismissable">
                   <h4><i class="icon fa fa-ban"></i>Alert!</h4>
				    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                  <span style="font-size:16px;"><?php echo $this->session->userdata('notfound'); ?>
                  </span>
                  </div>
                  
				<?php
				$this->session->unset_userdata('notfound');
				
			}
			?>
                  
                <div class="box-body">
                  <table id="example1" class="table table-bordered table-striped">
                    <thead >
                      <tr align="right">
                 
                       <th>Id</th>
                        <th>Name</th>
                        <th style="background:#fff">Banner Images</th>
						
                        <th style="background:#fff">Status</th>
                        <th>Created</th>
                        <th style="background:#fff">Content Control</th>
                      </tr>
                    </thead>
                    <tbody align="center">
                      <?php foreach ($banner as $banner_item){ ?>
							<tr class="odd" align="center">
				
								<td><?php echo $banner_item->banner_id ?></td>
								<td><?php echo $banner_item->banner_name ?></td>
								<td align="center"><img src="
								<?php
								if(file_exists("../uploads/banner_image/thumbs/".$banner_item->banner_img))
								{?>
								 <?php echo base_url("../uploads/banner_image/thumbs/").'/'.$banner_item->banner_img ?>
								<?php 
								}
								else
								{
									?>
                                     <?php echo base_url("images/comingsoon.jpg")?>
                                    <?php 
								
								}
								?>
								"style="height:70px;width:70px" /></td>
                                <td><?php if($banner_item->status =="0"){ echo "<span style='color:red'>Disabled</span>"; } else { echo "<span style='color:green'>Enabled</span>"; }?></td>
								<td><?php echo $banner_item->banner_created ?></td>
								 <td><a href="<?php echo site_url('banner/banner/delete').'/'. $banner_item->banner_id ?>" onclick="return confirm('Are You Sure?');"><img src="<?php echo base_url('/images/delete.gif'); ?>" height="40" width="60" /></a>&nbsp;
								 

								 <a href="<?php echo site_url('banner/banner/edit').'/'. $banner_item->banner_id ?>"><img src="<?php echo base_url('/images/edit.gif'); ?>" height="40" width="60" /></a>&nbsp;</a>&nbsp;&nbsp;<a href="<?php echo site_url('banner/banner/view').'/'. $banner_item->banner_id ?>"><img src="<?php echo base_url('/images/view.gif'); ?>" height="40" width="60" /></a></td>
							</tr>
							<?php } ?>
                      
                    </tbody>
                    
                  </table>
                </div><!-- /.box-body -->
              </div><!-- /.box -->
            </div><!-- /.col -->
          </div><!-- /.row -->
        </section><!-- /.content -->
      </div>
      <!-- jQuery 2.1.3 -->
    <script src="<?php echo base_url();?>bootstrap/plugins/jQuery/jQuery-2.1.3.min.js"></script>
    <!-- Bootstrap 3.3.2 JS -->

    <!-- DATA TABES SCRIPT -->
    <script src="<?php echo base_url();?>bootstrap/plugins/datatables/jquery.dataTables.js" type="text/javascript"></script>
    <script src="<?php echo base_url();?>bootstrap/plugins/datatables/dataTables.bootstrap.js" type="text/javascript"></script>
    <!-- SlimScroll -->
    <script src="<?php echo base_url();?>bootstrap/dist/js/demo.js" type="text/javascript"></script>
    <!-- page script -->
   
	   <script type="text/javascript">
      $(function () {
        $("#example1").dataTable();
        $('#example2').dataTable({
          "bPaginate": true,
          "bLengthChange": false,
          "bFilter": false,
          "bSort": true,
          "bInfo": true,
          "bAutoWidth": false
        });
      });
    </script>
