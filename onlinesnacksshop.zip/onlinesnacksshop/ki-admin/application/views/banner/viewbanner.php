<style>
tbl
{
	width:250px;
	float:left;
}
tbl1
{
		width:250px;
	float:left;
}
</style>


    
<div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
			banner Section::
          
          </h1>
          <ol class="breadcrumb">
             <li><a href=""><i class="fa fa-dashboard"></i> Dashbord</a></li>
            <li><a href="<?php echo base_url('banner/banner'); ?>"><i class="fa fa-th fa-th-large"></i>banner</a></li>
            <li class="active">banner List</li>
          </ol>
        </section>

        <!-- Main content -->
        <section class="content">
          <div class="row">
            <div class="col-xs-12">
              <!-- /.box -->

              <div class="box">
                <div class="box-header">
				<h4><?php echo anchor('banner/banner/',"<span><span><i class='fa fa-fw fa-arrow-left'></i>&nbsp;Back to banner</span>",'class="btn btn-primary"'); ?></h4>
                </div><!-- /.box-header -->
               
                 
                <div class="box-body">
						<div id="tbl">
	

							<img src="<?php echo  base_url("../uploads/banner_image/thumbs/").'/'.$banner_item->banner_img ?>" alt="<?php echo $banner_item->banner_img; ?>" width="200" />
						
</div>
<div id="tbl1">

					<table cellspacing="40">
						<tr>
							<td><span>Title :-</span></td>
							<td><span><?php echo $banner_item->banner_name ?></span></td>
						</tr>
						<tr>
							<td valign="top">Description :-</td>
							<td><span><?php echo $banner_item->banner_desc ?></span></td>
						</tr>
					
						<tr>
							<td><span>Status :-</span></td>
							<td><span><?php if($banner_item->status =="0") { echo "Disabled"; } else { echo "Enabled"; } ?></span></td>
						</tr>
						
						
					</table>	
</div>                  
                </div><!-- /.box-body -->
              </div><!-- /.box -->
            </div><!-- /.col -->
          </div><!-- /.row -->
        </section><!-- /.content -->
      </div>


