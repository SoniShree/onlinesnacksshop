<style type="text/css">	
input[type='text']    
{
	height: 35px;
	width: 180px;
	margin-left: 15px;
}
.textarea    
{
	height: 65px;
	width: 180px;
	margin-left: 15px;
}
.upload    
{
	height: 35px;
	width: 200px;
	margin-left: 15px;
}
.drpdwn
{
	height: 35px;
	width: 180px;
	margin-left: 15px;
}
.btn
{
	height: 40px;
	width: 180px;
	
}
td
{
	padding:5px;
}
</style>
<div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
			Edit banner::
          
          </h1>
          <ol class="breadcrumb">
            <li><a href=""><i class="fa fa-dashboard"></i> Dashbord</a></li>
            <li><a href="<?php echo base_url('banner/banner'); ?>"><i class="fa fa-th fa-th-large"></i>banner</a></li>
            <li class="active">Edit banner</li>
          </ol>
        </section>

        <!-- Main content -->
        <section class="content">
          <div class="row">
            <div class="col-xs-12">
              <!-- /.box -->

              <div class="box">
                <div class="box-header">
				<h4><?php echo anchor('banner/banner/',"<span><i class='fa fa-fw fa-arrow-left'></i>&nbsp;Back To banner</span>",'class="btn btn-primary"'); ?></h4>
                </div><!-- /.box-header -->
               
            
			
		<span>&nbsp;</span>
        <span>&nbsp;</span>
               
                
                  <?php
				
			if($this->session->userdata('imgerr'))
			{
				?>
                 <div class="alert alert-danger alert-dismissable">
                 <h4><i class="icon fa fa-ban"></i>Alert!</h4>
				    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                  <span style="font-size:16px;"><?php echo $this->session->userdata('imgerr'); ?>
                  </span>
                  </div>
                  
				<?php
				$this->session->unset_userdata('imgerr');
				
			}
			?>
                  
                <div class="box-body">
<?php echo form_open_multipart('banner/banner/edit/'."$banner_item->banner_id"); ?>
						
						<?php echo form_hidden('banner_id',$banner_item->banner_id); ?>
				<table cellpadding="5">

				<tr>


					<td>
                		<label>Title <span style="color:#f00">(Required Field)</span></label>
					</td>
					<td>

						<input type="text" value="<?php echo $banner_item->banner_name; ?>" name="banner_name" class="form-control" required="required" />
                           <h4>   <?php
				  if(form_error('banner_name'))
					{
						?>
                         <div class="alert alert-danger ">  
				    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                  <span style="font-size:16px;"><?php echo form_error('banner_name'); ?>
                  </span>
                  </div>
                 
                        <?php 
							
					}?></h4>
					</td>
				</tr>
				<tr>
					<td>
							<label>Status <span style="color:#f00">(Required Field)</span></label>
					</td>
					<td>
							<select name="banner_status" required="required" class="drpdwn form-control" >
							<option value="0" <?php if($banner_item->status==0) { echo "selected"; } ?>>Disabled</option><option  value="1" <?php if($banner_item->status==1) { echo "selected"; } ?>>Enabled</option></select>
					</td>
				</tr>
				<tr>
					<td>
							<label>Image <span style="color:#f00">(Required Field)</span></label>
					</td>
					<td colspan="2">
					
							<?php echo form_upload('banner_images', $banner_item->banner_img,' class="upload "'); ?>
                            <?php echo form_hidden('old_img',$banner_item->banner_img); ?>
                            <br />
                            <p  style="border:2px solid; width:110px;"><img src="<?php echo  base_url("../uploads/banner_image/thumbs/").'/'.$banner_item->banner_img ?>" height="100" width="100" alt="<?php echo $banner_item->banner_img; ?>" /></p>

					</td>
				</tr>
				<tr>
					<td>
						<label >Content <span style="color:#f00">(Required Field)</span></label>
					</td>
					<td>
						<textarea class="form-control redactor" value="" name="banner_desc" rows="10" cols="60"><?php echo $banner_item->banner_desc; ?></textarea>
                           <h4>   <?php
				  if(form_error('banner_desc'))
					{
						?>
                         <div class="alert alert-danger ">  
				    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                  <span style="font-size:16px;"><?php echo form_error('banner_desc'); ?>
                  </span>
                  </div>
                 
                        <?php 
							
					}?></h4>
					</td>
				</tr>
				</table>		
							
							
					<input type="submit" class="btn bg-purple margin" value="Edit" />
					<?php echo form_close(); ?>
                
                </div><!-- /.box-body -->
              </div><!-- /.box -->
            </div><!-- /.col -->
          </div><!-- /.row -->
        </section><!-- /.content -->
   </div>