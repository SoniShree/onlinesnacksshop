<style type="text/css">	
input[type='text']    
{
	height: 35px;
	width: 200px;
	margin-left: 15px;
}
.textarea    
{
	height: 65px;
	width: 200px;
	margin-left: 15px;
}
.upload    
{
	height: 35px;
	width: 200px;
	margin-left: 15px;
}
.drpdwn
{
	height: 35px;
	width: 200px;
	margin-left: 15px;
}
.btn
{
	height: 40px;
	width: 180px;
	
}
td
{
	padding:5px;
}
</style>
<div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
			Edit Product::
          
          </h1>
          <ol class="breadcrumb">
           <li><?php echo anchor('','<i class="fa fa-dashboard"></i> Dashbord'); ?></li>
              <li><?php echo anchor('product/product','<i class="fa fa-th fa-th-large"></i>Product'); ?></li>
            <li class="active">Edit product</li>
          </ol>
        </section>

        <!-- Main content -->
        <section class="content">
          <div class="row">
            <div class="col-xs-12">
              <!-- /.box -->

              <div class="box">
                <div class="box-header">
				<h4><?php echo anchor('product/product/',"<span><i class='fa fa-fw fa-arrow-left'></i>&nbsp;Back To Product</span>",'class="btn btn-primary"'); ?></h4>
                </div><!-- /.box-header -->
               
            
			
		<span>&nbsp;</span>
        <span>&nbsp;</span>
               
                
                  <?php
				 
			if($this->session->userdata('imgerr'))
			{
				?>
                 <div class="alert alert-danger alert-dismissable">
                 <h4><i class="icon fa fa-ban"></i>Alert!</h4>
				    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                  <span style="font-size:16px;"><?php echo $this->session->userdata('imgerr'); ?>
                  </span>
                  </div>
                  
				<?php
				$this->session->unset_userdata('imgerr');
				
			}
			?>
                  
                <div class="box-body">
<?php echo form_open_multipart('product/product/edit/'."$product_item->product_id"); ?>
						
						<?php echo form_hidden('product_id',$product_item->product_id); ?>
				<table cellpadding="5">
              

                 <tr>


					<td>
                <label>Select Category <span style="color:#f00">(Required Field)</span></label>
					</td>
					<td>

                                <select name="category_id" required="required" class="drpdwn form-control" >
                                <?php foreach ($category_name as $category_name) { ?>
									
								<option value="<?php echo  $category_name->category_id ?>"><?php echo $category_name->category_title  ?></option>
                                <?php } ?>
                                </select>
                 </td>
				</tr>
				<tr>


					<td>
                		<label>Title <span style="color:#f00">(Required Field)</span></label>
					</td>
					<td>

						<input type="text" required="required" value="<?php echo $product_item->product_title; ?>" name="product_title" class="form-control" />
                             <?php
				  if(form_error('product_title'))
					{
						?>
                         <div class="alert alert-danger ">  
				    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                  <span style="font-size:16px;"><?php echo form_error('product_title'); ?>
                  </span>
                  </div>
                 
                        <?php 
							
					}?>
					</td>
				</tr>
				<tr>
					<td>
							<label>Status <span style="color:#f00">(Required Field)</span></label>
					</td>
					<td>
							<select name="product_status" required="required" class="drpdwn form-control" >
							<option value="0" <?php if($product_item->product_status==0) { echo "selected"; } ?>>Disabled</option><option  value="1" <?php if($product_item->product_status==1) { echo "selected"; } ?>>Enabled</option></select>
					</td>
				</tr>
                				<tr>


					<td>
                <label>Price /Kg<span style="color:#f00">(Required Field)</span></label>
					</td>
					<td>

				<input type="text" required="required" value="<?php echo $product_item->product_price; ?>" name="product_price" class="form-control" />
                  <?php
				  if(form_error('product_price'))
					{
						?>
                         <div class="alert alert-danger ">  
				    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                  <span style="font-size:16px;"><?php echo form_error('product_price'); ?>
                  </span>
                  </div>
                 
                        <?php 
							
					}?>
					</td>
				</tr>
				<tr>


					<td>
                <label>Quantity(In Kg) <span style="color:#f00">(Required Field)</span></label>
					</td>
					<td>

				<input type="text" required="required" value="<?php echo $product_item->product_qty; ?>" name="product_qty" class="form-control" />
                    <?php
				  if(form_error('product_qty'))
					{
						?>
                         <div class="alert alert-danger ">  
				    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                  <span style="font-size:16px;"><?php echo form_error('product_qty'); ?>
                  </span>
                  </div>
                 
                        <?php 
							
					}?>
					</td>
				</tr>

				<tr>
					<td>
							<label>Image <span style="color:#f00">(Required Field)</span></label>
					</td>
					<td>
					
							<?php echo form_upload('product_images', $product_item->product_img,' class="upload"'); ?>
                            <?php echo form_hidden('old_img',$product_item->product_img); ?>
                             <br />
                            <p  style="border:2px solid; width:110px;">
                            <img src="<?php echo  base_url("../uploads/product_image/thumbs/").'/'.$product_item->product_img ?>" height="100" width="100" alt="<?php echo $product_item->product_img; ?>" /></p>

					</td>
				</tr>
				<tr>
					<td>
						<label >Content <span style="color:#f00">(Required Field)</span></label>
					</td>
					<td>
						<textarea class="form-control redactor" name="product_desc" rows="10" cols="60"><?php echo $product_item->product_desc; ?></textarea>
                           <?php
				  if(form_error('product_desc'))
					{
						?>
                         <div class="alert alert-danger ">  
				    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                  <span style="font-size:16px;"><?php echo form_error('product_desc'); ?>
                  </span>
                  </div>
                 
                        <?php 
							
					}?>
					</td>
				</tr>
				</table>		
							
							
					<input type="submit" class="btn bg-purple margin" value="Edit" />
					<?php echo form_close(); ?>
                
                </div><!-- /.box-body -->
              </div><!-- /.box -->
            </div><!-- /.col -->
          </div><!-- /.row -->
        </section><!-- /.content -->
   </div>