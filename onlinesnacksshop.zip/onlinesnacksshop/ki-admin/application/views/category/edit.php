<style type="text/css">	
input[type='text']    
{
	height: 35px;
	width: 180px;
	
}
.textarea    
{
	height: 65px;
	width: 180px;
	
}
.upload    
{
	height: 35px;
	width: 200px;
	
}
.drpdwn
{
	height: 35px;
	width: 180px;
	
}
.btn
{
	height: 40px;
	width: 180px;
	
}
td
{
	padding:5px;
}
</style>
<div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
			Edit category::
          
          </h1>
          <ol class="breadcrumb">
           <li><?php echo anchor('','<i class="fa fa-dashboard"></i> Dashbord'); ?></li>
              <li><?php echo anchor('category/category','<i class="fa fa-th fa-th-list"></i>Category'); ?></li>
            
            <li class="active">Edit Category</li>
          </ol>
        </section>

        <!-- Main content -->
        <section class="content">
          <div class="row">
            <div class="col-xs-12">
              <!-- /.box -->

              <div class="box">
                <div class="box-header">
				<h4><?php echo anchor('category/category/','<span><i class="fa fa-arrow-left"></i>&nbsp;Back To Category</span>','class="btn btn-primary"'); ?></h4>
                </div><!-- /.box-header -->
               
            
			
		<span>&nbsp;</span>
        <span>&nbsp;</span>
               
                
                  <?php
			if($this->session->userdata('imgerr'))
			{
				?>
                 <div class="alert alert-danger alert-dismissable">
                 <h4><i class="icon fa fa-ban"></i>Alert!</h4>
				    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                  <span style="font-size:16px;"><?php echo $this->session->userdata('imgerr'); ?>
                  </span>
                  </div>
                  
				<?php
				$this->session->unset_userdata('imgerr');
				
			}
			?>
                  
                <div class="box-body">
<?php echo form_open_multipart('category/category/edit/'."$category_item->category_id"); ?>
						
						<?php echo form_hidden('category_id',$category_item->category_id); ?>
				<table cellpadding="5">
				<tr>


					<td>
                		<label>Title <span style="color:#f00">(Required Field)</span></label>
					</td>
					<td>

						<input type="text" value="<?php echo $category_item->category_title; ?>" name="category_title" class="form-control" required="required" />
                         <?php if(form_error('category_title'))
									{
										?> 
									<div class="alert alert-danger ">
									<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
								  <span style="font-size:14px;"><?php  echo form_error('category_title'); ?>
								  </span>
								  </div>
							  <?php } ?>
					</td>
				</tr>
				<tr>
					<td>
							<label>Status <span style="color:#f00">(Required Field)</span></label>
					</td>
					<td>
							<select name="category_status" required="required" class="drpdwn form-control" >
							<option value="0" <?php if($category_item->category_status==0) { echo "selected"; } ?>>Disabled</option><option  value="1" <?php if($category_item->category_status==1) { echo "selected"; } ?>>Enabled</option></select>
					</td>
				</tr>
				<tr>
					<td>
							<label>Image <span style="color:#f00">(Required Field)</span></label>
					</td>
					<td>
					
							<?php echo form_upload('category_images', $category_item->category_img,' class="upload"'); ?>
                            <?php echo form_hidden('old_img',$category_item->category_img); ?>
                            <img src="<?php echo  base_url("../uploads/category_image/thumbs/").'/'.$category_item->category_img ?>" height="60" width="60" alt="<?php echo $category_item->category_img; ?>" />

					</td>
				</tr>
				<tr>
					<td>
						<label >Content <span style="color:#f00">(Required Field)</span></label>
					</td>
					<td>
						<textarea class="redactor form-control" value="" name="category_desc" rows="10" cols="60"><?php echo $category_item->category_desc; ?></textarea>
                         <?php if(form_error('category_desc'))
									{
										?> 
									<div class="alert alert-danger ">
									<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
								  <span style="font-size:14px;"><?php  echo form_error('category_desc'); ?>
								  </span>
								  </div>
							  <?php } ?>
					</td>
				</tr>
				</table>		
					<input type="submit" class="btn bg-purple margin" value="Edit" />
					<?php echo form_close(); ?>
                
                </div><!-- /.box-body -->
              </div><!-- /.box -->
            </div><!-- /.col -->
          </div><!-- /.row -->
        </section><!-- /.content -->
   </div>
