
<script>
$(document).ready(function() {
    $('#selecctall').click(function(event) {  //on click
        if(this.checked) { // check select status
            $('.checkbox1').each(function() { //loop through each checkbox
                this.checked = true;  //select all checkboxes with class "checkbox1"              
            });
        }else{
            $('.checkbox1').each(function() { //loop through each checkbox
                this.checked = false; //deselect all checkboxes with class "checkbox1"                      
            });        
        }
    });
   
});
</script>
<div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
			Category Section::
          
          </h1>
          <ol class="breadcrumb">
             <li><?php echo anchor('','<i class="fa fa-dashboard"></i> Dashbord'); ?></li>
              <li class="active"><?php echo anchor('category/category','<i class="fa fa-th fa-th-list"></i>Category'); ?></li>
            
          
          </ol>
        </section>

        <!-- Main content -->
        <section class="content">
          <div class="row">
            <div class="col-xs-12">
              <!-- /.box -->

              <div class="box">
                <div class="box-header">
                <?php echo form_open('category/category/multiple') ?>
				<h4><?php echo anchor('category/category/addcategory',"<span><i class='fa fa-fw fa-plus'></i>Add Category</span>",'class="btn btn-primary"'); ?></h4>
                </div><!-- /.box-header -->
               
                   <?php
			if($this->session->userdata('insert'))
			{
				?>
				 <div class="alert alert-success alert-dismissable">
                                  <h4><i class="icon fa fa-check"></i>Alert!</h4>
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                   <span style="font-size:16px; color:#000"> &nbsp;&nbsp;<?php echo $this->session->userdata('insert'); ?>
                   </span></div>
				<?php
				$this->session->unset_userdata('insert');
			
			}
		    if($this->session->userdata('del'))
			{
				?>
								 <div class="alert alert-success alert-dismissable">
                                                  <h4><i class="icon fa fa-check"></i>Alert!</h4>
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                   <span style="font-size:16px; color:#000"><?php echo $this->session->userdata('del'); ?>
                   </span></div>
				<?php
				$this->session->unset_userdata('del');
				echo "</p>";
			}
			if($this->session->userdata('edit'))
			{
				?>
								 <div class="alert alert-success alert-dismissable">
                                                  <h4><i class="icon fa fa-check"></i>Alert!</h4>
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                   <span style="font-size:16px; color:#000"><?php echo $this->session->userdata('edit'); ?>
                   </span></div>
				<?php

				$this->session->unset_userdata('edit');
				echo "</p>";
			}
		
			
		?>
		<span>&nbsp;</span>
        <span>&nbsp;</span>
               
                
                  <?php
			if($this->session->userdata('notfound'))
			{
				?>
                 <div class="alert alert-danger alert-dismissable">
                   <h4><i class="icon fa fa-ban"></i>Alert!</h4>
				    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                  <span style="font-size:16px;"><?php echo $this->session->userdata('notfound'); ?>
                  </span>
                  </div>
                  
				<?php
				$this->session->unset_userdata('notfound');
				
			}
			?>
                  
                <div class="box-body">
                  <table id="example1" class="table table-bordered table-striped">
                    <thead >
                      <tr >
                   
                       <th>Id</th>
                        <th>Title</th>
                        <th style="background:#fff">Category Images</th>
                        <th style="background:#fff">Status</th>
                        <th>Created</th>
                        <th style="background:#fff">Content Control</th>
                      </tr>
                    </thead>

                    <tbody>
                      <?php foreach ($category as $category_item){ ?>
							<tr>
							<?php echo form_hidden('category_id','15'); ?>
							
								<td><?php echo $category_item->category_id ?></td>
								<td><?php echo $category_item->category_title ?></td>
								<td align="center"><img src="<?php
                                if(file_exists("../uploads/category_image/thumbs/".$category_item->category_img))
								{?>
								 <?php echo base_url()."../uploads/category_image/thumbs/".'/'.$category_item->category_img ?>
								<?php 
								}
								else
								{
									?>
                                     <?php echo base_url("images/comingsoon.jpg")?>
                                    <?php 
								
								}
								?>
								"style="height:70px;width:70px" /></td>
								<td><?php if($category_item->category_status =="0") { echo "<span style='color:red'>Disabled</span>"; } else { echo "<span style='color:green'>Enabled</span>"; }?></td>
								<td><?php echo $category_item->category_created ?></td>
								 <td><a href="<?php echo site_url('category/category/delete').'/'. $category_item->category_id ?>" onclick="return confirm('Are You Sure?');"><img src="<?php echo base_url('/images/delete.gif'); ?>" height="40" width="60" /></a>&nbsp;
								 

								 <a href="<?php echo site_url('category/category/edit').'/'. $category_item->category_id ?>"><img src="<?php echo base_url('/images/edit.gif'); ?>" height="40" width="60" /></a>&nbsp;</a>&nbsp;&nbsp;<a href="<?php echo site_url('category/category/view').'/'. $category_item->category_id ?>"><img src="<?php echo base_url('/images/view.gif'); ?>" height="40" width="60" /></a></td>
							</tr>
							<?php } ?>
                      </form>
                    </tbody>
                    
                  </table>
                </div><!-- /.box-body -->
              </div><!-- /.box -->
            </div><!-- /.col -->
          </div><!-- /.row -->
        </section><!-- /.content -->
      </div>
    
