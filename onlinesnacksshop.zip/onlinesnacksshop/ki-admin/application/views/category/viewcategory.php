<style>
td
{
	padding:20px;
}
tr
{

}
</style>


    
<div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
			category Section::
          
          </h1>
          <ol class="breadcrumb">
            <li><?php echo anchor('','<i class="fa fa-dashboard"></i> Dashbord'); ?></li>
              <li><?php echo anchor('category/category','<i class="fa fa-th fa-th-list"></i>Category'); ?></li>
            
            <li class="active">Category List</li>
          </ol>
        </section>

        <!-- Main content -->
        <section class="content">
          <div class="row">
            <div class="col-xs-12">
              <!-- /.box -->

              <div class="box">
                <div class="box-header">
				<h4><?php echo anchor('category/category/','<span><i class="fa fa-arrow-left"></i>&nbsp;Back to Category</span>','class="btn btn-primary"'); ?></h4>
                </div><!-- /.box-header -->
               
                 
                <div class="box-body">
						<div id="tbl">
	

							<img src="<?php echo  base_url("../uploads/category_image/thumbs/").'/'.$category_item->category_img ?>" alt="<?php echo $category_item->category_img; ?>" width="200" />
						
</div>
<div id="tbl1">

					<table>
						<tr>
							<td>Title:-</td>
							<td><span><?php echo $category_item->category_title ?></span></td>
						</tr>
						<tr>
							<td valign="top">Description:-</td>
							<td><span><?php echo $category_item->category_desc ?></span></td>
						</tr>
					
						<tr>
							<td>Status :-</td>
							<td><span><?php if($category_item->category_status =="0") { echo "Disabled"; } else { echo "Enabled"; } ?></span></td>
						</tr>
						
						
					</table>	
</div>                  
                </div><!-- /.box-body -->
              </div><!-- /.box -->
            </div><!-- /.col -->
          </div><!-- /.row -->
        </section><!-- /.content -->
      </div>


