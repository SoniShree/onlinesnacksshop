<script type="text/javascript" charset="utf-8">
			$(document).ready(function() 
			{
				$('#dailydiv').hide();
				$('#weeklydiv').hide();
				$('#yearllydiv').hide();
				
				
				
				$('#dailybtn').click(function() 
				{
					
					$('#dailydiv').fadeToggle(1000);
					$('#weeklydiv').hide();
					$('#yearllydiv').hide();
					
				});
				
				
			});
		</script>

<div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
			Reports::
          
          </h1>
          <ol class="breadcrumb">
            <li><?php echo anchor('','<i class="fa fa-dashboard"></i> Dashbord'); ?></li>
            <li class="active">Report List</li>
          </ol>
        </section>

        <!-- Main content -->
        <section class="content">
          <div class="row">
            <div class="col-xs-12">
              <!-- /.box -->

              <div class="box">
                <div class="box-header" >
                </div><!-- /.box-header -->
             
                <div class="box-body" >
                <div>
            
              <h4><address>
              <?php echo form_open(''); ?>
                <strong>Weekly Report:</strong><br>
                <select name="Weekly" class="form-control margin" style="width:200px;">
                 <option value="jan" >January</option>
                 <option value="feb" >February</option>
                 <option value="mar" >March</option>
				<option value="april" >April</option>
				<option value="may" >May</option>
				<option value="june" >June</option>
				<option value="july" >July</option>
				<option value="aug" >August</option>
				<option value="sep" >September</option>
				<option value="oct" >October</option>
				<option value="nov" >November</option>
 				<option value="dec" >December</option>
                 </select>
                 
			<h4><?php echo form_submit('',"Check Status",'class="btn bg-purple margin"'); ?></h4>
               
              </address></h4>
            </div>
    
            <div>
                <?php echo form_open(''); ?>
                 <h4> <strong>Yearlly Report: </strong ></h4>

                 <select name="Yearlly" class="form-control margin" style="width:200px;">
                 
                 </select>
			<h4><?php echo form_submit('',"Check Status",'class="btn bg-purple margin"'); ?></h4>
            </div>

                </div><!-- /.box-body -->
              </div><!-- /.box -->
            </div><!-- /.col -->
          </div><!-- /.row -->
        </section><!-- /.content -->
      </div>
