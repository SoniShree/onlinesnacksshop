<html>
<head>
<title><?php echo $title ?></title>
</head>

<body onload="window.print();">
<div style="font-size:12px; font-family:arial, verdana, sans-serif;">
  <h2></h2>
  <table style="border:1px solid #000; width:100%; font-size:13px;" cellpadding="5" cellspacing="0">
    <tr>
      <td style="width:20%; vertical-align:top;" >
      <strong style="font-size:20px;">Deliverd By:</strong><br>
        <br>
        Pragnya Food Products,<br>
        Kadodra,Surat.<br>
        Phone: +91-9377712229 <br/>
        Email: info@pragnyafoodproducts.com
        </address>
        </h4>
      </td>
      <td style="width:30%; vertical-align:top;"><strong style="font-size:20px;">Bill To Address</strong><br>
        <br>
        <?php echo ucfirst($allrec->bill_firstname); echo nbs(); echo ucfirst($allrec->bill_lastname); ?><br>
        <?php echo ucfirst($allrec->bill_address1);?><br>
        Phone: <?php echo $allrec->bill_phone;?><br/>
        Email: <?php echo $allrec->bill_email;?>
        </address>
        </h4></td>
      <td style="width:30%; vertical-align:top;" class="packing"><strong style="font-size:20px;">Ship To Address</strong><br>
        <br>
        <?php echo ucfirst($allrec->ship_firstname); echo nbs(); echo ucfirst($allrec->bill_lastname); ?><br>
        <?php echo ucfirst($allrec->ship_address1);?><br>
        Phone: <?php echo $allrec->ship_phone;?><br/>
        Email: <?php echo $allrec->ship_email;?>
        </address>
        </h4>
        <br/></td>
    </tr>
    <tr>
    
      <td style="border-top:1px solid #000;"></td>
      <td style="border-top:1px solid #000;"><strong>Payment Method&nbsp;:-&nbsp;</strong><span>Cash On Delivery</span></td>
      <td style="border-top:1px solid #000;"><strong>Shipping Charge&nbsp;:-&nbsp;</strong> <?php echo $allrec->shipping ?></td>
    </tr>
  </table>
  <table border="1" style="width:100%; margin-top:10px; border-color:#000; font-size:13px; border-collapse:collapse;" cellpadding="5" cellspacing="0">
    <thead>
      <tr>
        <th width="15%" class="packing"> Name </th>
        <th class="packing" > Price </th>
        <th class="packing" >Quantity</th>
        <th class="packing" >Total</th>
        <th class="packing" >Ordered On</th>
      </tr>
    </thead>
    <?php
				  foreach($allrec_items as $obj)
                                    { ?>
    <tr>
      <td class="packing" style="font-size:15px; text-align:center; "><?php echo $obj->product_name;?></td>
      <td  class="packing" style="font-size:15px; text-align:center; "><?php echo $obj->product_price?></td>
      <td  class="packing" style="font-size:15px;text-align:center; "><?php echo $obj->quantity;?></td>
      <td  class="packing" style="font-size:15px;  text-align:center; "><?php echo $obj->total?></td>
      <td  class="packing" width="20%" style="font-size:15px;  text-align:center; "><?php echo $allrec->ordered_on;?></td>
    </tr>
    <?php } ?>
    <tfoot>
      <tr>
        <th width="15%" class="packing" style="font-size:25px;">Grand Total :</th>
        <th>&nbsp;</th>
        <th>&nbsp;</th>
        <th  style="font-size:25px;"> <?php echo $allrec->g_total;?></th>
        <th>&nbsp;</th>
      </tr>
    </tfoot>
  </table>
</div>
</html>