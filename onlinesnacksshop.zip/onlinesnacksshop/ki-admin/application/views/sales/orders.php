<div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
			Orders::
          
          </h1>
          <ol class="breadcrumb">
            <li><?php echo anchor('','<i class="fa fa-dashboard"></i> Dashbord'); ?></li>
              <li><?php echo anchor('sales/orders','<i class="fa fa-th fa-th-list"></i>Orders'); ?></li>
            <li class="active">Order List</li>
          </ol>
        </section>

        <!-- Main content -->
        <section class="content">
          <div class="row">
            <div class="col-xs-12">
              <!-- /.box -->

              <div class="box">
                <div class="box-header">
                </div><!-- /.box-header -->
               <?php 
                 if($this->session->userdata('del'))
			{
				?>
								 <div class="alert alert-success alert-dismissable">
                                                  <h4><i class="icon fa fa-check"></i>Alert!</h4>
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                   <span style="font-size:16px; color:#000"><?php echo $this->session->userdata('del'); ?>
                   </span></div>
				<?php
				$this->session->unset_userdata('del');

			}  ?>
             <?php 
                 if($this->session->userdata('msg'))
			{
				?>
								 <div class="alert alert-success alert-dismissable">
                                                  <h4><i class="icon fa fa-check"></i>Alert!</h4>
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                   <span style="font-size:16px; color:#000"><?php echo $this->session->userdata('msg'); ?>
                   </span></div>
				<?php
				$this->session->unset_userdata('msg');

			}  ?>
            <?php 
                 if($this->session->userdata('err'))
			{
				?>
								 <div class="alert alert-success alert-dismissable">
                                                  <h4><i class="icon fa fa-check"></i>Alert!</h4>
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                   <span style="font-size:16px; color:#000"><?php echo $this->session->userdata('err'); ?>
                   </span></div>
				<?php
				$this->session->unset_userdata('err');

			}  ?>
                <div class="box-body">
                  <table id="example1" class="table table-bordered table-striped">
                    <thead >
                      <tr >
                   <!-- <th style="background:#fff"><input type="checkbox" name="chk" onclick='ToggleAll(this);'/></th>-->
                       <th >Id</th>
                        <th>Bill To</th>
                        <th style="background:#fff">Ship To</th>
                        <th style="background:#fff">Order On</th>
                        <th>Status</th>
                        <th style="background:#fff">Total</th>
                        <th style="background:#fff">View Order</th>
                      </tr>
                    </thead>
                  
                    <tbody>
                      <?php
			   foreach($orders as $order)
			   {
			    ?>
                    <tr>
                      <td><?php echo $order->id; ?></td>
                      <td><?php echo $order->bill_firstname; echo nbs();echo $order->bill_lastname; ?></td>
                      <td><?php echo $order->ship_firstname; echo nbs();echo $order->ship_lastname; ?></td>
                      <td><?php echo $order->ordered_on; ?></td>
                      <td>
                      <?php echo form_open("sales/orders/update_status/$order->id") ?>
                       <select name="status"  class="form-control">
                <option value="orderplaced" <?php if($order->status=="orderplaced"){ echo "selected"; } else { echo ""; } ?> >Order Placed</option>
                <option value="pending" <?php if($order->status=="pending"){ echo "selected"; } else { echo ""; } ?>>Pending</option>
                <option value="processing" <?php if($order->status=="processing"){ echo "selected"; } else { echo ""; } ?>>Processing</option>
                <option value="shipped" <?php if($order->status=="shipped"){ echo "selected"; } else { echo ""; } ?>>Shipped</option>
              
                <option value="cancelled" <?php if($order->status=="cancelled"){ echo "selected"; } else { echo ""; } ?>>Cancelled</option>
                <option value="delivered" <?php if($order->status=="delivered"){ echo "selected"; } else { echo ""; } ?>>Delivered</option>
                </select>
					  <button class="btn btn-default">Save</button>
                      <?php echo form_close(); ?>
                      </td>
                      <td><?php echo $order->g_total; ?>&nbsp;&nbsp;<i class="fa fa-rupee"></i></td>
                      <td>
                      
                      <a href="<?php echo site_url('sales/orders/invoice').'/'. $order->id; ; ?>">
                      
                      <img src="<?php echo base_url('/images/view.gif'); ?>" height="40" width="60" /></a>
                      
                      
                      </td>
                      </tr>
                  
                <?php } ?>
                  </tbody>
                  </table>
                 	<?php echo form_close();?>
                </div><!-- /.box-body -->
              </div><!-- /.box -->
            </div><!-- /.col -->
          </div><!-- /.row -->
        </section><!-- /.content -->
      </div>
