
      <!-- Left side column. contains the logo and sidebar -->
<style>
.roww{margin-left:-20px;*zoom:1;width:80%}.row:before,.row:after{display:table;line-height:0;content:""}.row:after{clear:both}[class*="span"]{float:left;margin-left:20px}
.span12{width:940px}
</style>
<script type="text/javascript" charset="utf-8">
			$(document).ready(function() 
			{
				$('#notification_form').hide();
				
				
				
				$('#sendemail').click(function() 
				{
					
					$('#notification_form').fadeToggle(1000);
					
					
				} 	);
				
				
			} );
		</script>
<script>
// store message content in JS to eliminate the need to do an ajax call with every selection

// use our customer names var to update the customer name in the template
function update_name()
{
    if($('#sub_messages').val().length>0)
    {
        set_canned_message($('#sub_messages').val());
    }
}

function set_canned_message(id)
{
    // update the customer name variable before setting content 
    $('#msg_subject').val("Your order has shipped !");
    //$('#content_editor').redactor('insertHtml', messages[id]['content'].replace(/{customer_name}/g, customer_names[$('#recipient_name').val()]));
}   
</script>
  <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
          &nbsp;&nbsp; <i class="fa fa-globe"></i> Invoice
           
          </h1>
          <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="#">Ordres</a></li>
            <li class="active">Invoice</li>
          </ol>
        </section>
      <!--  <div class="pad margin no-print">
          <div class="callout callout-info" style="margin-bottom: 0!important;">												
            <h4><i class="fa fa-info"></i> Note:</h4>
            This page has been enhanced for printing. Click the print button at the bottom of the invoice to test.
          </div>
        </div>

        <!-- Main content -->
        
        <?php if($allrec) {
			
			 ?>
		
        <section class="invoice">
          <!-- title row -->
          <div class="row">
            <div class="col-xs-12">
              <h2 class="page-header">
              <?php echo anchor('sales/orders',"<span><span><i class='fa fa-fw fa-arrow-left'></i>&nbsp;Back To Orders</span>",'class="btn btn-primary"'); ?>
                &nbsp;&nbsp;<i class="fa fa-globe"></i> View Order&nbsp;&nbsp;
                 <span class="pull-right"  style="font-size:15px;">&nbsp;&nbsp;&nbsp;Date: <?php echo $allrec->ordered_on ?></span>&nbsp;&nbsp;
              <?php echo anchor("sales/orders/packing/$allrec->id","<i class='fa fa-print'></i>Print Slip",'class="btn btn-default pull-right" target=_blank'); ?>&nbsp;&nbsp;&nbsp;
              <span class="btn btn-default pull-right" id="sendemail"><i class='fa fa-fw fa-envelope'></i>Send Email Notification</span>
                          
             
              </h2>
                <?php 
                 if($this->session->userdata('msg'))
			{
				?>
								 <div class="alert alert-success alert-dismissable">
                                                  <h4><i class="icon fa fa-check"></i>Alert!</h4>
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                   <span style="font-size:16px; color:#000"><?php echo $this->session->userdata('msg'); ?>
                   </span></div>
				<?php
				$this->session->unset_userdata('msg');

			}  ?>
               <?php 
                 if($this->session->userdata('email'))
			{
				?>
								 <div class="alert alert-success alert-dismissable">
                                                  <h4><i class="icon fa fa-check"></i>Alert!</h4>
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                   <span style="font-size:16px; color:#000"><?php echo $this->session->userdata('email'); ?>
                   </span></div>
				<?php
				$this->session->unset_userdata('email');

			}  ?>
            </div><!-- /.col -->
          </div>
          <!-- info row -->
          <div class="row invoice-info">
          

<div id="notification_form" class="col-lg-7"  style="display:none;width:80%">
 
 <div class="box box-info">
                <div class="box-header ui-sortable-handle">
                  <i class="fa fa-envelope"></i>
                  <h3 class="box-title">Send Email</h3>
                  <!-- tools box -->
                  <div class="pull-right box-tools">
                 
                  </div><!-- /. tools -->
                </div>
                <div class="box-body">
         
        <form action="<?php echo site_url('sales/orders/sndmail'); ?>" method="post" accept-charset="utf-8">
        <input type="hidden" value="<?php echo $allrec->id ?>" name="id" />
                <label>Recipient: </label>
                 <div class="input-group">
                <select name="recipient" required="required"  style="width:530px"  class='form-control'>
                    <option value="<?php echo $allrec->customer_email ?>">Account Main Email (<?php echo $allrec->customer_email ?>)</option><option value="<?php echo $allrec->ship_email ?>">Shipping Email (<?php echo $allrec->ship_email ?>) </option></select>

                      </div>
               
               
                <label>Subject: </label>
                 <div class="input-group">
				                <input  type="text" name="subject" style="width:530px" value="Your order has shipped !" id="msg_subject" class="form-control"/>
                      </div>



                <label>Message: </label>
                <div class="input-group">
                <textarea class="redactor form-control" style="resize:none;" rows="10" cols="100" name="content">
Dear <?php echo ucfirst($allrec->customer_fname); ?> <?php echo ucfirst($allrec->customer_lname); ?>,<br /><br /><br />

Thank you for your purchase at !<br />

This message is to inform you that your order (<?php echo $allrec->order_number; ?>) has been shipped.<br />

Enjoy your purchase!
                
                </textarea>
                      </div>

<br />
                <div class="box-footer clearfix">
                  <button type="submit" class="pull-right btn btn-default" id="sendEmail">Send <i class="fa fa-arrow-circle-right"></i></button>
                </div>
        </form>
   </div>
                
              </div>
    <!---->
</div>


            <div class="col-sm-4 invoice-col">
            
              <h4><address>
                <strong>Account Info</strong><br>
                <?php echo ucfirst($allrec->customer_fname); echo nbs(); echo ucfirst($allrec->customer_lname); ?><br>
                Phone: <?php echo $allrec->customer_mobile;?><br/>
                Email: <?php echo $allrec->customer_email;?>
              </address></h4>
            </div><!-- /.col -->
            <div class="col-sm-4 invoice-col">
              <h4><address>
                <strong>Billing Address</strong><br>
                <?php echo ucfirst($allrec->bill_firstname); echo nbs(); echo ucfirst($allrec->bill_lastname); ?><br>
                <?php echo ucfirst($allrec->bill_address1);?><br>
				Phone: <?php echo $allrec->bill_phone;?><br/>
                Email: <?php echo $allrec->bill_email;?>
              </address></h4>
            </div><!-- /.col -->
            <div class="col-sm-4 invoice-col">
              <h4><address>
                <strong>Shipping Address</strong><br>
                <?php echo ucfirst($allrec->ship_firstname); echo nbs(); echo ucfirst($allrec->ship_lastname); ?><br>
                <?php echo ucfirst($allrec->ship_address1);?><br>
				Phone: <?php echo $allrec->ship_phone;?><br/>
                Email: <?php echo $allrec->ship_email;?>
              </address></h4>
            </div><!-- /.col -->
          </div><!-- /.row -->
			<div class="row">
            <!-- accepted payments column -->
          <div class="col-xs-6">
             <p class="lead"> <b>Admin Notes:</b></p>
            <?php echo form_open("sales/orders/addnotes/$allrec->id"); ?>
              <p class="text-muted well well-sm no-shadow" style="margin-top: 10px;">
               <textarea class="form-control" style="resize: none;" name="notes" cols="69" style="border-radius:10px;" no-resize ><?php echo $allrec->notes; ?></textarea>
              </p>
            </div><!-- /.col -->
           <div class="col-xs-6">
              <p class="lead"><b>Status:</b></p>
              <div>
               
                <select name="status"  class="form-control">
                <option value="orderplaced" <?php if($allrec->status=="orderplaced"){ echo "selected"; } else { echo ""; } ?> >Order Placed</option>
                <option value="pending" <?php if($allrec->status=="pending"){ echo "selected"; } else { echo ""; } ?>>Pending</option>
                <option value="processing" <?php if($allrec->status=="processing"){ echo "selected"; } else { echo ""; } ?>>Processing</option>
                <option value="shipped" <?php if($allrec->status=="shipped"){ echo "selected"; } else { echo ""; } ?>>Shipped</option>
              
                <option value="cancelled" <?php if($allrec->status=="cancelled"){ echo "selected"; } else { echo ""; } ?>>Cancelled</option>
                <option value="delivered" <?php if($allrec->status=="delivered"){ echo "selected"; } else { echo ""; } ?>>Delivered</option>
                </select>
                <br><br>
                 <button type="submit"  class="btn bg-purple margin pull-right">&nbsp;&nbsp;Update Order</button>            
                 <?php echo form_close(); ?>
            </div>
            </div><!-- /.col -->
          </div><!-- /.row -->
		
          <!-- this row will not appear when printing -->
<br>
          <!-- Table row -->
          <div class="row">
            <div class="col-xs-12 table-responsive">
            <h3><strong>Orders:</strong></h3>
              <table class="table table-striped">
                <thead>
                 <tr>
                    <th>Name</th>
                   <th>Image</th>
                   <th>Price</th>
                   <th>Quantity</th>
                   <th>Total</th>
                  
                     <th>Ordered On</th>
                  </tr>
                </thead>
                <tbody>
               
               		 <?php
				  foreach($allrec_items as $obj)
                                    { ?> 
                  <tr>
                 
                    <td> <?php echo $obj->product_name;?></td>
                     <td>
                     <img src="
								<?php
								if(file_exists("../uploads/product_image/thumbs/".$obj->img))
								{?>
								 <?php echo base_url("../uploads/product_image/thumbs/").'/'. $obj->img?>
								<?php 
								}
								else
								{
									?>
                                     <?php echo base_url("images/comingsoon.jpg")?>
                                    <?php 
								
								}
								?>
								"style="height:70px;width:70px" />
                     
                     </td>
                    <td> <?php echo $obj->product_price?></td>                    
                    <td> <?php echo $obj->quantity;?></td>
                    <td> <?php echo $obj->total?></td>
                 
                    <td> <?php echo $allrec->ordered_on;?></td>
                  </tr>
                  <?php } ?>
                  </tbody>
                  <tfoot>
                  <tr>
                  <td>&nbsp;
                  
                  </td>
                  </tr>
                 <tr>
                 
                   <th>Grand Total :</th>
                   <th>&nbsp;</th>
                   <th>&nbsp;</th>
                   <th>&nbsp;</th>
                   <th> <?php echo $allrec->g_total;?></th>
                  
                     <th>&nbsp;</th>
                  </tr>
                </tfoot>
                    </table>
               
              	<?php } ?><hr />
                
                 

 

                <br />
            </div><!-- /.col -->
          </div><!-- /.row -->

                    <div class="row no-print">
         <div class="col-xs-12">

              <?php echo anchor("sales/orders/packing/$allrec->id","<i class='fa fa-print'></i>Print Slip",'class="btn btn-default" target=_blank');  ?>
             
              <a href="<?php echo site_url("sales/orders/getpdf/$allrec->id"); ?>" class="btn btn-primary pull-right"  target="_blank" style="margin-right: 5px;" > <i class="fa fa-download"></i> Generate PDF</a>
             
            </div>
          </div>
        </section><!-- /.content -->
        <div class="clearfix"></div>
      </div><!-- /.content-wrapper -->