
    
    
<div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
			Product Reports Section::
          
          </h1>
          <ol class="breadcrumb">
             <li><?php echo anchor('','<i class="fa fa-dashboard"></i> Dashbord'); ?></li>
              <li class="active"><?php echo anchor('reports/product_reports','<i class="fa fa-th fa-th-large"></i>Product Reports'); ?></li>
           
          </ol>
        </section>

        <!-- Main content -->
        <section class="content">
          <div class="row">
            <div class="col-xs-12">
              <!-- /.box -->

              <div class="box">
              <div class="box-header">
			  <?php
			  	echo form_open('reports/product_reports/getPdf','target="_blank"');
			   echo form_submit('',"Convert to PDF",'class="btn btn-primary"'); ?>
              </form>
				</div><!-- /.box-header -->
   
                  <?php
			if($this->session->userdata('notfound'))
			{
				?>
                 <div class="alert alert-danger alert-dismissable">
                   <h4><i class="icon fa fa-ban"></i>Alert!</h4>
				    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                  <span style="font-size:16px;"><?php echo $this->session->userdata('notfound'); ?>
                  </span>
                  </div>
                  
				<?php
				$this->session->unset_userdata('notfound');
				
			}
			?>
                  
                <div class="box-body">
                  <table id="example1" class="table table-bordered table-striped">
                    <thead >
                      <tr>
                      
                       <th >Id</th>
                        <th>Title</th>
                        <th style="background:#fff">Product Images</th>
						<th style="background:#fff">Product Stock Quantity</th>
                        <th style="background:#fff">Product Sold Quantity</th>
						<th>Price</th>
                        <th style="background:#fff">Status</th>
                        <th>Total Amount</th>
                        </tr>
                    </thead>
                    <tbody >
                      <?php 
					  if(!is_array($product))
					  {
						  echo"<tr><td colspan='7'>".$product."</td></tr>";
					  }
					  else
					  {
						  $i=0;  
					  foreach ($product as $product_item){ ?>
							<tr >
					
								<td><?php echo $product_item['product_id'] ?></td>
								<td><?php echo $product_item['product_title'] ?></td>
								<td><img src="<?php echo base_url("../uploads/product_image/").'/'.$product_item['product_img'] ?>" height="50" width="70" alt="<?php echo $product_item['product_title']; ?>" /></td>
                                <td><?php echo $product_item['product_qty'] ?></td>
                                <td><?php echo $total[$i]?></td>
                                <td><?php echo $product_item['product_price'] ?></td>
								<td><?php if($product_item['product_status'] =="0") { echo "Disabled"; } else { echo "Enabled"; }?></td>
                                 <td><?php echo $product_item['product_price']*$total[$i] ?></td>
						</tr>
							<?php $i++;
							}
					  }?>
                      
                    </tbody>
                   
                  </table>
                  </form>
                </div><!-- /.box-body -->
              </div><!-- /.box -->
            </div><!-- /.col -->
          </div><!-- /.row -->
        </section><!-- /.content -->
      </div>
     
