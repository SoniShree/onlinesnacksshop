<style>
tbl
{
	width:250px;
	float:left;
}
tbl1
{
		width:250px;
	float:left;
}
</style>


    
<div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
			News Section::
          
          </h1>
          <ol class="breadcrumb">
          <li><?php echo anchor('','<i class="fa fa-dashboard"></i> Dashbord'); ?></li>
              <li><?php echo anchor('news/news','<i class="fa fa-th fa-th-list"></i>News'); ?></li>
            <li class="active">News List</li>
          </ol>
        </section>

        <!-- Main content -->
        <section class="content">
          <div class="row">
            <div class="col-xs-12">
              <!-- /.box -->

              <div class="box">
                <div class="box-header">
					<h4><?php echo anchor('news/news/',"<i class='fa fa-fw fa-arrow-left'></i>&nbsp;Back To News",'class="btn btn-primary"'); ?></h4>
                </div><!-- /.box-header -->
               
                 
                <div class="box-body">
						<div id="tbl">
	

							<img src="<?php echo  base_url("../uploads/news_image/thumbs/").'/'.$news_item->news_img ?>" alt="<?php echo $news_item->news_img; ?>" width="200" />
						
</div>
<div id="tbl1">

					<table cellspacing="40">
						<tr>
							<td><span>Title :-</span></td>
							<td><span><?php echo $news_item->news_title ?></span></td>
						</tr>
						<tr>
								<td valign="top">Description :-</td>
							<td><span><?php echo $news_item->news_desc ?></span></td>
						</tr>
					
						<tr>
							<td><span>Status :-</span></td>
							<td><span><?php if($news_item->news_status =="0") { echo "Disabled"; } else { echo "Enabled"; } ?></span></td>
						</tr>
						
						
					</table>	
</div>                  
                </div><!-- /.box-body -->
              </div><!-- /.box -->
            </div><!-- /.col -->
          </div><!-- /.row -->
        </section><!-- /.content -->
      </div>


