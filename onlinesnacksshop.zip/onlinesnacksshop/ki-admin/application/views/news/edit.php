<style type="text/css">	

.btn
{
	height: 40px;
	width: 180px;
	
}
td
{
	padding:5px;
}
</style>
<div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
			Edit News::
          
          </h1>
          <ol class="breadcrumb">
         <li><?php echo anchor('','<i class="fa fa-dashboard"></i> Dashbord'); ?></li>
              <li><?php echo anchor('news/news','<i class="fa fa-th fa-th-list"></i>News'); ?></li>
            <li class="active">Edit News </li>
          </ol>
        </section>

        <!-- Main content -->
        <section class="content">
          <div class="row">
            <div class="col-xs-12">
              <!-- /.box -->

              <div class="box">
                <div class="box-header">
				<h4><?php echo anchor('news/news/',"<i class='fa fa-fw fa-arrow-left'></i>&nbsp;Back To News",'class="btn btn-primary"'); ?></h4>
                </div><!-- /.box-header -->
               
            
			
		<span>&nbsp;</span>
        <span>&nbsp;</span>
               
                
                  <?php
				
			if($this->session->userdata('imgerr'))
			{
				?>
                 <div class="alert alert-danger alert-dismissable">
                 <h4><i class="icon fa fa-ban"></i>Alert!</h4>
				    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                  <span style="font-size:16px;"><?php echo $this->session->userdata('imgerr'); ?>
                  </span>
                  </div>
                  
				<?php
				$this->session->unset_userdata('imgerr');
				
			}
			?>
                  
                <div class="box-body">
<?php echo form_open_multipart('news/news/edit/'."$news_item->news_id"); ?>
						
						<?php echo form_hidden('news_id',$news_item->news_id); ?>
				<table cellpadding="5">
				<tr>


					<td>
                		<label>Title <span style="color:#f00">(Required Field)</span></label>
					</td>
					<td>

						<input type="text" required="required" value="<?php echo $news_item->news_title; ?>" name="news_title" class="form-control" />
                           <?php
				  if(form_error('news_title'))
					{
						?>
                         <div class="alert alert-danger ">  
				    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                  <span style="font-size:16px;"><?php echo form_error('news_title'); ?>
                  </span>
                  </div>
                 
                        <?php 
							
					}?>
					</td>
				</tr>
				<tr>
					<td>
							<label>Status <span style="color:#f00">(Required Field)</span></label>
					</td>
					<td>
							<select name="news_status" required="required" class="drpdwn form-control" >
							<option value="0" <?php if($news_item->news_status==0) { echo "selected"; } ?>>Disabled</option><option  value="1" <?php if($news_item->news_status==1) { echo "selected"; } ?>>Enabled</option></select>
					</td>
				</tr>
				<tr>
					<td>
							<label>Image <span style="color:#f00">(Required Field)</span></label>
					</td>
					<td>
					
							<?php echo form_upload('news_images', $news_item->news_img,' class="upload"'); ?>
                            <?php echo form_hidden('old_img',$news_item->news_img); ?>
                            <br />
                            <p  style="border:2px solid; width:105px;">
                            <img src="<?php echo  base_url("../uploads/news_image/thumbs/").'/'.$news_item->news_img ?>" height="100" width="100" alt="<?php echo $news_item->news_img; ?>" /></p>

					</td>
				</tr>
				<tr>
					<td>
						<label >Content <span style="color:#f00">(Required Field)</span></label>
					</td>
					<td>
						<textarea class="form-control redactor" name="news_desc" rows="10" cols="60"><?php echo $news_item->news_desc; ?></textarea>
                        <?php
				  if(form_error('news_desc'))
					{
						?>
                         <div class="alert alert-danger ">  
				    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                  <span style="font-size:16px;"><?php echo form_error('news_desc'); ?>
                  </span>
                  </div>
                 
                        <?php 
							
					}?>
                        
					</td>
				</tr>
				</table>		
							
							
					<input type="submit" class="btn bg-purple margin" value="Edit" />
					<?php echo form_close(); ?>
                
                </div><!-- /.box-body -->
              </div><!-- /.box -->
            </div><!-- /.col -->
          </div><!-- /.row -->
        </section><!-- /.content -->
   </div>
