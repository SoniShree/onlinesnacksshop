  <script>					
			var checked = false;
			function ToggleAll(source) 
			{
				checkboxes = document.getElementsByName('chk[]');
				for(var i=0, n=checkboxes.length;i<n;i++) 
				{
					checkboxes[i].checked = source.checked;
				}
			}					
		</script>
<div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
			News Section::
          
          </h1>
          <ol class="breadcrumb">
            <li><?php echo anchor('','<i class="fa fa-dashboard"></i> Dashbord'); ?></li>
              <li class="active"><?php echo anchor('news/news','<i class="fa fa-th fa-th-list"></i>News'); ?></li>
            
          </ol>
        </section>

        <!-- Main content -->
        <section class="content">
          <div class="row">
            <div class="col-xs-12">
              <!-- /.box -->

              <div class="box">
                <div class="box-header">
                <?php echo form_open('news/news/checkbox');?>
				<h4><?php echo anchor('news/news/addnews',"<span><i class='fa fa-fw fa-plus'></i>Add News</span>",'class="btn btn-primary"'); ?>
				
				</h4>
                </div><!-- /.box-header -->
               
                   <?php
			if($this->session->userdata('insert'))
			{
				?>
				 <div class="alert alert-success alert-dismissable">
                                  <h4><i class="icon fa fa-check"></i>Alert!</h4>
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                   <span style="font-size:16px; color:#000"> &nbsp;&nbsp;<?php echo $this->session->userdata('insert'); ?>
                   </span></div>
				<?php
				$this->session->unset_userdata('insert');
			
			}
		    if($this->session->userdata('del'))
			{
				?>
								 <div class="alert alert-success alert-dismissable">
                                                  <h4><i class="icon fa fa-check"></i>Alert!</h4>
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                   <span style="font-size:16px; color:#000"><?php echo $this->session->userdata('del'); ?>
                   </span></div>
				<?php
				$this->session->unset_userdata('del');

			}
			if($this->session->userdata('edit'))
			{
				?>
								 <div class="alert alert-success alert-dismissable">
                                                  <h4><i class="icon fa fa-check"></i>Alert!</h4>
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                   <span style="font-size:16px; color:#000"><?php echo $this->session->userdata('edit'); ?>
                   </span></div>
				<?php

				$this->session->unset_userdata('edit');

			}
		
			
		?>
		<span>&nbsp;</span>
        <span>&nbsp;</span>
               
                
                  <?php
			if($this->session->userdata('notfound'))
			{
				?>
                 <div class="alert alert-danger alert-dismissable">
                   <h4><i class="icon fa fa-ban"></i>Alert!</h4>
				    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                  <span style="font-size:16px;"><?php echo $this->session->userdata('notfound'); ?>
                  </span>
                  </div>
                  
				<?php
				$this->session->unset_userdata('notfound');
				
			}
			?>
                  
                <div class="box-body">
                  <table id="example1" class="table table-bordered table-striped">
                    <thead >
                      <tr >
                   <!-- <th style="background:#fff"><input type="checkbox" name="chk" onclick='ToggleAll(this);'/></th>-->
                       <th >Id</th>
                        <th>Title</th>
                        <th style="background:#fff">News Images</th>
                        <th style="background:#fff">Status</th>
                        <th>Created</th>
                        <th style="background:#fff">Content Control</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php foreach ($news as $news_item){ ?>
							<tr>

							<!-- <td><input type="checkbox" name="chk[]" id="chk" value="<?php echo $news_item->news_id;?>"/></td>-->
								<td><?php echo $news_item->news_id ?></td>
								<td><?php echo $news_item->news_title ?></td>
								<td align="center"><img src="
								<?php
								if(file_exists("../uploads/news_image/thumbs/".$news_item->news_img))
								{?>
								 <?php echo base_url("../uploads/news_image/thumbs/").'/'.$news_item->news_img ?>
								<?php 
								}
								else
								{
									?>
                                     <?php echo base_url("images/comingsoon.jpg")?>
                                    <?php 
								
								}
								?>
								"style="height:70px;width:70px" /></td>
								<td><?php if($news_item->news_status =="0"){ echo "<span style='color:red'>Disabled</span>"; } else { echo "<span style='color:green'>Enabled</span>"; }?></td>
								<td><?php echo $news_item->news_created ?></td>
								 <td><a href="<?php echo site_url('news/news/delete').'/'. $news_item->news_id ?>" onclick="return confirm('Are You Sure?');"><img src="<?php echo base_url('/images/delete.gif'); ?>" height="40" width="60" /></a>&nbsp;
								 

								 <a href="<?php echo site_url('news/news/edit').'/'. $news_item->news_id ?>"><img src="<?php echo base_url('/images/edit.gif'); ?>" height="40" width="60" /></a>&nbsp;</a>&nbsp;&nbsp;<a href="<?php echo site_url('news/news/view').'/'. $news_item->news_id ?>"><img src="<?php echo base_url('/images/view.gif'); ?>" height="40" width="60" /></a></td>
							</tr>
							<?php } ?>
                      
                    </tbody>
                
                  </table>
                 	<?php echo form_close();?>
                </div><!-- /.box-body -->
              </div><!-- /.box -->
            </div><!-- /.col -->
          </div><!-- /.row -->
        </section><!-- /.content -->
      </div>
