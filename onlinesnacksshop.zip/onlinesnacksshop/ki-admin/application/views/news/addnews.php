<style type="text/css">
	

.btn
{
	height: 40px;
	width: 180px;
	
}
td
{
	padding:5px;
}
</style>

<div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
			Add News::
          
          </h1>
          <ol class="breadcrumb">
           <li><?php echo anchor('','<i class="fa fa-dashboard"></i> Dashbord'); ?></li>
              <li><?php echo anchor('news/news','<i class="fa fa-th fa-th-list"></i>News'); ?></li>
            
            <li class="active">Add News</li>
          </ol>
        </section>

        <!-- Main content -->
        <section class="content">
          <div class="row">
            <div class="col-xs-12">
              <!-- /.box -->

              <div class="box">
                <div class="box-header">
								<h4><?php echo anchor('news/news/',"<i class='fa fa-fw fa-arrow-left'></i>&nbsp;Back To News",'class="btn btn-primary"'); ?></h4>
                </div><!-- /.box-header -->
               
            
			
		<span>&nbsp;</span>
        <span>&nbsp;</span>
               
                
                  <?php
			if($this->session->userdata('imgerr'))
			{
				?>
                 <div class="alert alert-danger alert-dismissable">
                 <h4><i class="icon fa fa-ban"></i>Alert!</h4>
				    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                  <span style="font-size:16px;"><?php echo $this->session->userdata('imgerr'); ?>
                  </span>
                  </div>
                  
				<?php
				$this->session->unset_userdata('imgerr');
				
			}
			?>
                  
                <div class="box-body">
  				<?php echo form_open_multipart('news/news/addnew'); ?>
				<table cellpadding="5">
				<tr>
					<td>
								<label>Title <span style="color:#f00">(Required Field)</span></label>
					</td>
					<td>

									<input type="text" required="required" value="<?php echo $this->input->post('news_title'); ?>" name="news_title" class="form-control" />
                                        <?php
				  if(form_error('news_title'))
					{
						?>
                         <div class="alert alert-danger ">  
				    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                  <span style="font-size:16px;"><?php echo form_error('news_title'); ?>
                  </span>
                  </div>
                 
                        <?php 
							
					}?>
					</td>
				</tr>
				<tr>
					<td>
								<label>Status <span style="color:#f00">(Required Field)</span></label>
					</td>
					<td>
					
					<?php $options = array(
								                  '1'    => 'Enable',
								                  '0'  => 'Disable',
								                  ); ?>
								<?php echo form_dropdown('news_status',$options, set_value('news_status'),' class="drpdwn form-control"'); ?>
					</td>
				</tr>
				<tr>
					<td>
								<label>Image <span style="color:#f00">(Required Field)</span></label>
					</td>
					<td>
					
								<?php echo form_upload('news_images','',' class="upload"'); ?>
					</td>
				</tr>
				<tr>
					<td>
						<label >Content <span style="color:#f00">(Required Field)</span></label>
					</td>
					<td>
				<textarea class="form-control redactor" required="required" name="news_desc" rows="10" cols="60"><?php echo $this->input->post('news_desc'); ?></textarea>
                                       <?php
				  if(form_error('news_desc'))
					{
						?>
                         <div class="alert alert-danger ">  
				    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                  <span style="font-size:16px;"><?php echo form_error('news_des'); ?>
                  </span>
                  </div>
                 
                        <?php 
							
					}?>
					</td>
				</tr>
				</table>		
							
							
							<input type="submit" class="btn bg-purple margin" value="Add" />

					<?php echo form_close(); ?>
                
                </div><!-- /.box-body -->
              </div><!-- /.box -->
            </div><!-- /.col -->
          </div><!-- /.row -->
        </section><!-- /.content -->
      </div>


			
					<div >
						
