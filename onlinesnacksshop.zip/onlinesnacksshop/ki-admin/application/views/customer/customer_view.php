
<div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
			customer Section::
          
          </h1>
          <ol class="breadcrumb">
            <li><?php echo anchor('','<i class="fa fa-dashboard"></i> Dashbord'); ?></li>
              <li class="active"><i class="fa fa-th fa-th-list"></i>Customer</li>
            
          </ol>
        </section>

        <!-- Main content -->
        <section class="content">
          <div class="row">
            <div class="col-xs-12">
              <!-- /.box -->

              <div class="box">
                <div class="box-header">
               
				<h4><?php echo anchor('customer/customer/addcustomer',"<span><i class='fa fa-fw fa-plus'></i>Add customer</span>",'class="btn btn-primary"'); ?>
				<?php echo anchor('wishlist/wishlist/',"<span><i class='fa fa-fw fa-star'></i>View All Wishlist</span>",'class="btn btn-primary"'); ?>
				</h4>
                </div><!-- /.box-header -->
               
                   <?php
			if($this->session->userdata('insert'))
			{
				?>
				 <div class="alert alert-success alert-dismissable">
                                  <h4><i class="icon fa fa-check"></i>Alert!</h4>
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                   <span style="font-size:16px; color:#000"> &nbsp;&nbsp;<?php echo $this->session->userdata('insert'); ?>
                   </span></div>
				<?php
				$this->session->unset_userdata('insert');
			
			}
		    if($this->session->userdata('del'))
			{
				?>
								 <div class="alert alert-success alert-dismissable">
                                                  <h4><i class="icon fa fa-check"></i>Alert!</h4>
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                   <span style="font-size:16px; color:#000"><?php echo $this->session->userdata('del'); ?>
                   </span></div>
				<?php
				$this->session->unset_userdata('del');

			}
			if($this->session->userdata('edit'))
			{
				?>
								 <div class="alert alert-success alert-dismissable">
                                                  <h4><i class="icon fa fa-check"></i>Alert!</h4>
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                   <span style="font-size:16px; color:#000"><?php echo $this->session->userdata('edit'); ?>
                   </span></div>
				<?php

				$this->session->unset_userdata('edit');

			}
		
			
		?>
		<span>&nbsp;</span>
        <span>&nbsp;</span>
               
                
                  <?php
			if($this->session->userdata('notfound'))
			{
				?>
                 <div class="alert alert-danger alert-dismissable">
                   <h4><i class="icon fa fa-ban"></i>Alert!</h4>
				    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                  <span style="font-size:16px;"><?php echo $this->session->userdata('notfound'); ?>
                  </span>
                  </div>
                  
				<?php
				$this->session->unset_userdata('notfound');
				
			}
			?>
                  
                <div class="box-body">
                  <table id="example1" class="table table-bordered table-striped">
                    <thead >
                      <tr >
                   <!-- <th style="background:#fff"><input type="checkbox" name="chk" onclick='ToggleAll(this);'/></th>-->
                       <th >Id</th>
                        <th>Name</th>
                        <th style="background:#fff">Username</th>
                        <th style="background:#fff">Status</th>
                        <th>Created</th>
                        <th style="background:#fff">Content Control</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php foreach ($customer as $customer_item){ ?>
							<tr>

							<!-- <td><input type="checkbox" name="chk[]" id="chk" value="<?php echo $customer_item->customer_id;?>"/></td>-->
								<td><?php echo $customer_item->customer_id ?></td>
								<td><?php echo $customer_item->customer_fname ?></td>
								<td><?php echo $customer_item->customer_username ?></td>
                                
                                
								<td>
								
								<?php echo form_open("customer/customer/edit/$customer_item->customer_id") ?>
                       <select name="customer_status"  class="form-control">
                <option value="1" <?php if($customer_item->customer_status=="1"){ echo "selected"; } else { echo ""; } ?> >Enabled</option>
                 <option value="0" <?php if($customer_item->customer_status=="0"){ echo "selected"; } else { echo ""; } ?> >Disabled</option>
               
                </select>
					  <button type="submit" class="btn btn-default">Change</button>
                      <?php echo form_close(); ?>
								
                                
                                
                                </td>
								<td><?php echo $customer_item->customer_created ?></td>
								 <td><a href="<?php echo site_url('customer/customer/delete').'/'. $customer_item->customer_id ?>" onclick="return confirm('Are You Sure?');"><img src="<?php echo base_url('/images/delete.gif'); ?>" height="40" width="60" /></a>&nbsp;
								 

								&nbsp;<a href="<?php echo site_url('customer/customer/view').'/'. $customer_item->customer_id ?>"><img src="<?php echo base_url('/images/view.gif'); ?>" height="40" width="60" /></a>
                    <?php echo anchor('wishlist/wishlist/view/'.$customer_item->customer_id,"<span style='height:40px;width:100px;'><i class='fa fa-fw fa-star'></i>View My Wishlist</span>",'class="btn btn-primary"'); ?>           
                                 
                                 </td>
							</tr>
							<?php } ?>
                      
                    </tbody>
                
                  </table>
                 
                </div><!-- /.box-body -->
              </div><!-- /.box -->
            </div><!-- /.col -->
          </div><!-- /.row -->
        </section><!-- /.content -->
      </div>
