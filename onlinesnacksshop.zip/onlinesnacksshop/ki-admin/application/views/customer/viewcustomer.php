<style>
tbl
{
	width:250px;
	float:left;
}
tbl1
{
		width:250px;
	float:left;
}
td
{
	padding:10px;
}
</style>


    
<div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
			customer Section::
          
          </h1>
          <ol class="breadcrumb">
          <li><?php echo anchor('','<i class="fa fa-dashboard"></i> Dashbord'); ?></li>
              <li><?php echo anchor('customer/customer','<i class="fa fa-th fa-th-list"></i>customer'); ?></li>
            <li class="active">Customer List</li>
          </ol>
        </section>

        <!-- Main content -->
        <section class="content">
          <div class="row">
            <div class="col-xs-12">
              <!-- /.box -->

              <div class="box">
                <div class="box-header">
					<h4><?php echo anchor('customer/customer/',"<i class='fa fa-fw fa-arrow-left'></i>&nbsp;Back To Customer",'class="btn btn-primary"'); ?></h4>
                </div><!-- /.box-header -->
               
                 
                <div class="box-body">
						
			<div id="tbl1">

					<table cellspacing="40">
					<tr>
							<td><span>Customer Id :-</span></td>
							<td><span><?php echo $customer_item->customer_id ?></span></td>
						</tr>
						<tr>
							<td><span>Customer FirstName :-</span></td>
							<td><span><?php echo $customer_item->customer_fname ?></span></td>
						</tr>
                        <tr>
							<td><span>Customer LastName :-</span></td>
							<td><span><?php echo $customer_item->customer_lname ?></span></td>
						</tr>
						<tr>
							<td><span>Customer Username :-</span></td>
							<td><span><?php echo $customer_item->customer_username ?></span></td>
						</tr>
						<tr>
							<td><span>Customer Address :-</span></td>
							<td><span><?php echo $customer_item->customer_address ?></span></td>
						</tr>
						<tr>
							<td><span>Customer Mobile No :-</span></td>
							<td><span><?php echo $customer_item->customer_mobile ?></span></td>
						</tr>
						<tr>
							<td><span>Customer Email  :-</span></td>
							<td><span><?php echo $customer_item->customer_email ?></span></td>
						</tr>
						<tr>
							<td><span>customer Status :-</span></td>
							<td><span><?php if($customer_item->customer_status =="0") { echo "Disabled"; } else { echo "Enabled"; } ?></span></td>
						</tr>
						<tr>
							<td><span>Customer Created Date :-</span></td>
							<td><span><?php echo $customer_item->customer_created ?></span></td>
						</tr>
						<tr>
							<td><span>Customer Updated Date :-</span></td>
							<td><span><?php echo $customer_item->customer_updated ?></span></td>
						</tr>
						
						
					</table>	
</div>                  
                </div><!-- /.box-body -->
              </div><!-- /.box -->
            </div><!-- /.col -->
          </div><!-- /.row -->
        </section><!-- /.content -->
      </div>


