<style type="text/css">
	
input[type='text']    
{
	height: 35px;
	width: 200px;
	margin-left: 15px;
}
input[type='password']    
{
	height: 35px;
	width: 200px;
	margin-left: 15px;
}

.upload    
{
	height: 35px;
	width: 200px;
	margin-left: 15px;
}
.drpdwn
{
	height: 35px;
	width: 200px;
	margin-left: 15px;
}
.btn1
{
	height: 40px;
	width: 180px;
	
}
td
{
	padding:5px;
}
</style>

<div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
			Add customer::
          
          </h1>
          <ol class="breadcrumb">
           <li><?php echo anchor('','<i class="fa fa-dashboard"></i> Dashbord'); ?></li>
              <li><?php echo anchor('customer/customer','<i class="fa fa-th fa-th-list"></i>Customer'); ?></li>
            
            <li class="active">Add Customer</li>
          </ol>
        </section>

        <!-- Main content -->
        <section class="content">
          <div class="row">
            <div class="col-xs-12">
              <!-- /.box -->

              <div class="box">
                <div class="box-header">
								<h4><?php echo anchor('customer/customer/',"<i class='fa fa-fw fa-arrow-left'></i>&nbsp;Back To Customer",'class="btn btn-primary"'); ?></h4>
                </div><!-- /.box-header -->
               
            
			
		<span>&nbsp;</span>
        <span>&nbsp;</span>
               
                
                  <?php
			if($this->session->userdata('imgerr'))
			{
				?>
                 <div class="alert alert-danger alert-dismissable">
                 <h4><i class="icon fa fa-ban"></i>Alert!</h4>
				    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                  <span style="font-size:16px;"><?php echo $this->session->userdata('imgerr'); ?>
                  </span>
                  </div>
                  
				<?php
				$this->session->unset_userdata('imgerr');
				
			}
			?>
                  
                <div class="box-body">
  				<?php echo form_open_multipart('customer/customer/addnew'); ?>
				<table cellpadding="5">
				<tr>
					<td>
								<label>FirstName:- <span style="color:#f00">(Required Field)</span></label>
					</td>
					<td>

									<input type="text" required="required" class="form-control" value="<?php echo $this->input->post('customer_fname'); ?>" name="customer_fname" />
                               
                      <?php
                                      if(form_error('customer_fname'))
					{
						?>
                         <div class="alert alert-danger ">
				    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                  <span style="font-size:16px;"><?php echo  form_error('customer_fname'); ?>
                  </span>
                  </div>
                 
                        <?php 
							
					}
					?>
                   
					</td>
				</tr>
				<tr>
                <tr>
					<td>
								<label>LastName:- <span style="color:#f00">(Required Field)</span></label>
					</td>
					<td>

									<input type="text" required="required" class="form-control" value="<?php echo $this->input->post('customer_lname'); ?>" name="customer_lname" />
                               
                      <?php
                                      if(form_error('customer_lname'))
					{
						?>
                         <div class="alert alert-danger ">
				    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                  <span style="font-size:16px;"><?php echo form_error('customer_lname'); ?>
                  </span>
                  </div>
                 
                        <?php 
							
					}
					?>
                   
					</td>
				</tr>
				<tr>
					<td>
								<label>Username:- <span style="color:#f00">(Required Field)</span></label>
					</td>
					<td>

									<input type="text" required="required" class="form-control" value="<?php echo $this->input->post('customer_username'); ?>" name="customer_username" />
                                        
                      <?php
                                      if(form_error('customer_username'))
					{
						?>
                         <div class="alert alert-danger ">
				    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                  <span style="font-size:16px;"><?php echo form_error('customer_username'); ?>
                  </span>
                  </div>
                 
                        <?php 
							
					}
					?>
                   
					</td>
				</tr>
				<tr>
					<td>
								<label>Password:- <span style="color:#f00">(Required Field)</span></label>
					</td>
					<td>

									<input type="Password" required="required" class="form-control" value="<?php echo $this->input->post('customer_password'); ?>" name="customer_password" />
                                           
                      <?php
                                      if(form_error('customer_password'))
					{
						?>
                         <div class="alert alert-danger ">
				    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                  <span style="font-size:16px;"><?php echo form_error('customer_password'); ?>
                  </span>
                  </div>
                 
                        <?php 
							
					}
					?>
                   
					</td>
				</tr>
				<tr>
					<td>
								<label>Address:- <span style="color:#f00">(Required Field)</span></label>
					</td>
					<td>

									<input type="text" required="required" class="form-control" value="<?php echo $this->input->post('customer_address'); ?>" name="customer_address" />
                                             
                      <?php
                                      if(form_error('customer_address'))
					{
						?>
                         <div class="alert alert-danger ">
				    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                  <span style="font-size:16px;"><?php echo form_error('customer_address'); ?>
                  </span>
                  </div>
                 
                        <?php 
							
					}
					?>
                          
					</td>
				</tr>
		
				</tr>
				<tr>
					<td>
								<label>Mobile:- <span style="color:#f00">(Required Field)</span></label>
					</td>
					<td>

									<input type="text" required="required" class="form-control" value="<?php echo $this->input->post('customer_mobile'); ?>" name="customer_mobile" />
                                                        
                      <?php
                     if(form_error('customer_mobile'))
					{
						?>
                         <div class="alert alert-danger ">
				    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                  <span style="font-size:16px;"><?php echo form_error('customer_mobile'); ?>
                  </span>
                  </div>
                 
                        <?php 
							
					}
					?>
                   
					</td>
				</tr>
				<tr>
					<td>
								<label>Email:- <span style="color:#f00">(Required Field)</span></label>
					</td>
					<td>

									<input type="text" required="required" class="form-control" value="<?php echo $this->input->post('customer_email'); ?>" name="customer_email" />
                                                       
                      <?php
                       if(form_error('customer_email'))
					{
						?>
                         <div class="alert alert-danger ">
				    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                  <span style="font-size:16px;"><?php echo form_error('customer_email'); ?>
                  </span>
                  </div>
                 
                        <?php 
							
					}
					?>
                   
					</td>
				</tr>

				</table>		
							
							
							<input type="submit" class="btn1 bg-purple margin" value="Add" />

					<?php echo form_close(); ?>
                
                </div><!-- /.box-body -->
              </div><!-- /.box -->
            </div><!-- /.col -->
          </div><!-- /.row -->
        </section><!-- /.content -->
      </div>
					<div>
						
