<style type="text/css">	
input[type='text']    
{
	height: 35px;
	width: 200px;
	margin-left: 15px;
}
.textarea    
{
	height: 65px;
	width: 200px;
	margin-left: 15px;
}
.upload    
{
	height: 35px;
	width: 200px;
	margin-left: 15px;
}
.drpdwn
{
	height: 35px;
	width: 200px;
	margin-left: 15px;
}
.btn
{
	height: 40px;
	width: 180px;
	
}
td
{
	padding:5px;
}
</style>
<div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
			Edit customer::
          
          </h1>
          <ol class="breadcrumb">
         <li><?php echo anchor('','<i class="fa fa-dashboard"></i> Dashbord'); ?></li>
              <li><?php echo anchor('customer/customer','<i class="fa fa-th fa-th-list"></i>customer'); ?></li>
            <li class="active">Edit Customer </li>
          </ol>
        </section>

        <!-- Main content -->
        <section class="content">
          <div class="row">
            <div class="col-xs-12">
              <!-- /.box -->

              <div class="box">
                <div class="box-header">
				<h4><?php echo anchor('customer/customer/',"<i class='fa fa-fw fa-arrow-left'></i>&nbsp;Back To customer",'class="btn btn-primary"'); ?></h4>
                </div><!-- /.box-header -->
               
            
			
		<span>&nbsp;</span>
        <span>&nbsp;</span>
               
                
                  <?php
				  if(validation_errors())
					{
						?>
                         <div class="alert alert-danger ">
                         <h4><i class="icon fa fa-ban"></i>Alert!</h4>
                         
				    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                  <span style="font-size:16px;"><?php echo validation_errors(); ?>
                  </span>
                  </div>
                 
                        <?php 
							
					}
			if($this->session->userdata('imgerr'))
			{
				?>
                 <div class="alert alert-danger alert-dismissable">
                 <h4><i class="icon fa fa-ban"></i>Alert!</h4>
				    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                  <span style="font-size:16px;"><?php echo $this->session->userdata('imgerr'); ?>
                  </span>
                  </div>
                  
				<?php
				$this->session->unset_userdata('imgerr');
				
			}
			?>
                  
                <div class="box-body">
<?php echo form_open('customer/customer/edit/'."$customer_item->customer_id"); ?>
						
						<?php echo form_hidden('customer_id',$customer_item->customer_id); ?>
				<table cellpadding="5">
				<tr>
					<td>
							<label>Status <span style="color:#f00">(Required Field)</span></label>
					</td>
					<td>
							<select name="status" required="required" class="drpdwn form-control" >
							<option value="0" <?php if($customer_item->customer_status==0) { echo "selected"; } ?>>Disabled</option><option  value="1" <?php if($customer_item->customer_status==1) { echo "selected"; } ?>>Enabled</option></select>
					</td>
				</tr>
				</table>		
							
							
					<input type="submit" class="btn bg-purple margin" value="Edit" />
					<?php echo form_close(); ?>
                
                </div><!-- /.box-body -->
              </div><!-- /.box -->
            </div><!-- /.col -->
          </div><!-- /.row -->
        </section><!-- /.content -->
   </div>
