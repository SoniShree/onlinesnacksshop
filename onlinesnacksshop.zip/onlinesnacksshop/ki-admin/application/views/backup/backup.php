<div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
			Backup Section::
          
          </h1>
          <ol class="breadcrumb">
            <li><?php echo anchor('','<i class="fa fa-dashboard"></i> Dashbord'); ?></li>
              <li class="active"><?php echo anchor('backup','<i class="fa fa-th fa-th-list"></i>Backup'); ?></li>
            
          </ol>
        </section>

<div>
  
</div>
<div class="box-content alerts">
  <?php
				if($this->session->userdata('err'))
				{
                ?>
  <div class="alert alert-danger" id="sc">
    <button type="button" class="close" data-dismiss="alert">&times;</button>
    <?php echo $this->session->userdata('err'); $this->session->unset_userdata('err');?> </div>
  <?php
				}
				if($this->session->userdata('succ'))
				{
                ?>
  <div class="alert alert-success" id="sc">
    <button type="button" class="close" data-dismiss="alert">&times;</button>
    <?php echo $this->session->userdata('succ'); $this->session->unset_userdata('succ');?> </div>
  <?php
					
				}
				?>
  <?php
                if(validation_errors())
				{
                ?>
  <div class="alert alert-danger" id="sc">
    <button type="button" class="close" data-dismiss="alert">&times;</button>
    <?php echo validation_errors();?> </div>
  <?php
				}
				?>
</div>
<section class="content">
<div class="row">
  <div class="box col-md-12">
    <div class="box-inner">
     
      <?php echo form_open('backup/delete_multiple') ?>
      <div class="box-content">
        <?php
					//echo anchor('backup/backupsql','Create SQL Backup','class="btn btn-primary btn-xs" onclick="return window.confirm(\'Are You Sure?\');"');
					?>
                    <h4><?php echo anchor('backup/backupsql',"<span><i class='fa fa-fw fa-plus'></i>Create SQL Backup</span>",'class="btn btn-primary" onclick="return window.confirm(\'Are You Sure?\');"'); ?>
				
				<?php //echo anchor('del',"<span><i class='fa fa-fw fa-plus'></i>Delete Selected</span>",'class="btn btn-primary" onclick="return window.confirm(\'Are You Sure?\');"','id="multidel"'); ?>
                
        <?php //echo form_submit('del','Delete Selected',' id="multidel" class="btn btn-primary btn-xs"  onclick="return window.confirm(\'Are You Sure?\');" ') ?> </h4><br />
        <br />
        <table id="example1" class="table table-striped table-bordered bootstrap-datatable datatable responsive">
          <thead>
            <tr>
              
              <th>Backups List</th>
              <th>Size</th>
              <th>Date</th>
              <th >Content Control</th>
            </tr>
          </thead>
          <tbody>
            <?php
                                    $this->load->helper('html');
                                    
                                       foreach($files as $file) 
                                        {
                                            
                                            ?>
            <tr >
              
              <td><?php echo $file; ?></td>
              <td><?php echo round(reset(get_file_info('../backups/'.$file,'size'))/1024).' KB'; ?></td>
              <td><?php echo date('d-M-Y',reset(get_file_info('../backups/'.$file,'date'))); ?></td>
              <td ><a href="backup/download/<?php echo $file; ?>" class="btn btn-success " style="margin:0; float:none" onClick="return window.confirm('Are you sure?');"><span><i class='fa fa-fw fa-download'></i>Download</span></a>&nbsp;&nbsp;<a href="backup/restore/<?php echo $file; ?>" class="btn btn-primary" style="margin:0; float:none" onClick="return window.confirm('Are you sure?');"><span><i class='fa fa-fw fa-repeat'></i>Restore</span></a>&nbsp;&nbsp; <?php echo anchor('backup/delete/'.$file,img(base_url().'images/delete.gif'),' onclick="return window.confirm(\'Are You Sure?\');"');?></td>
            </tr>
            <?php
                                        }
                                ?>
          </tbody>
        </table>
        <?php echo form_close() ?> 
        <script>
            $(document).ready(function() {
                resetcheckbox();
				
				
				//$("input[type=submit]").attr('disabled','disabled');
				
                $('#selectall').click(function(event) {  //on click
                    if (this.checked) { // check select status
                        $('.checkbox').each(function() { //loop through each checkbox
                            this.checked = true;  //select all checkboxes with class "checkbox1" 
							
							             
                        });
                    } else {
                        $('.checkbox').each(function() { //loop through each checkbox
                            this.checked = false; //deselect all checkboxes with class "checkbox1" 
							//$("input[type=submit]").removeAttr('disabled');
							
							//$('input[type=submit]').prop('disabled', false);
							                   
                        });
                    }
                });
                $("#del_all").on('click', function(e) {
                    e.preventDefault();
                    var checkValues = $('.checkbox:checked').map(function()
                    {
                        return $(this).val();
                    }).get();
                    console.log(checkValues);
                    
                    $.each( checkValues, function( i, val ) {
                        $("#"+val).remove();
                        });
//                    return  false;
                    $.ajax({
                        url: '<?php echo base_url();?>news/delete_multiple',
                        type: 'post',
                        data: 'ids=' + checkValues
                    }).done(function(data) {
                        $("#respose").html(data);
                        $('#selectall').attr('checked', false);
                    });
                });

              
                
                function  resetcheckbox(){
                $('input:checkbox').each(function() { //loop through each checkbox
                this.checked = false; //deselect all checkboxes with class "checkbox1"   
				             
                   });
                }
            });
			
        </script> 
        <script type="text/javascript">
		 $('#sc').delay(3000).fadeOut(400)
		</script>
      </div>
    </div>
  </div>
  <!--/span--> 
  
</div>
</section>
</div>
<!--/row-->