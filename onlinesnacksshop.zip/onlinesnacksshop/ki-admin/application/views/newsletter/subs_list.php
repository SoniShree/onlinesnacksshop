<script language="javascript" type="text/javascript">
var count=0;
var flag=0;
var counter=0;
var msgscmsg = $('#msgscmsg');
function  resetcheckbox(){
	$('input:checkbox').each(function() { //loop through each checkbox
	this.checked = false; //deselect all checkboxes with class "checkbox1"   			 
   });
}
function timer(){
	
	var UrlToPass="";
	$.ajax({ 
	type : 'POST',
	data : UrlToPass,
	url  : '<?php  echo site_url(); ?>/misc/get_emailsent',
	success: function(count){
		$('#leftsend').html(Math.round(count)+"%");
		if(counter==0)
		{
			$('#progcomplete').css('width',"0%");
			counter=counter+1;
			$('#pro').show();
		}
		else
		{
			
			$('#progcomplete').css('width',Math.round(100-count)+"%");
		}
		$('#sucesssend').html(Math.round(100-count)+"%");}
	});
	if(flag!=1)
	{
		setTimeout('timer()',2000);
	}
	else
	{
		
		//delay(100);
		$('#sucesssend').html(0);
		$('#pro').hide();
	}
}
</script>
<div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
			Subscription::
          
          </h1>
          <ol class="breadcrumb">
            <li><?php echo anchor('','<i class="fa fa-dashboard"></i> Dashbord'); ?></li>
              <li><?php echo anchor('#','<i class="fa fa-th fa-th-list"></i>News Letter'); ?></li>
            <li class="active">Order List</li>
          </ol>
        </section>
        <section class="content">


    

    <div class="row">
    <div class="box col-md-12">
    <div class="box-inner">
    <h4>Email Listing:</h4>
    <?php echo form_open('news/delete_multiple') ?>
    <div class="box-content">
 	              
<div class="box-content alerts">
				<?php
				if($this->session->userdata('err'))
				{
                ?>
                <div class="alert alert-danger" id="sc">
                    <button type="button" class="close" data-dismiss="alert">&times;</button>
                    <?php echo $this->session->userdata('err'); $this->session->unset_userdata('err');?>
                </div>
   				<?php
				}
				if($this->session->userdata('succ'))
				{
                ?>
                <div class="alert alert-success" id="sc">
                    <button type="button" class="close" data-dismiss="alert">&times;</button>
                    <?php echo $this->session->userdata('succ'); $this->session->unset_userdata('succ');?>
                </div>
                <?php
					
				}
				?>

</div>                     
     
     
                            <br />
                            <br />
    	
     
     <div id="sublist">   
     	<table class="table table-striped table-bordered bootstrap-datatable datatable responsive" >
            <thead>
            <tr>
                                    
                                    
                                    <th>Email</th>
                                    
                                    <th width="20px">Subscribed</th>
                                    
                                    
                                    <!--<th>Created Date</th>
                               	<th>Added by</th>-->
                                    
                                    <th style="width:15%;" >Content Control</th>
            </tr>
            </thead>
            <tbody>
            <?php
                                    $this->load->helper('html');
                                    
                                       foreach($subs as $sub_item) 
                                        {
                                            $id =$sub_item->subs_id;
                                            $email =$sub_item->email_id;
                                            $status  =$sub_item->status;
											
                                           
                                            ?>
                                        
                                            <tr >
                                        
                                      
                                        <td><?php echo $email; ?></td>
                                      
                                      	<td id="stat"><?php
                                                if($status == 1)
                                                { 
														
                                                        ?>
                                                        <center>
														<i class="glyphicon glyphicon-ok"></i>
                                						</center>
														<?php
                                                }
                                                else
                                                { 
                                                      ?>
                                                      <center>
                                                      <i class="glyphicon glyphicon-remove"></i>
                                                      </center>
                                                      <?php
                                                    
                                                } 
                                
                                
                                            ?></td>
                                        
                                   
                                         
                                            <td ><?php echo anchor('newsletter/delete/'.$id,img(base_url().'images/delete.gif'),' onclick="return window.confirm(\'Are You Sure?\');"');?> </td>
                                    </tr>
                                        <?php
                                        }
                                ?>
            </tbody>
     </table>
     </div>
     
     <div id="emailform">
                                 
                                 		<?php // echo form_open_multipart('misc/sendbulkmail');?>
								
                         
                                
                 <div class="alert alert-success" id="msgsc" style="display:none;">
                    <button type="button" class="close" data-dismiss="alert">&times;</button>
                    <span id="msgscmsg"></span>
                </div>
                                <script type="text/javascript">
								function pre()
								{
									resetcheckbox();
									return true;
								}
									$(document).ready(function() 
									{
										var subject = $('#mailsub');
										var desc = $('#maildesc');
										var mailsuberr = $('#mailsuberr');
										var maildescerr = $('#maildescerr');
										var descerr = $('#descerr');
										var suberr = $('#suberr');
										var msgsc = $('#msgsc');
										var msgscmsg = $('#msgscmsg');
										msgsc.hide();
										descerr.hide();
										suberr.hide();
									  $('#sendmail').click(function() 
									  {
										  if(subject.val()=="")
										  {
											  mailsuberr.html("Subject field cannot be empty.");
											  suberr.show();
											  return false;
										  }
										  else
										  {
											  mailsuberr.html("");
											  suberr.hide();
										  }
										  var str=subject.val();
										  if(str.length<10)
										  {
											  mailsuberr.html("Subject field cannot be less than 10 chars.");
											  suberr.show();
											  return false;
										  }
										  else
										  {
											  mailsuberr.html("");
											  suberr.hide();
										  }
										  if(desc.val()=="<p><br></p>")
										  {
											  maildescerr.html("Description cannot be blank.");
											  descerr.show();
											  return false;
										  }
										  else
										  {
											  maildescerr.html("");
											  descerr.hide();
										  }
										  var str1=desc.val();
										  if(str1.length<36)
										  {
											  maildescerr.html("Description cannot be less than 25 chars.");
											  descerr.show();
											  return false;
										  }
										  else
										  {
											  maildescerr.html("");
											  descerr.hide();
										  }
										  if(desc.val()!="" && subject.val()!="<p><br></p>")
										  {
											  var res='';
											  	var checkValues ="";
												msgscmsg.html('Uploading Email List.');
												msgsc.show();
											  	checkValues = $('.checkbox:checked').map(function()
												{
													return $(this).val();
												}).get();
												//alert(checkValues);
												timer();
												$('#form').hide();
										  	var UrlToPass = 'bulksub='+subject.val()+'&bulkdesc='+desc.val()+'&eids='+checkValues;
											msgscmsg.html('Uploading Email List & Sending Emails. Please Wait.');	
											$.ajax({ 
											type : 'POST',
											data : UrlToPass,
											url  : '<?php  echo site_url(); ?>/misc/sendbulkmail',
											success: function(response){
													flag= response.substr(0,1);
													msgscmsg.html("Mail Sent To All Customers.");
													$('#sucesssend').html("98%");
													$('#progcomplete').css('width',"98%");
													msgsc.show().delay(0);
												}
											});
											
										  }
										  return false;
									  });									 
									});
								</script>
                                <br /><br />
                                <div class="progress" id="pro" style="display:none;">
                    <div class="progress-bar progress-bar-success progress-bar-striped progress-success active" role="progressbar" id="progcomplete" aria-valuenow="40" aria-valuemin="0" aria-valuemax="100"  style="width: 0%">
                        <span id="sucesssend" style="color:#000;"></span>
                    </div>
                                    

                    <center><span id="leftsend" ></span></center>
                    </div>
                                
								<div class="form-group" id="form">
									<center><?php echo form_label('Subject'); ?></center>
									<?php echo form_input('bulksub','','placeholder="Subject Name" class="form-control" required style="text-align:center" id="mailsub"');?>
                                    	<div class="alert alert-danger" style="display:none;" id="suberr">
										<button type="button" class="close" data-dismiss="alert">&times;</button>
                                        <span id="mailsuberr"></span>
										</div>
								<div class="form-group">
									<center><?php echo form_label('Content'); ?></center>
									<?php echo form_textarea('bulkdesc','','class="redactor form-control" style="text-align:center" id="maildesc" ');?>
                                    
										<div class="alert alert-danger" style="display:none;" id="descerr">
										<button type="button" class="close" data-dismiss="alert">&times;</button>
                                        <span id="maildescerr"></span>
								</div>
                                <br />
                               <center> <?php echo form_button('addmsg','Send Bulk  Email','class="btn btn-primary " id="sendmail"'); ?></center>
					<?php //echo form_close();?>
                                      
                              	
                            
                      
                       </div>
                        
                            
                            
     <script type="text/javascript">
	 $('#sc').delay(3000).fadeOut(400)
	</script>       
                            	
                           
     
    </div>
    </div>
     <script type="text/javascript" src="<?php echo base_url() ?>js/ajax.js">
     </script>
    
    
     
        
     <script>
            $(document).ready(function() {
                resetcheckbox();
				
				
				//$("input[type=submit]").attr('disabled','disabled');
				
                $('#selectall').click(function(event) {  //on click
                    if (this.checked) { // check select status
                        $('.checkbox').each(function() { //loop through each checkbox
                            this.checked = true;  //select all checkboxes with class "checkbox1" 
							
							             
                        });
                    } else {
                        $('.checkbox').each(function() { //loop through each checkbox
                            this.checked = false; //deselect all checkboxes with class "checkbox1" 
							//$("input[type=submit]").removeAttr('disabled');
							
							//$('input[type=submit]').prop('disabled', false);
							                   
                        });
                    }
                });
                $("#del_all").on('click', function(e) {
                    e.preventDefault();
                    var checkValues = $('.checkbox:checked').map(function()
                    {
                        return $(this).val();
                    }).get();
                    console.log(checkValues);
                    
                    $.each( checkValues, function( i, val ) {
                        $("#"+val).remove();
                        });
//                    return  false;
                    $.ajax({
                        url: '<?php echo base_url();?>news/delete_multiple',
                        type: 'post',
                        data: 'ids=' + checkValues
                    }).done(function(data) {
                        $("#respose").html(data);
                        $('#selectall').attr('checked', false);
                    });
                });
            });
			
        </script>
     
    
     <script type="text/javascript">
	 $('#sc').delay(3000).fadeOut(400)
     </script>	
     
     
<?php echo form_close() ?>
     
     
    </div>
    </div>
    </div>
    </div>
    <!--/span-->
    </div>