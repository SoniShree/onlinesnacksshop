<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Namkeen extends CI_Controller
{
	public function __construct()
   {
      parent::__construct();
      $is_logged_in=$this->session->userdata('is_logged_in');
      if(!isset($is_logged_in) || $is_logged_in != TRUE)
      {
        redirect('login');
      }
      $this->unset_sessions();
      $this->load->model('namkeen/namkeen_model','nm');
    $this->load->model('website_model','wm');
            $data['contact']=$this->wm->contact_details();
		$data['total_contact']=$this->wm->get_contact_row();

      $this->load->helper('date');
      $this->load->library('form_validation');

    
   }
   public function unset_sessions()
   {
      $this->session->unset_userdata('search');
   }
   public function index()
   
   {
        $data['title']="namkeen";
		
    $data['namkeen']=$this->nm->get_namkeen_page();
	$date['category_name']=$this->nm->get_category_name();
    $data['page']='namkeen/namkeen_view';
    $this->load->view('templates/content',$data);

   }
   public function checkBox()
	{				
		if(isset($_POST['chk']))
		{
			foreach($this->input->post('chk') as $value)
			{
				if($_POST["enable"]=="Enable Selected")
				{
					$this->namkeen_model->enable_news($value);					
					$v="Selected Record Enabled Successfully...!!!";
				}
				else if($_POST["disable"]=="Disable Selected")
				{
					$this->namkeen_model->disble_news($value);		
					$v="Selected Record Disabled Successfully...!!!";							
				}
				else if($_POST["delete"]=="Delete Selected")
				{
					$this->namkeen_model->delete_news($value);

					$v="Selected Record Deleted Successfully...!!!";	
				}
			}						
			$this->session->set_userdata('msg',$v);
			redirect('namkeen/namkeen');	
		}
		$this->index();		
	}
   //view function
  public function view($id)
   {
      $data['namkeen_item'] = $this->nm->get_namkeen($id);
	  $data['image'] = $this->nm->get_images($id);
	  
	  
      if (empty($data['namkeen_item']))
      {
        redirect('pagenotfound');
      }
	  
	      $data['title']="View namkeen";
      $data['page']='namkeen/viewnamkeen';
      $this->load->view('templates/content',$data);  

   }
   //add namkeen function
   public function addnamkeen()
   {
           $data['title']="Add namkeen";
        $data['page']='namkeen/addnamkeen';
		$data['category_name']=$this->nm->get_category_name();
        $this->load->view('templates/content',$data);  
   }
   //add namkeen
   public function addnew()
   {
	   $data['category_name']=$this->nm->get_category_name();
    $config['upload_path'] = "../uploads/product_image/";
    $config['allowed_types'] = 'gif|jpg|png|jpeg';
    $config['max_size'] = '100000';
    $config['max_width']  = '2000';
    $config['max_height']  = '2000';
    $this->load->library('upload', $config);   
     $this->form_validation->set_rules('namkeen_title', 'Namkeen Title', 'required|trim|min_length[5]|max_length[100]');
     $this->form_validation->set_rules('namkeen_sort', 'Namkeen Description', 'required|trim');
	  $this->form_validation->set_rules('namkeen_long', 'Namkeen Description', 'required|trim');
      $this->form_validation->set_rules('namkeen_price', 'Namkeen Price', 'required|trim|numeric|min_length[2]|max_length[10]|is_natural_no_zero');
	  $this->form_validation->set_rules('namkeen_qty', 'Namkeen Quantity', 'required|trim|numeric|min_length[2]|max_length[10]|is_natural_no_zero');
        if ($this->form_validation->run() == FALSE)
        {
			    $data['title']="Add namkeen";
            $data['page']='namkeen/addnamkeen';
           $this->load->view('templates/content',$data);  
        }
        else
        {
           $temp=$this->upload->do_upload('namkeen_images');
            if($temp)
            {
              
              $imgarr = $this->upload->data();
              $fname = $imgarr['file_name'];
			  $this->upload->resize($fname,$config['upload_path'],$config['upload_path'].'thumbs/',600);
				 if(file_exists("../uploads/product_image/".$fname))
				{
					unlink("../uploads/product_image/".$fname);
				}
              $flag=$this->nm->addnamkeen($fname);
			  
			  
			  
        	  
              $this->session->set_userdata('insert','namkeen Insert Successfully...');
              redirect('namkeen/namkeen');
            }
            else
            {
                $this->session->set_userdata('imgerr',$this->upload->display_errors());
				$data['category_name']=$this->nm->get_category_name();
                $data['page']='namkeen/addnamkeen';
                $this->load->view('templates/content',$data); 
            }
        }    
    
  }
   
  //edit function
   public function edit($id=FALSE)
  {
	  $data['category_name']=$this->nm->get_category_name();
    if($id)
    {

      $data['namkeen_item'] = $this->nm->get_namkeen($id);
      if (empty($data['namkeen_item']))
      {
            $this->session->set_userdata('notfound',"namkeen Id Not Found");
            redirect('namkeen/namkeen/');
      }
    $config['upload_path'] = "../uploads/product_image/";
    $config['allowed_types'] = 'gif|jpg|png|jpeg';
    $config['max_size'] = '100000';
    $config['max_width']  = '2000';
    $config['max_height']  = '2000';
    $this->load->library('upload', $config);    
    $this->form_validation->set_rules('namkeen_title', 'Namkeen Title', 'required|trim|min_length[5]|max_length[100]');
    $this->form_validation->set_rules('namkeen_sort', 'Namkeen Sort Description', 'required|trim|min_length[5]|max_length[1000]');
	$this->form_validation->set_rules('namkeen_long', 'Namkeen Long Description', 'required|trim|min_length[5]|max_length[1000]');
	$this->form_validation->set_rules('namkeen_price', 'Namkeen Price', 'required|trim|numeric|min_length[2]|max_length[10]|is_natural_no_zero');
	$this->form_validation->set_rules('namkeen_qty', 'Namkeen Quantity', 'required|trim|numeric|min_length[2]|max_length[10]|is_natural_no_zero');
    if ($this->form_validation->run() == FALSE)
      {
           $data['title']="edit namkeen";
           $data['page'] = 'namkeen/edit';
          $this->load->view('templates/content',$data);  
      }
      else
      {
        $oldimage =  $this->input->post('old_img');
          $this->upload->do_upload('namkeen_images');
          $imgarr = $this->upload->data();
          $fname = $imgarr['file_name'];
           if($fname !="")
					{
						if(file_exists("../uploads/product_image/thumbs/".$oldimage))
						{
							
							unlink("../uploads/product_image/thumbs/".$oldimage);
						}
						if(file_exists("../uploads/product_image/".$fname))
						{
							unlink("../uploads/product_image/".$fname);
						}
						$imgname=$fname;
						 $result=$this->nm->editproduct($imgname);
					}
					else
					{
						$imgname=$oldimage;
						$this->upload->resize($imgname,$config['upload_path'],$config['upload_path'].'thumbs/',600);
						
						$result=$this->nm->editproduct($imgname);
						
					}
         if($result)
          {
            $this->session->set_userdata('edit','namkeen Update Successfully...');
            redirect('namkeen/namkeen');
          
        }
        
      }

    }
    else
    {
         $this->session->set_userdata('notfound',"namkeen Id Not Found");
        redirect('namkeen/namkeen');
    }
      
      
  }
    
//delete function
  public function delete($id=FALSE)
  {
    if($id)
    {
      $data['namkeen_item'] = $this->nm->get_namkeen($id);
      if (empty($data['namkeen_item']))
      {
            $this->session->set_userdata('notfound',"namkeen Id Not Found");
            redirect('namkeen/namkeen/');
      }
       $oldimage=$data['product_item']->product_img;
			if(file_exists("../uploads/product_image/".$oldimage) or file_exists("../uploads/product_image/thumbs/".$oldimage))
			{
				//unlink("../uploads/product_image/".$oldimage);
				unlink("../uploads/product_image/thumbs/".$oldimage);
			}
       $this->nm->delete_namkeen($id);
      $this->session->set_userdata('del','namkeen Deleted Succesfully...');
      redirect('namkeen/namkeen');
      
    }
    else
    {

        $this->session->set_userdata('notfound',"namkeen Id Not Found");
       redirect('namkeen/namkeen'); 
    }
   
  }
  
  public function addgallery($namkeen_id)
	{
		if(!is_dir('../uploads/namkeen_image/'.$namkeen_id))
		{
			mkdir('../uploads/product_image/'.$namkeen_id,0777,true);
			mkdir('../uploads/product_image/'.$namkeen_id.'/full',0777,true);
			mkdir('../uploads/product_image/'.$namkeen_id.'/thumbs',0777,true);
			
		}
		$config['upload_path'] = '../uploads/product_image/'.$namkeen_id.'/full';
		$config['allowed_types'] = 'gif|jpg|png|jpeg';
		$config['max_width']  = '5000';
		$config['max_height']  = '5000';
		$config['encrypt_name'] =  TRUE;

		$this->load->library('upload', $config);
		 
		$i = 0;
		foreach($_FILES as $key=>$val)
		{
			$cnt = count($_FILES['userfile']['name']);
			for($j=0;$j<$cnt;$j++)
			{
				$img['name'] = $val['name'][$i];
				$img['type'] = $val['type'][$i];
				$img['tmp_name'] = $val['tmp_name'][$i];
				$img['error'] = $val['error'][$i];
				$img['size'] = $val['size'][$i];
				
				//echo "<pre>"; print_r($img); 
				//$this->upload->do_upload_ki($img);
				$i++;
				if ( ! $this->upload->do_upload_ki($img))
				{
					$this->session->set_userdata('err',$this->upload->display_errors());
					
					redirect ('namkeen/namkeen/view/'.$namkeen_id);
				}
				else
				{
					$arr = $this->upload->data();
					$imageName = $arr['file_name'];
					
					$this->upload->resize($imageName,$config['upload_path'],'../uploads/product_image/'.$namkeen_id.'/thumbs');
									
					$res = $this->nm->add_gallery($namkeen_id,$imageName);
					
					
				}
				
			}
		}
				redirect ('namkeen/namkeen/view/'.$namkeen_id);
	}
		
	public function imgdel($namkeen_id,$photo_id)
	{
		$data['img'] = $this->nm->get_photo($photo_id);
		$image = $data['img']->long_name;
		
		
		if(file_exists('../uploads/product_image/'.$namkeen_id.'/full/').$image)	
		{
			unlink('../uploads/product_image/'.$namkeen_id.'/full/'.$image);
		}
		
		if(file_exists('../uploads/product_image/'.$namkeen_id.'/thumbs/').$image)	
		{
			unlink('../uploads/product_image/'.$namkeen_id.'/thumbs/'.$image);
		} 
		
		
		$res = $this->nm->delete_image($namkeen_id,$photo_id); 
		if($res)
		{
			$this->session->set_userdata('msg','Image Deleted Succesfully');
			redirect('namkeen/namkeen/view/'.$namkeen_id);
		}
		else
		{
			redirect('namkeen/namkeen/view/'.$namkeen_id);
		}
			
	}
}
?>