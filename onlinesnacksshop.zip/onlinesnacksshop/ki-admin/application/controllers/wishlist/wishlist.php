<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class wishlist extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->model('wishlist/wishlist_model','wm');
	}
	public function index()
	{
		$data['wishlist']=$this->wm->get_wishlist();
		$data['title']='Wishlist';
		$data['page']='wishlist/wishlist_view';
    	$this->load->view('templates/content',$data);
	}
	public function view($id=FALSE)
	{
		$data['Wishlist_item'] = $this->wm->get_Wishlist_record($id);
		
		
		//$data['wishlist_product']=$this->wm->get_Wishlist_record_product($p_id);
		$data['Wishlist_customer'] = $this->wm->get_Wishlist_record_customer($id);
		
		
		$data['title']="View Wishlist";
		$data['page']='wishlist/viewwishlist';
		$this->load->view('templates/content',$data);
	}
}
?>