<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class News extends CI_Controller
{
	public function __construct()
   {
      parent::__construct();
      $is_logged_in=$this->session->userdata('is_logged_in');
      if(!isset($is_logged_in) || $is_logged_in != TRUE)
      {
        redirect('login');
      }
 
      $this->load->model('news/news_model','nm');
      $this->load->model('website_model','wm');
              $data['contact']=$this->wm->contact_details();
		$data['total_contact']=$this->wm->get_contact_row();

      $this->load->helper('date');
      $this->load->library('form_validation');

    
   }


   public function index()
   
   {
   	$data['contact']=$this->wm->contact_details();
		$data['total_contact']=$this->wm->get_contact_row();
		
        $data['title']="News";
    $data['news']=$this->nm->get_news_page();
    $data['page']='news/news_view';
    $this->load->view('templates/content',$data);

   }
   //view function
  public function view($id=FALSE)
   {
   	if($id)
   	{
      $data['news_item'] = $this->nm->get_news($id);
      if (empty($data['news_item']))
      {
        $this->session->set_userdata('notfound',"News Id Not Found");
            redirect('news/news/');
      }
	      $data['title']="View News";
      $data['page']='news/viewnews';
      $this->load->view('templates/content',$data);  
  }
  else
  {
  		    $this->session->set_userdata('notfound',"News Id Not Found");
            redirect('news/news/');
  }
   }
   //add news function
   public function addnews()
   {
           $data['title']="Add News";
        $data['page']='news/addnews';
        $this->load->view('templates/content',$data);  
   }
   //add news
   public function addnew()
   {
   if(!is_dir('../uploads/news_image/thumbs/'))
		{
			mkdir('../uploads/news_image/thumbs/',0777,true);
			
		}
    
    
    $config['upload_path'] = "../uploads/news_image/";
    $config['allowed_types'] = 'gif|jpg|png|jpeg';
    $config['max_size'] = '100000';
    $config['max_width']  = '2000';
    $config['max_height']  = '2000';
    $this->load->library('upload', $config); 
     $this->form_validation->set_rules('news_title', 'News Title', 'required|trim|min_length[5]|max_length[100]');
     $this->form_validation->set_rules('news_desc', 'News Description', 'required|trim');
        if ($this->form_validation->run() == FALSE)
        {
			    $data['title']="Add News";
            $data['page']='news/addnews';
           $this->load->view('templates/content',$data);  
        }
        else
        {
           $temp=$this->upload->do_upload('news_images');
            if($temp)
            {
              
              $imgarr = $this->upload->data();
              $fname = $imgarr['file_name'];
			    $this->upload->resize($fname,$config['upload_path'],$config['upload_path'].'thumbs/',500);
				 if(file_exists("../uploads/news_image/".$fname))
				{
					unlink("../uploads/news_image/".$fname);
				}
              $flag=$this->nm->addnews($fname);
        
              $this->session->set_userdata('insert','News Insert Successfully...');
              redirect('news/news');
            }
            else
            {
                $this->session->set_userdata('imgerr',$this->upload->display_errors());
                $data['page']='news/addnews';
                $this->load->view('templates/content',$data); 
            }
        }    
    
  }
   
  //edit function
  public function edit($id=FALSE)
  {
    if($id)
    {

      $data['news_item'] = $this->nm->get_news($id);
      if (empty($data['news_item']))
      {
            $this->session->set_userdata('notfound',"News Id Not Found");
            redirect('news/news/');
      }
    $config['upload_path'] = "../uploads/news_image/";
    $config['allowed_types'] = 'gif|jpg|png|jpeg';
    $config['max_size'] = '100000';
    $config['max_width']  = '2000';
    $config['max_height']  = '2000';
    $this->load->library('upload', $config);    
    $this->form_validation->set_rules('news_title', 'News Title', 'required|trim|min_length[5]|max_length[100]');
    $this->form_validation->set_rules('news_desc', 'News Description', 'required|trim|min_length[5]|max_length[1000]');
    if ($this->form_validation->run() == FALSE)
      {
           $data['title']="Edit News";
           $data['page'] = 'news/edit';
          $this->load->view('templates/content',$data);  
      }
      else
      {
        $oldimage =  $this->input->post('old_img');
          $this->upload->do_upload('news_images');
          $imgarr = $this->upload->data();
          $fname = $imgarr['file_name'];
		  $this->upload->resize($fname,$config['upload_path'],$config['upload_path'].'thumbs/',500);
					
					if($fname !="")
					{
						if(file_exists("../uploads/news_image/thumbs/".$oldimage))
						{
							
							unlink("../uploads/news_image/thumbs/".$oldimage);
						}
						if(file_exists("../uploads/news_image/".$fname))
						{
							unlink("../uploads/news_image/".$fname);
						}
						$imgname=$fname;
						 $result=$this->nm->editnews($imgname);
					}
					else
					{
						$imgname=$oldimage;
						$this->upload->resize($imgname,$config['upload_path'],$config['upload_path'].'thumbs/',500);
						
						$result=$this->nm->editnews($imgname);
						
					}
            
         if($result)
          {
            $this->session->set_userdata('edit','News Update Successfully...');
            redirect('news/news');
          
        }
        
      }
    }
      else
      {
      	$this->session->set_userdata('notfound',"News Id Not Found");
            redirect('news/news/');
      }
}
//delete function
  public function delete($id=FALSE)
  {
    if($id)
    {
      $data['news_item'] = $this->nm->get_news($id);
      if (empty($data['news_item']))
      {
            $this->session->set_userdata('notfound',"News Id Not Found");
            redirect('news/news/');
      }
     $oldimage=$data['category_item']->category_img;
			if(file_exists("../uploads/news_image/".$oldimage) or file_exists("../uploads/category_image/thumbs/".$oldimage))
			{
				//unlink("../uploads/news_image/".$oldimage);
				unlink("../uploads/news_image/thumbs/".$oldimage);
			}
       $this->nm->delete_news($id);
      $this->session->set_userdata('del','News Deleted Succesfully...');
      redirect('news/news');
      
    }
    else
    {

        $this->session->set_userdata('notfound',"News Id Not Found");
       redirect('news/news'); 
    }
   
  }
}
?>