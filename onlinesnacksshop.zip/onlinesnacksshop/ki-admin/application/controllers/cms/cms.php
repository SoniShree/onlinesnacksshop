<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class cms extends CI_Controller
{
	public function __construct()
   {
      parent::__construct();
      $is_logged_in=$this->session->userdata('is_logged_in');
      if(!isset($is_logged_in) || $is_logged_in != TRUE)
      {
        redirect('login');
      }
      
      $this->load->model('cms/cms_model','nm');
      $this->load->model('website_model','wm');
      $this->load->helper('date');
      $this->load->library('form_validation');

    
   }
   public function index()
   
   {    
   	$data['contact']=$this->wm->contact_details();
	$data['total_contact']=$this->wm->get_contact_row();
    $data['title']="CMS";
    $data['cms']=$this->nm->get_cms_page();
    $data['page']='cms/cms_view';
    $this->load->view('templates/content',$data);

   }
   //view function
  public function view($id)
   {
      $data['cms_item'] = $this->nm->get_cms($id);
      if (empty($data['cms_item']))
      {
        redirect('pagenotfound');
      }
	      $data['title']="View Page";
      $data['page']='cms/viewcms';
      $this->load->view('templates/content',$data);  

   }
   //add cms function
   public function addcms()
   {
           $data['title']="Add Page";
        $data['page']='cms/addcms';
        $this->load->view('templates/content',$data);  
   }
   //add cms
   public function addnew()
   {    
     $this->form_validation->set_rules('cms_title', 'Title', 'required|trim|min_length[4]|max_length[100]');
     $this->form_validation->set_rules('cms_desc', 'Description', 'required|trim');
	
     $this->form_validation->set_rules('url_key', 'Title', 'required|trim|min_length[1]|max_length[255]');
     $this->form_validation->set_rules('meta_keywords', 'cms Description', 'required|trim');
     $this->form_validation->set_rules('meta_desc', 'cms Description', 'required|trim');
     
        if ($this->form_validation->run() == FALSE)
        {
			    $data['title']="Add Page";
            $data['page']='cms/addcms';
           $this->load->view('templates/content',$data);  
        }
        else
        {
           
              $flag=$this->nm->addcms();
              $this->session->set_userdata('insert','Page Insert Successfully...');
              redirect('cms/cms');

        }    
    
  }
   
  //edit function
  public function edit($id=FALSE)
  {
    if($id)
    {
	    $data['title']="Edit Page";
      $data['cms_item'] = $this->nm->get_cms($id);
      if (empty($data['cms_item']))
      {
            $this->session->set_userdata('notfound',"Page Id Not Found");
            redirect('cms/cms/');
      }
     $this->form_validation->set_rules('cms_title', 'Title', 'required|trim|min_length[4]|max_length[100]');
     $this->form_validation->set_rules('cms_desc', 'Description', 'required|trim');
     $this->form_validation->set_rules('meta_keywords', 'Meta Keywords', 'required|trim');
     $this->form_validation->set_rules('meta_desc', 'Meta Description', 'required|trim');
    if ($this->form_validation->run() == FALSE)
      {
           $data['title']="Edit Page";
           $data['page'] = 'cms/edit';
          $this->load->view('templates/content',$data);  
      }
      else
      {
              $result=$this->nm->editcms();
              if($result)
              {
                $this->session->set_userdata('edit','Page Update Successfully...');
                redirect('cms/cms');

              }
      	}
      }

    
    else
    {
         $this->session->set_userdata('notfound',"Page Id Not Found");
        redirect('cms/cms');
    }
      
      
  }
    
//delete function
  public function delete($id=FALSE)
  {
    if($id)
    {
      $data['cms_item'] = $this->nm->get_cms($id);
      if (empty($data['cms_item']))
      {
            $this->session->set_userdata('notfound',"Page Id Not Found");
            redirect('cms/cms/');
      }
       $this->nm->delete_cms($id);
      $this->session->set_userdata('del','Page Deleted Succesfully...');
      redirect('cms/cms');
      
    }
    else
    {

       $this->session->set_userdata('notfound',"Page Id Not Found");
       redirect('cms/cms'); 
    }
   
  }
  function image_unlink($str)
	{
		$dir = '../uploads/redactor/';
		if(isset($str))
		{
			$img=$str;
			if(file_exists($dir.$img))
			{
				unlink($dir.$img);
			}
		}
	}
}

?>