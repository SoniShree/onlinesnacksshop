<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class customer extends CI_Controller
{
	public function __construct()
   {
      parent::__construct();
      $is_logged_in=$this->session->userdata('is_logged_in');
      if(!isset($is_logged_in) || $is_logged_in != TRUE)
      {
        redirect('login');
      }
 
      $this->load->model('customer/customer_model','nm');
      $this->load->model('website_model','wm');
              $data['contact']=$this->wm->contact_details();
		$data['total_contact']=$this->wm->get_contact_row();

      $this->load->helper('date');
      $this->load->library('form_validation');

    
   }


   public function index()
   
   {
   	$data['contact']=$this->wm->contact_details();
		$data['total_contact']=$this->wm->get_contact_row();
		
        $data['title']="customer";
    $data['customer']=$this->nm->get_customer_page();
    $data['page']='customer/customer_view';
    $this->load->view('templates/content',$data);

   }
   //view function
  public function view($id=FALSE)
   {
   	if($id)
   	{
      $data['customer_item'] = $this->nm->get_customer($id);
      if (empty($data['customer_item']))
      {
        $this->session->set_userdata('notfound',"customer Id Not Found");
            redirect('customer/customer/');
      }
	      $data['title']="View customer";
      $data['page']='customer/viewcustomer';
      $this->load->view('templates/content',$data);  
  }
  else
  {
  		    $this->session->set_userdata('notfound',"customer Id Not Found");
            redirect('customer/customer/');
  }
   }
   //add customer function
   public function addcustomer()
   {
           $data['title']="Add customer";
        $data['page']='customer/addcustomer';
        $this->load->view('templates/content',$data);  
   }
   //add customer
   public function addnew()
   {
 
     $this->load->library('form_validation');
	     $this->form_validation->set_rules('customer_fname', 'FirstName', 'required|trim|min_length[3]|max_length[20]|alpha');
		 $this->form_validation->set_rules('customer_lname', 'LastName', 'required|trim|min_length[3]|max_length[20]|alpha');
	     $this->form_validation->set_rules('customer_username', 'Username', 'required|trim|min_length[5]|max_length[20]|alpha_numeric|is_unique[customer.customer_username]');
	     $this->form_validation->set_rules('customer_mobile', 'Mobile No', 'required|trim|min_length[10]|max_length[10]|is_natural_no_zero|is_unique[customer.customer_mobile]');
	     $this->form_validation->set_rules('customer_email', 'Email', 'valid_email|is_unique[customer.customer_email]');
	     $this->form_validation->set_rules('customer_password', 'Password', 'required|trim|min_length[5]|max_length[20]');
	    if ($this->form_validation->run() == FALSE)
        {

        		$this->addcustomer();

        }
        else
        {
        	  $flag=$this->nm->addcustomer();
        	if($flag)
        	{
        		$this->session->set_userdata('insert','customer Insert Successfully...');
              redirect('customer/customer');    	
        	}
        }
            
              
    
  }
   
  //edit function
  public function edit($id=FALSE)
  {
    
	    $result=$this->nm->editcustomer($id);
		
         if($result)
          {
            $this->session->set_userdata('edit','customer Update Successfully...');
            redirect('customer/customer');
          
       		 }
        
    
 }
//delete function
  public function delete($id=FALSE)
  {
    if($id)
    {
      $data['customer_item'] = $this->nm->get_customer($id);
      if (empty($data['customer_item']))
      {
            $this->session->set_userdata('notfound',"customer Id Not Found");
            redirect('customer/customer/');
      }
      $this->nm->delete_customer($id);
      $this->session->set_userdata('del','customer Deleted Succesfully...');
      redirect('customer/customer');
      
    }
    else
    {

        $this->session->set_userdata('notfound',"customer Id Not Found");
       redirect('customer/customer'); 
    }
   
  }
	
}
?>