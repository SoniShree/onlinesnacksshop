<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class master extends CI_Controller
{
	public function __construct()
   {
      parent::__construct();
	  $master=$this->session->userdata('master');
	  if(!isset($master))
		{
	       redirect('login');
		}
      $this->load->model('master_model','nm');
      $this->load->helper('date');
      $this->load->library('form_validation');

    
   }

	public function logout()
	{
		$this->session->unset_userdata('master');
		redirect('login');
	}
   public function index()
   
   {
	   $master=$this->session->userdata('master');
	   if(!isset($master))
		{
	       redirect('login');
		}
    $data['title']="Master Admin";
    $data['master']=$this->nm->get_master_page();
    $data['page']='master/master_view';
    $this->load->view('templates/content',$data);

   }
   //view function
  public function view($id=FALSE)
   {
	   $master=$this->session->userdata('master');
	     if(!isset($master))
		{
	       redirect('login');
		}
   	if($id)
   	{
      $data['master_item'] = $this->nm->get_master($id);
      if (empty($data['master_item']))
      {
        $this->session->set_userdata('notfound',"Admin Id Not Found");
            redirect('master');
      }
	      $data['title']="View Admin";
      $data['page']='master/viewmaster';
      $this->load->view('templates/content',$data);  
  }
  else
  {
  		    $this->session->set_userdata('notfound',"Admin Id Not Found");
            redirect('master');
  }
   }
   //add master function
   public function addmaster()
   {
	   $master=$this->session->userdata('master');
	     if(!isset($master))
		{
	       redirect('login');
		}
           $data['title']="Add Admin";
        $data['page']='master/addmaster';
        $this->load->view('templates/content',$data);  
   }
   //add master
   public function addnew()
   {
	   $master=$this->session->userdata('master');
   if(!isset($master))
		{
	       redirect('login');
		}
     $this->load->library('form_validation');
	     $this->form_validation->set_rules('master_fname', 'FirstName', 'required|trim|min_length[3]|max_length[20]|alpha');
		 $this->form_validation->set_rules('master_lname', 'LastName', 'required|trim|min_length[3]|max_length[20]|alpha');
		$this->form_validation->set_rules('master_username', 'Username', 'required|trim|min_length[5]|max_length[20]|alpha_numeric');
	     $this->form_validation->set_rules('master_email', 'Email', 'valid_email');
	     $this->form_validation->set_rules('master_password', 'Password', 'required|trim|min_length[5]|max_length[20]');
	    if ($this->form_validation->run() == FALSE)
        {

        		$this->addmaster();

        }
        else
        {
        	  $flag=$this->nm->addmaster();
        	if($flag)
        	{
        		$this->session->set_userdata('insert','Admin Insert Successfully...');
              redirect('master');    	
        	}
        }
            
              
    
  }
   
  //edit function
  public function edit($id=FALSE)
  {
	  $master=$this->session->userdata('master');
      if(!isset($master))
		{
	       redirect('login');
		}
	 if($id)
    {

      $data['master_item'] = $this->nm->get_master($id);
      if (empty($data['master_item']))
      {
            $this->session->set_userdata('notfound',"Admin Id Not Found");
            redirect('master');
      }
	  $this->load->library('form_validation');
	     $this->form_validation->set_rules('master_fname', 'FirstName', 'required|trim|min_length[3]|max_length[20]|alpha');
		 $this->form_validation->set_rules('master_lname', 'LastName', 'required|trim|min_length[3]|max_length[20]|alpha');
		$this->form_validation->set_rules('master_username', 'Username', 'required|trim|min_length[5]|max_length[20]|alpha_numeric');
	     $this->form_validation->set_rules('master_email', 'Email', 'valid_email');
	     $this->form_validation->set_rules('master_password', 'Password', 'required|trim|min_length[5]|max_length[20]');
    	if ($this->form_validation->run() == FALSE)
      {
           $data['title']="Edit News";
           $data['page'] = 'master/edit';
          $this->load->view('templates/content',$data);  
      }
      else
      {
		  
		 $result=$this->nm->editmaster($id);      
         if($result)
          {
            $this->session->set_userdata('edit','Admin Update Successfully...');
            redirect('master');
          
        }
        
      }
    }
      else
      {
      	$this->session->set_userdata('notfound',"Admin Id Not Found");
            redirect('master');
      } 
    
 }
//delete function
  public function delete($id=FALSE)
  {
	  $master=$this->session->userdata('master');
	    if(!isset($master))
		{
	       redirect('login');
		}
    if($id)
    {
      $data['master_item'] = $this->nm->get_master($id);
      if (empty($data['master_item']))
      {
            $this->session->set_userdata('notfound',"Admin Id Not Found");
            redirect('master');
      }
      $this->nm->delete_master($id);
      $this->session->set_userdata('del','Admin Deleted Succesfully...');
      redirect('master');
      
    }
    else
    {

        $this->session->set_userdata('notfound',"Admin Id Not Found");
       redirect('master'); 
    }
   
  }
	
}
?>