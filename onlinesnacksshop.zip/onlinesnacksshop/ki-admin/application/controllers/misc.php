<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');
 class Misc extends CI_Controller
 {
	 public function __construct()
	 {
		 parent::__construct();
		  
		  $this->load->model('misc_model');
			 
	 }
	
	public function get_emailcount()
	{
		echo $this->session->userdata('emails');
	}
	public function get_emailsent()
	{
		echo $this->session->userdata('emailssent');
	}
	public function sendbulkmail()
	{
		$this->load->helper('form');
		$this->load->library('form_validation');
		$this->form_validation->set_rules('bulksub', 'Subject', 'trim|required|min_length[10]');
		$this->form_validation->set_rules('bulkdesc', 'Description', 'trim|required|min_length[25]');
		if ($this->form_validation->run() == FALSE)
		{
				echo 0;
		}
		else
		{
									$subject = $this->input->post('bulksub');
									$desc = $this->input->post('bulkdesc');
																								
									//echo $subject."<br>".$desc;die;
									$emaillist = $this->misc_model->get_email_list($this->input->post('eids'));
									$this->session->set_userdata('emails',100);
									$tot=sizeof($emaillist);
									$count=sizeof($emaillist);
									foreach($emaillist as $value)
									{
										//$desc = str_replace('{email}',$value->subs_id,$desc);
									
									
									//echo $emails;die;
										
										/* 'protocol' => 'smtp',
			  'smtp_host' => 'ssl://smtp.googlemail.com',
			  'smtp_port' => 465,
			  'smtp_user' => 'sarfarajkazi7@gmail.com', // change it to yours
			  'smtp_pass' => '9033200540', //				 */
								 $config = array(
								  'mailtype' => 'html',
								  'charset' => 'iso-8859-1',
								  'wordwrap' => TRUE
								);
									$this->load->library('email', $config);
										$this->email->clear();
										$this->email->set_newline("\r\n");
							  $this->email->from('info@pragnyafoodproducts.com','Pragnyafoodproducts'); // change it to yours
										$this->email->to($value->email_id);
										//$this->email->to($indemail);// change it to yours
										$this->email->subject($subject);
										
										$this->email->message($desc);
										$this->email->send();
										$this->session->set_userdata('emailssent',$count/$tot*100);
										$count--;
									}
									echo 1;	
									$this->session->unset_userdata('emailssent');
									$this->session->unset_userdata('emails');
			}
	}
	
  }
?>