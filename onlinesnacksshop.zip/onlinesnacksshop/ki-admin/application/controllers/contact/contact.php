<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Contact extends CI_Controller 
{
	public function __construct()
	{
		parent::__construct();
		$this->load->model('contact/contact_model');
		   $this->load->model('website_model','wm');
	}
	public function index()
	{
		//$this->load->model('contact_model');
		//$this->page();
		$data['contact']=$this->wm->contact_details();
		$data['total_contact']=$this->wm->get_contact_row();
		
				$data['title']="Feedbacks";
		$data['result'] = $this->contact_model->get_page();
		$data['page'] = 'contact/contact_list';
		$this->load->view('templates/content',$data);
	}
	public function changestatus($id)
	{
		if($id)
		{
			
			$result=$this->contact_model->updatestatus($id);
			redirect('contact/contact');
			
			
				   
		}    
		else
			{
				$this->session->set_userdata('err','Id Not Found');
				redirect('contact/contact');
			}
	
	}
	public function delete($contact_id=NULL)
	{
		if($contact_id == NULL)
		{
			
				$this->session->set_userdata('err',"No Such page Found To delete.");
				redirect('contact');
		}
		else
		{
				$rec = $this->contact_model->get_rec($contact_id);
				if(empty($rec))
				{
						$this->session->set_userdata('err',"No record found!!!");
						redirect('contact/contact');

				}
			
				
			$this->contact_model->delete_contact($contact_id);
			$data['contact'] = $this->contact_model->con_list_model($contact_id);
			$this->session->set_userdata('msg','Contact Delete Successfully');
			redirect('contact/contact');
		}
	}
	public function view_contact($contact_id=0)
	{
		if($contact_id == "")
		{
				$this->session->set_userdata('err',"No Record Found.");
				redirect('contact/contact');
		}
		else
		{
			$this->norec($contact_id);
		$data['title']="View FeedBack";
		$data['result'] = $this->contact_model->con_view_model($contact_id);
		$data['page']='contact/view_contact';
		$this->load->view('templates/content',$data);
		}
		
	}
	public function norec($contact_id)
	{
		$res=$this->contact_model->findrecord($contact_id);
		if($res)
		{
			$this->session->set_userdata('err','No Record Found');
			redirect('contact/contact');
		}
	}
	
		
}
?>