<?php
 if ( ! defined('BASEPATH')) exit('No direct script access allowed');
 class Newsletter extends CI_Controller
 {
	 public function __construct()
	 {
		 parent::__construct();
		 
		  $this->load->model('newsletter_model');
		  $this->load->model('misc_model');
		  
		
	 }
	 
	public function index()
	{
				
				
				$data['subs'] = $this->newsletter_model->search();
				$data['title']="News Letter";
				$data['page']= 'newsletter/subs_list';
				$this->load->view('templates/content',$data);
	}
	
	public function delete($id = NULL)
	{
			
		if($id == NULL)
		{
			redirect('newsletter');
		}
		if(!is_numeric($id))
		{
			redirect('newsletter');
		}
		$resdel = $this->newsletter_model->delete_news($id);
		if($resdel)
		{
			$this->session->set_userdata('succ','Subscriber Deleted Succesfully');
			redirect('newsletter');
		}
		else
		{
			redirect('newsletter');
		}
	}
	public function change_newsletter_status($id=FALSE,$status=FALSE)
    {
		$this->newsletter_model->update_status($id,$status);	
		redirect('newsletter');
	}
	
	
  }
?>