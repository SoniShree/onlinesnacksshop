<?php
	class Backup extends CI_Controller
	{
		public function __construct()
		{
			parent::__construct();
			
			$this->load->model('website_model');
			$isLoggedin=$this->session->userdata('is_logged_in');
			if(!isset($isLoggedin) || $isLoggedin != TRUE )
			{
				redirect('login');
			}
		}
		
		
		
		public function index()
		{
			
			$dir    = '../backups/';
			$data['files'] = get_filenames($dir);
			
			//$data['admin_data']=$this->website_model->get_details();
			$data['title']="Backup";
			$data['page'] = 'backup/backup';
			$this->load->view('templates/content',$data);
		}
		
		public function backupsql()
		{
			
			$this->load->dbutil();
			$data = array(
					'host' => 'localhost',
					'user' => 'root',
					'pass' => '',
					'dbname' => 'onlinesnacksstore',
                	'format' => 'txt',
                	'add_drop'  => TRUE,
                	'add_insert' => TRUE,
					'ignore'      => array('mssessions'),
                	'newline'  => "\n"
					);
					
			
       		$backup =& $this->dbutil->backup($data);
			
			$db_name = 'onlinesnacksstore_backup_'. date("Y-m-d-H-i-s").'.sql'; 
			$save = '../backups/'.$db_name;
       		write_file($save, $backup);
			$this->session->set_userdata('succ',"Database Backup Successfull!!!");
			redirect('backup');
		}
		
		public function delete($file=NULL)
		{
			if($file == NULL)
			{
				redirect('tools');
			}
			else
			{
				unlink("../backups/$file");	
				$this->session->set_userdata('succ',"Backup Deleted Successfully!!!");
				redirect('backup');
			}
		}
		
		public function download($file=NULL)
		{
			if($file == NULL)
			{
				redirect('backup');
			}
			else
			{
				$this->load->helper('download');
				$dir =  file_get_contents("../backups/".$file);
				
				
				$filename = $file;
				force_download($filename,$dir);
				redirect('backup');
			}
		}
		
		public function restore($file)
		{
			if($file == NULL)
			{
				redirect('backup');
			}
			else
			{
				$this->load->helper('download');
				$dir =  file_get_contents("../backups/".$file);
				$sqlinfo = explode(";\n",$dir);
				
				
				//$this->load->model('backup_model');
				
				//$ses = $this->backup_model->get_sessions();
				//echo"<pre>";print_r($sqlinfo);die;
				//echo"<pre>";print_r($ses);die;
				foreach($sqlinfo as $sqldata)
				{
					if (trim($sqldata))
					{
						$this->db->query("SET FOREIGN_KEY_CHECKS = 0");
						$this->db->query($sqldata);
						$this->db->query("SET FOREIGN_KEY_CHECKS = 1");
					}
				}
				
				
				
				
				redirect();
				
				
				
			}
		}
		
		
		
		public function delete_multiple()
		{
		if($this->input->post('del'))
		{
			$box = $this->input->post('selector');
			if($box == "")
			{
				$this->session->set_userdata('err','Please select at least 1 record... ');
				redirect('backup');
			}
			else
			{
				foreach($box as $key => $value)
				{
					
					//echo $value;die;
					$msg = "Backup Deleted ...";
					
					if(file_exists('../backups/'.$value))
					{
						unlink('../backups/'.$value);
						
						
					}
						
					$this->session->set_userdata('succ','File Deleted Successfully');	
					
				}
			}
			
			redirect('backup');
		}
	}
}
?>