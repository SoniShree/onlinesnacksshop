<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class category extends CI_Controller
{
	public function __construct()
   {
      parent::__construct();
      $is_logged_in=$this->session->userdata('is_logged_in');
      if(!isset($is_logged_in) || $is_logged_in != TRUE)
      {
        redirect('login');
      }
 
      $this->load->model('category/category_model','nm');
      $this->load->model('website_model','wm');
              $data['contact']=$this->wm->contact_details();
		$data['total_contact']=$this->wm->get_contact_row();

      $this->load->helper('date');
      $this->load->library('form_validation');
   }
   public function index()
   
   {
    $data['title']="Category";
    $data['contact']=$this->wm->contact_details();
		$data['total_contact']=$this->wm->get_contact_row();
	
    $data['category']=$this->nm->get_category_page();
    $data['page']='category/category_view';
    $this->load->view('templates/content',$data);

   }
   //view function
  public function view($id)
   {
      $data['category_item'] = $this->nm->get_category($id);
      if (empty($data['category_item']))
      {
        redirect('pagenotfound');
      }
	      $data['title']="View Category";
      $data['page']='category/viewcategory';
      $this->load->view('templates/content',$data);  

   }
   //add category function
   public function addcategory()
   {
           $data['title']="Add Category";
        $data['page']='category/addcategory';
        $this->load->view('templates/content',$data);  
   }
   //add category
   public function addnew()
   {
	   if(!is_dir('../uploads/category_image/thumbs/'))
		{
			mkdir('../uploads/category_image/thumbs/',0777,true);
			
		}
    $config['upload_path'] = "../uploads/category_image/";
    $config['allowed_types'] = 'gif|jpg|png|jpeg';
    $config['max_size'] = '100000';
    $config['max_width']  = '2000';
    $config['max_height']  = '2000';
    $this->load->library('upload', $config); 
     $this->form_validation->set_rules('category_title', 'category Title', 'required|trim|min_length[5]|max_length[100]');
     $this->form_validation->set_rules('category_desc', 'category Description', 'required|trim|min_length[5]');
        if ($this->form_validation->run() == FALSE)
        {
        	$data['title']="Add Category";
            $data['page']='category/addcategory';
           $this->load->view('templates/content',$data);  
        }
        else
        {
           $temp=$this->upload->do_upload('category_images');
            if($temp)
            {
              
              $imgarr = $this->upload->data();
              $fname = $imgarr['file_name'];
			   $this->upload->resize($fname,$config['upload_path'],$config['upload_path'].'thumbs/',500);
				 if(file_exists("../uploads/category_image/".$fname))
				{
					unlink("../uploads/category_image/".$fname);
				}
              $flag=$this->nm->addcategory($fname);
              $this->session->set_userdata('insert','Category Insert Successfully...');
              redirect('category/category');
            }
            else
            {
                $this->session->set_userdata('imgerr',$this->upload->display_errors());
				    $data['title']="Add Category";
                $data['page']='category/addcategory';
                $this->load->view('templates/content',$data); 
            }
        }    
    
  }
   
  //edit function
	public function edit($id=FALSE)
	{
		if($id)
		{
			$data['category_item'] = $this->nm->get_category($id);
			if (empty($data['category_item']))
			{
				$this->session->set_userdata('notfound',"category Id Not Found");
				redirect('category/category/');
			}
			$config['upload_path'] = "../uploads/category_image/";
			$config['allowed_types'] = 'gif|jpg|png|jpeg';
			$config['max_size'] = '100000';
			$config['max_width']  = '2000';
			$config['max_height']  = '2000';
			$this->load->library('upload', $config);
			$this->form_validation->set_rules('category_title', 'category Title', 'required|trim|min_length[5]|max_length[100]');
			$this->form_validation->set_rules('category_desc', 'category Description', 'required|trim|min_length[5]');
			if ($this->form_validation->run() == FALSE)
			{
				    $data['title']="Edit Category";
				$data['page'] = 'category/edit';
				$this->load->view('templates/content',$data);  
			}
			else
			{
				$oldimage =  $this->input->post('old_img');
				$this->upload->do_upload('category_images');
				$imgarr = $this->upload->data();
				$fname = $imgarr['file_name'];
				$this->upload->resize($fname,$config['upload_path'],$config['upload_path'].'thumbs/',500);
					
					if($fname !="")
					{
						if(file_exists("../uploads/category_image/thumbs/".$oldimage))
						{
							
							unlink("../uploads/category_image/thumbs/".$oldimage);
						}
						if(file_exists("../uploads/category_image/".$fname))
						{
							unlink("../uploads/category_image/".$fname);
						}
						$imgname=$fname;
						$result=$this->nm->editcategory($imgname);
					}
					else
					{
						$imgname=$oldimage;
						$this->upload->resize($imgname,$config['upload_path'],$config['upload_path'].'thumbs/',500);
						
						$result=$this->nm->editcategory($imgname);
						
					}
				if($result)
				{
					$this->session->set_userdata('edit','category Update Successfully...');
					redirect('category/category');
				}
			}
		}
		else
		{
			$this->session->set_userdata('notfound',"category Id Not Found");
			redirect('category/category/');
		}
	}
    
//delete function
  public function delete($id=FALSE)
  {
    if($id)
    {
		
      $data['category_item'] = $this->nm->get_category($id);
      if (empty($data['category_item']))
      {
            $this->session->set_userdata('notfound',"category Id Not Found");
            redirect('category/category/');
      }
	  $oldimage=$data['category_item']->category_img;
			if(file_exists("../uploads/category_image/".$oldimage) or file_exists("../uploads/category_image/thumbs/".$oldimage))
			{
				//unlink("../uploads/category_image/".$oldimage);
				unlink("../uploads/category_image/thumbs/".$oldimage);
			}
       $this->nm->delete_category($id);
      $this->session->set_userdata('del','category Deleted Succesfully...');
      redirect('category/category');
      
    }
    else
    {

        $this->session->set_userdata('notfound',"category Id Not Found");
       redirect('category/category'); 
    }
   
  }
}
?>