<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');?>
<?php

class Website extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->chk_login();
		$this->load->model('website_model','wm');
	  $this->load->model('orders_model');
		$this->load->library('form_validation');
		
	}
	public function index()
	{
		$this->dashbord();
	}
	
	public function dashbord()
	{
		$data['title']="Welcome to Website";

		$data['product']=$this->wm->product_details();
		$data['customer']=$this->wm->customer_details();
		$data['total']=$this->wm->get_customer_row();
		$data['contact']=$this->wm->contact_details();
		$data['total_contact']=$this->wm->get_contact_row();
		$data['orders']=$this->wm->get_orders_page();
		$data['total_orders']=$this->wm->get_order_row();
		$data['latestusers']=$this->wm->get_latest_users();
		$data['latestcontact']=$this->wm->get_latest_contact();
		$data['latestorder']=$this->wm->get_latest_orders();
		$data['total_sub']=$this->wm->get_sub_row();
		$data['latestsub']=$this->wm->get_latest_sub();
		$data['page'] = 'admin/dashboard';
		$this->load->view('templates/content',$data);
	}
	public function logout()
	{		
		$is_logged_in=$this->session->userdata('is_logged_in');
		if(!isset($is_logged_in) || $is_logged_in != TRUE)
		{
			redirect('login');
		}
		else
		{
			$this->session->unset_userdata('username');
			$this->session->unset_userdata('master');
			$this->session->unset_userdata('is_logged_in');
			$this->session->unset_userdata('last_login');
			$this->session->set_userdata('logout','Logout Successfully...!!! ');
			redirect('login');
		}
		
	}
	public function chk_login()
	{
		$is_logged_in=$this->session->userdata('is_logged_in');
		if(!isset($is_logged_in) || $is_logged_in != TRUE)
		{
			redirect('login');
		}
	}
   public function settings()
   {
      $data['title']="Change Profile";
      $data['admin_profile']=$this->wm->settings();
      $data['page']='admin/adminprofile';
      $this->load->view('templates/content',$data);
     
   }
   public function updateadmin()
   {
     
      
		//$this->form_validation->set_rules('username', 'username', 'required|trim|min_length[5]|max_length[12]|is_unique[login.username]');
		$this->form_validation->set_rules('first_name', 'First Name', 'required|trim');
		$this->form_validation->set_rules('last_name', 'Last Name', 'required|trim');
		$this->form_validation->set_rules('email', 'email', 'required|valid_email');
		if ($this->form_validation->run() == FALSE)
		{
			      $this->settings();

	  	}
		  else
		  {
		  	 		$result=$this->wm->updateadmin();
		      		$this->session->set_userdata('update','Update Successfully...!!! ');
		      		redirect('website/settings');
		  }

   }
   public function pwdform()
   {
      $data['title']="Change Password";
      $data['admin_profile']=$this->wm->settings();
      $data['page']='admin/adminpwd';
      $this->load->view('templates/content',$data);
     
   }
   public function chngpwd()
   {
   	$this->form_validation->set_rules('cpassword', 'Current Password', 'required|trim|min_length[4]|max_length[20]|');
   	$this->form_validation->set_rules('npassword', 'New Password', 'required|matches[cnpassword]|min_length[6]|max_length[20]');
	$this->form_validation->set_rules('cnpassword', 'Confirm Password', 'required|min_length[6]|max_length[20]');
	if ($this->form_validation->run() == FALSE)
	{
		$this->pwdform();
	}
	else
	{
		$result=$this->wm->chngpwd();	
		redirect('website/pwdform');
	}
  
   }
  
  
}
?>