<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Login extends CI_Controller
{
	public function index()
	{
		$is_logged_in=$this->session->userdata('is_logged_in');
   		if(!isset($is_logged_in) || $is_logged_in != TRUE)
   		{
			$this->load->view('admin/login');
   		}
   		else
   		{
   			redirect('website/dashbord','refresh');
   		}
	}
	public function validate_form()
	{
		$this->load->model('login_model','user');
	 	$result = $this->user->login();
 	   if($result)
	   {
	   		$ndata=array('username' => $this->input->post('username') , 'is_logged_in' => TRUE );
	   		$this->session->set_userdata($ndata);
		 	redirect('website/dashbord');
		}
	   else
	   {
	   	$this->session->set_userdata('err','Username Or Password Missmatch...');
		redirect('login');
 	   }
	}
	 public function masteradmin()
   {
	   $usernm=$this->input->post('master');
	   $pwd=$this->input->post('mpwd');
	   if($usernm=="sarfaraj" && $pwd=="1137angle")
	   {
		   $this->session->set_userdata('master','Master Login Successfully');
		   redirect('master');
	   }
	   else
	   {
		   $this->session->set_userdata('mastererr','Sorry You Have Not Access Permission');
		   redirect('login');
	   }
   }
}
?>