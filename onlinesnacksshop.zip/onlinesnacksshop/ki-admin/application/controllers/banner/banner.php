<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Banner extends CI_Controller
{
	public function __construct()
   {
      parent::__construct();
      $is_logged_in=$this->session->userdata('is_logged_in');
      if(!isset($is_logged_in) || $is_logged_in != TRUE)
      {
        redirect('login');
      }
      $this->unset_sessions();
      $this->load->model('banner/banner_model','nm');
      $this->load->model('website_model');
      $this->load->helper('date');
      $this->load->library('form_validation');  
   }
   public function unset_sessions()
   {
      $this->session->unset_userdata('search');
   }
   public function index()
   
   {
    $data['title']="Banner";
    $data['banner']=$this->nm->get_banner_page();
	$data['page']='banner/banner_view';
    $this->load->view('templates/content',$data);

   }
   //view function
  public function view($id)
   {
      $data['banner_item'] = $this->nm->get_banner($id);
	  
	  
      if (empty($data['banner_item']))
      {
        redirect('pagenotfound');
      }
	      $data['title']="View banner";
      $data['page']='banner/viewbanner';
      $this->load->view('templates/content',$data);  

   }
   //add banner function
	 public function addbanner()
   {
	   
           $data['title']="Add banner";
        $data['page']='banner/addbanner';
		
        $this->load->view('templates/content',$data);  
   }
   //add banner
   public function addnew()
   {
	if(!is_dir('../uploads/banner_image/thumbs/'))
		{
			mkdir('../uploads/banner_image/thumbs/',0777,true);
		}
    $config['upload_path'] = "../uploads/banner_image/";
    $config['allowed_types'] = 'gif|jpg|png|jpeg';
    $config['max_size'] = '100000';
    $config['max_width']  = '2000';
    $config['max_height']  = '2000';
    $this->load->library('upload', $config);   
     $this->form_validation->set_rules('banner_name', 'banner name', 'required|trim|min_length[5]|max_length[100]');
     $this->form_validation->set_rules('banner_desc', 'banner Description', 'required|trim');
       if ($this->form_validation->run() == FALSE)
        {
			    $data['title']="Add banner";
            $data['page']='banner/addbanner';
           $this->load->view('templates/content',$data);  
        }
        else
        {
           $temp=$this->upload->do_upload('banner_images');
            if($temp)
            {
              
              $imgarr = $this->upload->data();
              $fname = $imgarr['file_name'];
			  $this->upload->resize($fname,$config['upload_path'],$config['upload_path'].'thumbs/',500);
              $flag=$this->nm->addbanner($fname);
			  
			  
			  
        	  
              $this->session->set_userdata('insert','banner Insert Successfully...');
              redirect('banner/banner');
            }
            else
            {
                $this->session->set_userdata('imgerr',$this->upload->display_errors());
				
                $data['page']='banner/addbanner';
                $this->load->view('templates/content',$data); 
            }
        }    
    
  }
   
  //edit function
   public function edit($id=FALSE)
  {
	  
    if($id)
    {

      $data['banner_item'] = $this->nm->get_banner($id);
      if (empty($data['banner_item']))
      {
            $this->session->set_userdata('notfound',"banner Id Not Found");
            redirect('banner/banner/');
      }
    $config['upload_path'] = "../uploads/banner_image/";
    $config['allowed_types'] = 'gif|jpg|png|jpeg';
    $config['max_size'] = '100000';
    $config['max_width']  = '2000';
    $config['max_height']  = '2000';
    $this->load->library('upload', $config);    
    $this->form_validation->set_rules('banner_name', 'banner name', 'required|trim|min_length[5]|max_length[100]');
    $this->form_validation->set_rules('banner_desc', 'banner Description', 'required|trim|min_length[5]|max_length[1000]');
    if ($this->form_validation->run() == FALSE)
      {
           $data['title']="edit banner";
           $data['page'] = 'banner/edit';
          $this->load->view('templates/content',$data);  
      }
      else
      {
        $oldimage =  $this->input->post('old_img');
          $this->upload->do_upload('banner_images');
          $imgarr = $this->upload->data();
          $fname = $imgarr['file_name'];
		  $this->upload->resize($fname,$config['upload_path'],$config['upload_path'].'thumbs/',500);
			  if($fname != "")
            {
					
					if(file_exists("../uploads/banner_image/thumbs/".$oldimage))
					{
						
						unlink("../uploads/banner_image/thumbs/".$oldimage);
					}
					if(file_exists("../uploads/banner_image/".$oldimage))
					{
						unlink("../uploads/banner_image/".$oldimage);
					}
					  $imgname = $fname;
						$result=$this->nm->editbanner($imgname);
              }	
            else
            {
             	$imgname=$oldimage; 
				  $this->upload->resize($imgname,$config['upload_path'],$config['upload_path'].'thumbs/',500);
             	$result=$this->nm->editbanner($imgname);


            }
         if($result)
          {
            $this->session->set_userdata('edit','Banner Update Successfully...');
            redirect('banner/banner');
          
        }
        
      }

    }
    else
    {
         $this->session->set_userdata('notfound',"Banner Id Not Found");
        redirect('banner/banner');
    }
      
      
  }
    
//delete function
  public function delete($id=FALSE)
  {
    if($id)
    {
      $data['banner_item'] = $this->nm->get_banner($id);
      if (empty($data['banner_item']))
      {
            $this->session->set_userdata('notfound',"banner Id Not Found");
            redirect('banner/banner/');
      }
      $oldimage=$data['banner_item']->banner_img;
    	if(file_exists("../uploads/banner_image/".$oldimage) or file_exists("../uploads/banner_image/thumbs/".$oldimage))
			{
				unlink("../uploads/banner_image/".$oldimage);
				unlink("../uploads/banner_image/thumbs/".$oldimage);
			}
       $this->nm->delete_banner($id);
      $this->session->set_userdata('del','Banner Deleted Succesfully...');
      redirect('banner/banner');
      
    }
    else
    {

        $this->session->set_userdata('notfound',"Banner Id Not Found");
       redirect('banner/banner'); 
    }
   
  }

}
?>