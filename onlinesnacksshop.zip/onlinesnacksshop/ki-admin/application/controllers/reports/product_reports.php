<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Product_reports extends CI_Controller
{
	public function __construct()
   {
      parent::__construct();
      $is_logged_in=$this->session->userdata('is_logged_in');
      if(!isset($is_logged_in) || $is_logged_in != TRUE)
      {
        redirect('login');
      }
      $this->unset_sessions();
      $this->load->model('reports/product_model','nm');
     $this->load->helper('date');
      $this->load->library('form_validation');

    
   }
   public function unset_sessions()
   {
      $this->session->unset_userdata('search');
   }
   public function index()
   {
		$data['title']="Product Reports";
		$data['product']=$this->nm->get_product_page();
		foreach($data['product'] as $a)
		{
			$qty[]=$this->nm->get_sales($a['product_id']);

		}
		foreach($qty as $t)
		{
			$tot[]=$t[0]['quantity'];
		}
		$data['total']=$tot;
		$data['page']='reports/product_view';
		$this->load->view('templates/content',$data);
   }
   public function getPdf()
	{
		$data['product']=$this->nm->get_product_page();
	
		foreach($data['product'] as $a)
		{
			$qty[]=$this->nm->get_sales($a['product_id']);
		}
		foreach($qty as $t)
		{
			
			$tot[]=$t[0]['quantity'];
		}
		$data['total']=$tot;
		$this->load->model('fpdf');
		$this->fpdf->AddPage();
		$this->fpdf->SetFont('Arial','B',30);
		$this->fpdf->cell(88,20,"Pragnya Food Product",'','','L');
		$this->fpdf->cell(0,10,"","",1,'C');
		$this->fpdf->SetFont('Arial','B',26);
		$this->fpdf->cell(88,20,"Product Report",'','','L');
		$this->fpdf->cell(0,10,"","",1,'C');
		$this->fpdf->SetFont('Arial','B',10);
		$this->fpdf->cell(56,20,"Date : ".date('Y/m/d'),'','','L');
		$this->fpdf->SetFont('Arial','B',10);
		//$this->fpdf->cell(50,20,"Total product Amount : ".$t[0]['quantity']*$t[0]['total'],"",1,'C');
		$this->fpdf->cell(0,10,"","",1,'C');						
		$this->fpdf->SetLineWidth(.3);
		//$data['totalsales'];		
		$this->fpdf->cell(0,10,"","",1,'C');
		$this->fpdf->SetFont('Arial','B',8);
        $this->fpdf->Cell(10,8,"ID",1,'','C');
		$this->fpdf->Cell(30,8,"Product Name",1,'','C');
		//$this->fpdf->Cell(50,8,"Product Image",1,'','C');
		$this->fpdf->Cell(40,8,"Product Stock Quantity",1,'','C');
		$this->fpdf->Cell(40,8,"Product Sold Quantity",1,'','C');
		$this->fpdf->Cell(30,8,"Price",1,'','C');
		$this->fpdf->Cell(40,8,"Total Amount",1,1,'C');
    	//$this->fpdf->Ln();	
		$this->fpdf->SetFillColor(220,220,220);
	    $this->fpdf->SetTextColor(0);
    	$this->fpdf->SetFont('');
		$fill = false;
		$i=0;
		foreach($data['product'] as $row)
		{
			//$fillimage=$this->fpdf->Image(base_url("../uploads/product_image")."/".$row['product_img'],20,6,10);
			$this->fpdf->Cell(10,8,ucfirst($row['product_id']),'LR',0,'C',$fill);
			$this->fpdf->Cell(30,8,ucfirst($row['product_title']),'LR',0,'C',$fill);
			//$this->fpdf->Image($fillimage,'.jpg');
			$this->fpdf->Cell(40,8,number_format($row['product_qty']),'LR',0,'C',$fill);
			$this->fpdf->Cell(40,8,number_format($tot[$i]),'LR',0,'C',$fill);
			$this->fpdf->Cell(30,8,number_format($row['product_price']),'LR',0,'C',$fill);
			$this->fpdf->Cell(40,8,number_format($tot[$i]*$row['product_price']),'LR',0,'C',$fill);
			$this->fpdf->Ln();
			$fill = !$fill;
			$i++;
		}		
		$this->fpdf->Cell(190,0,"",1,'','C');
		$this->fpdf->Output();																
	}
  
}
?>