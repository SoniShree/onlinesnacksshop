<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Customer_reports extends CI_Controller
{
	public function __construct()
   {
      parent::__construct();
      $is_logged_in=$this->session->userdata('is_logged_in');
      if(!isset($is_logged_in) || $is_logged_in != TRUE)
      {
        redirect('login');
      }
 
      $this->load->model('reports/customer_model','nm');
      $this->load->helper('date');
      $this->load->library('form_validation');

    
   }
   public function index() 
   {
    $data['title']="customer_reports";
    $data['customer']=$this->nm->get_customer_page();
    foreach($data['customer'] as $c)
	{
		$cust[]=$this->nm->get_total($c['customer_id']);
	}
	foreach($cust as $arr)
	{
		$tot[]=$arr[0]['total'];
	}
	$data['total']=$tot;
	$data['page']='reports/customer_view';
    $this->load->view('templates/content',$data);

   }
  
public function getPdf()
	{
		$data['customer']=$this->nm->get_customer_page();
		foreach($data['customer'] as $c)
		{
			$cust[]=$this->nm->get_total($c['customer_id']);
		}
		foreach($cust as $arr)
		{
			$tot[]=$arr[0]['total'];
		}
		$data['total']=$tot;		
		$this->load->model('fpdf');
		$this->fpdf->AddPage();
		//$img=base_url()."bootstrap/themes/images/logo.png";
		//$this->fpdf->Image(base_url()."bootstrap/themes/images/logo.png",10,10,'23','23','PNG');
		$this->fpdf->SetFont('Arial','B',30);
		$this->fpdf->cell(88,10,"PRAGNYA FOOD PRODUCT",'','','L');
		$this->fpdf->cell(0,10,"","",1,'C');
		$this->fpdf->SetFont('Arial','B',26);
		$this->fpdf->cell(88,10,"Customer Report",'','','L');
		$this->fpdf->cell(0,10,"","",1,'C');
		$this->fpdf->SetFont('Arial','B',10);
		$this->fpdf->cell(56,20,"Date : ".date('Y/m/d'),'','','L');
		$this->fpdf->cell(0,10,"","",1,'C');
		$this->fpdf->SetFont('Arial','B',10);
		$this->fpdf->cell(0,10,"","",1,'C');
		$this->fpdf->SetLineWidth(.3);
		//$data['totalsales'];		
		$this->fpdf->SetFont('Arial','B',8);
        $this->fpdf->Cell(10,8,"ID",1,'','C');
		$this->fpdf->Cell(35,8,"Customers Name",1,'','C');
		$this->fpdf->Cell(20,8,"Type",1,'','C');
		$this->fpdf->Cell(50,8,"Email",1,'','C');
		$this->fpdf->Cell(20,8,"Mobile",1,'','C');
		$this->fpdf->Cell(20,8,"Total Sales",1,'','C');
		$this->fpdf->Cell(40,8,"Joined Date",1,1,'C');
    	//$this->fpdf->Ln();	
		$this->fpdf->SetFillColor(220,220,220);
	    $this->fpdf->SetTextColor(0);
    	$this->fpdf->SetFont('');
		$fill = false;
		$i=0;
		foreach($data['customer'] as $row)
		{
			$this->fpdf->Cell(10,8,ucfirst($row['customer_id']),'LR',0,'C',$fill);
			$this->fpdf->Cell(35,8,ucfirst($row['customer_username']),'LR',0,'C',$fill);
			$this->fpdf->Cell(20,8,ucfirst($row['customer_type']),'LR',0,'C',$fill);
			$this->fpdf->Cell(50,8,ucfirst($row['customer_email']),'LR',0,'C',$fill);
			$this->fpdf->Cell(20,8,ucfirst($row['customer_mobile']),'LR',0,'C',$fill);
			$this->fpdf->Cell(20,8,ucfirst($tot[$i]),'LR',0,'C',$fill);
			$this->fpdf->Cell(40,8,ucfirst($row['customer_created']),'LR',0,'C',$fill);
			$this->fpdf->Ln();
			$fill = !$fill;
			$i++;
		}		
		$this->fpdf->Cell(195,0,"",1,'','C');
		$this->fpdf->Output();																
	}	
}
?>