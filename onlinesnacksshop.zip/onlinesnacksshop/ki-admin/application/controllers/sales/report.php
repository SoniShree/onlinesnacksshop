<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Report extends CI_Controller
{
	public function __construct()
   {
      parent::__construct();
   }
   public function index()
   {
	   $data['title']="Reports";
	   $data['page']="sales/report";
	   $this->load->view('templates/content',$data);
	   
   }

}
?>