<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Orders extends CI_Controller
{
	public function __construct()
   {
      parent::__construct();
	  $this->load->model('orders_model');
   }
   public function index()
   {
	   $data['orders']=$this->orders_model->get_orders_page();
	   
	   $data['title']="Orders";
	   $data['page']="sales/orders";
	   $this->load->view('templates/content',$data);
	   
   }
    public function invoice($id)
   {
	   if($id)
	   {
		   $data['invoice']=$this->orders_model->get_orders($id);
		 
		    $order_no=$data['invoice']->order_number;
		   if(!empty($data['invoice']))
		   {
			 
			  
			   $data['allrec']=$this->orders_model->show_all($id);
			  $data['allrec_items']=$this->orders_model->get_order_items($order_no);
			 
			   $data['title']="Invoice";
			   $data['page']="sales/invoice";
			   $this->load->view('templates/content',$data);
		   }
		   else
		   {
			   $this->session->set_userdata('err','Id Not Found');
			   redirect('orders');
		   }
		   
	   }
	   
	   else
	   {
		   $this->session->set_userdata('err','Id Not Found');
		   redirect('orders');
	   }
	   
   }
   public function addnotes($id)
   {
	  $res=$this->orders_model->update($id);
	  if($res)
	  {
		  $this->session->set_userdata('msg','Notes Updated');
		  redirect("sales/orders/invoice/$id");
	  }
	  
   }
    public function update_status($id)
   {
	  $res=$this->orders_model->update_status($id);
	  if($res)
	  {
		  $this->session->set_userdata('msg','Status Updated');
		  redirect("sales/orders/");
	  }
	  
   }
   
    public function delete($id=FALSE)
  {
    if($id)
    {
      $data['allrec']=$this->orders_model->get_orders($id);
      if (empty($data['allrec']))
      {
            $this->session->set_userdata('notfound',"Order Id Not Found");
            redirect('sales/orders');
      }
     
       $this->orders_model->delete_order($id);
      $this->session->set_userdata('del','Order Deleted Succesfully...');
      redirect('sales/orders');      
    }
    
   
  }
  public function packing($id)
  {
	 	if($id)
	   {
		   $data['packing']=$this->orders_model->get_orders($id);
		   $order_no=$data['packing']->order_number;
		   if(!empty($data['packing']))
		   {
			 
			  
			   $data['allrec']=$this->orders_model->show_all($id);
			   $data['allrec_items']=$this->orders_model->get_order_items($order_no);
			   $data['title']="Packing Slip";
			  
			   $this->load->view('sales/packing',$data);
		   }
		   else
		   {
			   $this->session->set_userdata('err','Id Not Found');
			   redirect('orders');
		   }
		   
	   }
	   
	   else
	   {
		   $this->session->set_userdata('err','Id Not Found');
		   redirect('orders');
	   }
  }
 public function getPdf($id)
	{
		
		$data['packing']=$this->orders_model->get_orders($id);
		$order_no=$data['packing']->order_number;
		if(!empty($data['packing']))
		{
		   $data['allrec']=$this->orders_model->show_all($id);
		   $data['allrec_items']=$this->orders_model->get_order_items($order_no);
		}		  
		$allrec=$data['allrec'];	
		
		$this->load->model('fpdf');
		$this->fpdf->AddPage();
		$this->fpdf->SetFont('Arial','B',25);

		$this->fpdf->cell(10,10,"Pragyna Foods Products",'','1','L');
		$this->fpdf->SetFont('Arial','B',10);
		$this->fpdf->Cell(10,10,'Order Number : '.$allrec->order_number,'','1','L');
		$this->fpdf->cell(10,10,"Date : ".date('Y/m/d'),'','1','L');
		$this->fpdf->cell(0,0,"","",1,'C');
		$this->fpdf->cell(60,20,"Account Info",'','','L');
		$this->fpdf->cell(60,20,"Billing Address",'','','L');
		$this->fpdf->cell(50,20,"Shipping Address",'','','L');
		$this->fpdf->cell(0,10,"","",1,'C');
		$this->fpdf->SetFont('Arial','B',8);
		$this->fpdf->Cell(10,10,'Name: ','','','L');
		$this->fpdf->Cell(10,10,ucfirst($allrec->customer_fname)." ",'','','L');
		$this->fpdf->Cell(50,10," ".ucfirst($allrec->customer_lname),'','','L');
		$this->fpdf->cell(0,8,"","",1,'C');
		$this->fpdf->Cell(10,0,'Phone:  ','','','L');
		$this->fpdf->Cell(50,0,ucfirst($allrec->customer_mobile),'','','L');
		$this->fpdf->cell(0,3,"","",1,'C');
		$this->fpdf->Cell(10,0,'Email: ','','','L');
		$this->fpdf->Cell(50,0,ucfirst($allrec->customer_email),'','','L');
		
		$this->fpdf->Cell(10,-10,'Name: ','','','L');
		$this->fpdf->Cell(10,-10,ucfirst($allrec->bill_firstname)." ",'','','L');
		$this->fpdf->Cell(-20,-10," ".ucfirst($allrec->bill_lastname),'','','L');
		$this->fpdf->Cell(-1,0,ucfirst($allrec->bill_address1),'','','L');
		$this->fpdf->Cell(10,10,'Phone:','','','L');		
		$this->fpdf->Cell(-10,10,ucfirst($allrec->bill_phone),'','','L');		
		$this->fpdf->Cell(10,20,'Email:','','','L');		
		$this->fpdf->Cell(51,20,ucfirst($allrec->bill_email),'','','L');		
		
		$this->fpdf->Cell(10,-10,'Name: ','','','L');
		$this->fpdf->Cell(10,-10,ucfirst($allrec->ship_firstname)." ",'','','L');
		$this->fpdf->Cell(-20,-10," ".ucfirst($allrec->ship_lastname),'','','L');
		$this->fpdf->Cell(-1,0,ucfirst($allrec->ship_address1),'','','L');
		$this->fpdf->Cell(10,10,'Phone:','','','L');		
		$this->fpdf->Cell(-10,10,ucfirst($allrec->ship_phone),'','','L');		
		$this->fpdf->Cell(10,20,'Email:','','','L');		
		$this->fpdf->Cell(51,20,ucfirst($allrec->ship_email),'','','L');		
		
		$this->fpdf->Cell(0,20,'','','1','L');
		$this->fpdf->Cell(0,10,'Orders :','','1','L');
		$this->fpdf->SetLineWidth(.3);
		$this->fpdf->SetFont('Arial','B',8);
       	$this->fpdf->Cell(30,8,"Product Name",1,'','C');
		$this->fpdf->Cell(40,8,"Product Price",1,'','C');
		$this->fpdf->Cell(40,8,"Product Quantity",1,'','C');
		$this->fpdf->Cell(30,8,"Total Amount",1,'','C');
		$this->fpdf->Cell(40,8,"Ordered On",1,1,'C');
    	//$this->fpdf->Ln();	
		$this->fpdf->SetFillColor(220,220,220);
	    $this->fpdf->SetTextColor(0);
    	$this->fpdf->SetFont('');
		$fill = false;
		$grand_total=0;
		foreach($data['allrec_items'] as $all)
		{
			$this->fpdf->Cell(30,8,ucfirst($all->product_name),'LR',0,'C',$fill);
			$this->fpdf->Cell(40,8,number_format($all->product_price),'LR',0,'C',$fill);
			$this->fpdf->Cell(40,8,number_format($all->quantity),'LR',0,'C',$fill);
			$this->fpdf->Cell(30,8,number_format($all->total),'LR',0,'C',$fill);
			$this->fpdf->Cell(40,8,ucfirst($allrec->ordered_on),'LR',0,'C',$fill);
			$this->fpdf->Ln();
			$fill = !$fill;
			$grand_total=$grand_total+$all->total;
		}
		$this->fpdf->Cell(180,0,"",1,'1','C');
		$this->fpdf->Cell(0,0,'','','1','L');
		$this->fpdf->Cell(0,10,'','','1','L');
		$this->fpdf->SetFont('Arial','B',16);
		$this->fpdf->Cell(50,10,"Grand Total : ".$grand_total,'','','C');
		$this->fpdf->Output();																
	}
//
  public function sndmail()
  {
	  $id=$this->input->post('id');
			/* 'protocol' => 'smtp',
			  'smtp_host' => 'ssl://smtp.googlemail.com',
			  'smtp_port' => 465,
			  'smtp_user' => 'sarfarajkazi7@gmail.com', // change it to yours
			  'smtp_pass' => '9033200540', // change it to yours
			  */
			 $config = Array(
			 'mailtype' => 'html',
			  'charset' => 'iso-8859-1',
			  'wordwrap' => TRUE
			);
			$this->load->library('email', $config);
			  $this->email->set_newline("\r\n");
			  $this->email->from('info@pragnyafoodproducts.com','Pragnyafoodproducts'); // change it to yours
			  $this->email->to($this->input->post('recipient'));// change it to yours
			  $this->email->subject($this->input->post('subject'));
			  $this->email->message($this->input->post('content'));
			  if($this->email->send())
			 {
					$this->session->set_userdata('email',"Email Notification Send Successfully...");
					redirect("sales/orders/invoice/$id");
			 }
			 else
			{
				$this->session->set_userdata('err',"Connnection Error");
					redirect("sales/orders/invoice/$id");

			}
  }  
}
?>