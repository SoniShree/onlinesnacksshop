<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
Class Orders_model extends CI_Model
{

	public function __construct()
	{
		parent::__construct();
	}
	public function get_orders($id=false)
	{
		if($id==false)
		{
			$this->db->order_by("id", "desc");	
			$query = $this->db->get('orders');
			return $query->result();
		}
		$query = $this->db->get_where('orders', array('id' => $id));
		return $query->row(); 
	}
	public function show_all($id)
	{
	
		$this->db->select('*');
		$this->db->from('customer');
		$this->db->where('id',$id);
		$this->db->join('orders','orders.customer_id=customer.customer_id');
		$this->db->join('order_detail','order_detail.customer_id=customer.customer_id');
		$query = $this->db->get();
		return $query->row();	
	
	}
	public function get_orders_page()
	{
		$this->db->order_by("id", "desc");	
		$query = $this->db->get('orders');
		return $query->result();	
	
	}
	public function get_order_items($orderno)
	{
		$query = $this->db->get_where('order_detail', array('order_number' => $orderno));
		return $query->result();	
	
	}
	public function delete_orders($id) 
	{
		$this->db->delete('orders', array('id' => $id));
		return TRUE;
	}
	public function update($id)
	{
	   $note=$this->input->post('notes');
	   $status=$this->input->post('status');
	   
	   $data = array('notes' => $note ,
               'status' =>$status
			   );
			   $this->db->where('id',$id);
	   $result=$this->db->update('orders', $data);
	   return TRUE;
	}
	public function update_status($id)
	{
	   
	   $status=$this->input->post('status');
	   
	   $data = array('status' =>$status
			   );
			   $this->db->where('id',$id);
	   $result=$this->db->update('orders', $data);
	   return TRUE;
	}
	public function delete_order($id) 
	{
		$this->db->delete('orders', array('id' => $id));
		return TRUE;
	}
	
}
?>