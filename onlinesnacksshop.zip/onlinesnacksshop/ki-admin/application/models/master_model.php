<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');?>
<?php
Class master_model extends CI_Model
{
	//show master model
	public function __construct()
	{
		parent::__construct();
	}
	public function get_master($id=false)
	{
		if($id==false)
		{
			
			$query = $this->db->get('login');
			return $query->result();
		}
		$query = $this->db->get_where('login', array('id' => $id));
		return $query->row(); 
	}
	public function get_master_page()
	{

		$query = $this->db->get('login');
		return $query->result();	
	
	}
	
	
	public function addmaster()
	{

		$name=$this->input->post('master_fname');
		$lname=$this->input->post('master_lname');
		$username=$this->input->post('master_username');
       $password=md5($this->input->post('master_password'));
       $email=$this->input->post('master_email');
       $data = array('first_name' => $name ,
	   				'last_name' => $lname ,
               'username' =>$username,
			   'email'=>$email,
               'password'=>$password
               );
	   $result=$this->db->insert('login', $data);
       if($result)
       {
       		return true;
       }
       else
       {
       		return false;
       }
	}
	//edit model
    public function editmaster($id) 
	{
		
	  $name=$this->input->post('master_fname');
		$lname=$this->input->post('master_lname');
		$username=$this->input->post('master_username');
       $password=md5($this->input->post('master_password'));
       $email=$this->input->post('master_email');
       $data = array('first_name' => $name ,
	   				'last_name' => $lname ,
               'username' =>$username,
			   'email'=>$email,
               'password'=>$password
               );
			
			$this->db->where('id', $id);
				$this->db->update('login', $data);
				return TRUE;
	}
	//delete model
	public function delete_master($id) 
	{
		$this->db->delete('login', array('id' => $id));
		return TRUE;
	}
	
	
}
?>