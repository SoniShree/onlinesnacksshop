<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
Class Website_model extends CI_Model
{
	public function settings()
	{
			$id=$this->session->userdata('id');
			$result = $this->db->get_where('login', array('id' => $id));
			$qry['recode']=$result->row();
			$this->session->set_userdata('username',$qry['recode']->username);
			$this->session->set_userdata('pwd',$qry['recode']->password);
			return $result->row();		
		
	}
	public function userdata($email)
	{

		$result = $this->db->get_where('login', array('email' => $email));
		return $result->row();
	}
	public function adminpwd($cpwd)
	{
		
			$this->db->where('email', $this->session->userdata('email'));
			$result=$this->db->update('login', $data); 
			$this->session->set_userdata('cpwd',"Password Changed Successfully...");
			return TRUE;
	}
	public function updateadmin()
	{
		
		$data = array('first_name' => $this->input->post('first_name'),'last_name' => $this->input->post('last_name'),'email' => $this->input->post('email') );
		$this->db->where('id', $this->input->post('id') );
 		$result=$this->db->update('login', $data); 
 		if($result)
 		{
 			
 			return TRUE;	
 		}
 		

	}
	public function get_random_password($chars_min=8, $chars_max=10, $use_upper_case=true, $include_numbers=true, $include_special_chars=true)
    {
        $length = rand($chars_min, $chars_max);
        $selection = 'aeuoyibcdfghjklmnpqrstvwxz';
        if($include_numbers) 
		{
            $selection .= "1234567890";
        }
        if($include_special_chars) 
		{
            $selection .= "04f7c318ad0360bd7b04c980f950833f11c0b1d1quot";
        }
                                
        $password = "";
        for($i=0; $i<$length; $i++) 
		{
            $current_letter = $use_upper_case ? (rand(0,1) ? strtoupper($selection[(rand() % strlen($selection))]) : $selection[(rand() % strlen($selection))]) : $selection[(rand() % strlen($selection))];            
            $password .=  $current_letter;
        }                
        
        return $password;
    }
	public function update($email,$pwd)
	{
		$this->db->where('email',$email);
		$data = array('password' => $pwd);
		$result=$this->db->update('login', $data); 
		
	}
	public function contact_details()
	{
		$this->db->order_by('contact_id','desc');
		$result=$this->db->get('contact','4');
		return $result->result();
	}
	public function product_details()
	{

		$result=$this->db->get('product','4');
		return $result->result();
	}
	public function get_contact_row()
	{

			$query = $this->db->get('contact');
			return $query->num_rows;
	}
	public function customer_details()
	{
		$this->db->order_by('customer_id','desc');
		$result=$this->db->get('customer','8');
		return $result->result();
	}
	public function get_customer_row()
	{

			$query = $this->db->get('customer');
			return $query->num_rows;
	}
	public function get_latest_users()
	{
		
		$last_login = $this->session->userdata('last_login');
		$this->db->where('username',$this->session->userdata('username'));
		$result=$this->db->get('login');
		$data = $result->row();
		$curr = $data->last_login;
		$this->db->where('customer_created >=', $last_login);
		$this->db->where('customer_created <=', $curr);
		$num = $this->db->get('customer');		
		return  $num->num_rows();

	}
	public function get_latest_contact()
	{
		
		$last_login = $this->session->userdata('last_login');
		$this->db->where('username',$this->session->userdata('username'));
		$result=$this->db->get('login');
		$data = $result->row();
		$curr = $data->last_login;
		$this->db->where('created >=', $last_login);
		$this->db->where('created <=', $curr);
		$num = $this->db->get('contact');		
		return  $num->num_rows();

	}
	public function get_latest_orders()
	{
		
		$last_login = $this->session->userdata('last_login');
		$this->db->where('username',$this->session->userdata('username'));
		$result=$this->db->get('login');
		$data = $result->row();
		$curr = $data->last_login;
		$this->db->where('ordered_on >=', $last_login);
		$this->db->where('ordered_on <=', $curr);
		$num = $this->db->get('orders');		
		return  $num->num_rows();

	}
	public function get_order_row()
	{

			$query = $this->db->get('orders');
			return $query->num_rows;
	}
	public function get_latest_sub()
	{
		
		$last_login = $this->session->userdata('last_login');
		$this->db->where('username',$this->session->userdata('username'));
		$result=$this->db->get('login');
		$data = $result->row();
		$curr = $data->last_login;
		$this->db->where('created >=', $last_login);
		$this->db->where('created <=', $curr);
		$num = $this->db->get('newsletter');		
		return  $num->num_rows();

	}
	public function get_sub_row()
	{

			$query = $this->db->get('newsletter');
			return $query->num_rows;
	}
	public function get_orders_page()
	{
		$this->db->order_by("id", "desc");	
		$query = $this->db->get('orders','10');
		return $query->result();	
	
	}
	public function chngpwd()
	{
		if(md5($this->input->post('cpassword'))==$this->session->userdata('pwd'))
		{
			if($this->input->post('npassword')==$this->input->post('cnpassword'))
			{
				$data = array('password' => md5($this->input->post('npassword')));
				$this->db->where('id', $this->session->userdata('id'));
 				$result=$this->db->update('login', $data); 
 				$this->session->set_userdata('cpwd',"Password Changed Successfully...");
 				return TRUE;
			}
			else
			{
				$this->session->set_userdata('err1pwd',"Password Should Me Match...");
			}
			
		}
		else
		{
			$this->session->set_userdata('err1pwd',"Current Password Mismatch...");
		}
	}
}
?>