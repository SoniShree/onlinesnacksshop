<?php
class Newsletter_model extends CI_Model 
{

	public function __construct()
	{
		$this->load->database();
	}

	public function search()
	{
		 $this->db->order_by('subs_id','desc'); 		
		 $res = $this->db->get('newsletter');
		return 	$res->result();
	}
	public function del_multiple($box)
	{
		$this->db->where('subs_id',$box);
		$query = $this->db->delete('newsletter');
		return TRUE;
	}
	public function delete_news($id) 
	{
		
		$this->db->delete('newsletter', array('subs_id' => $id));
		return TRUE;
	}
	public function update_status($id,$status)
	{
		
		if($status == 0)
		{
			$upstat = 1;
			$this->session->set_userdata('succ','Status Changed To Premium');
		}
		else
		{
			$upstat = 0;
			$this->session->set_userdata('succ','Status Changed To Normal');
		}
		$arr=array('premium'=>$upstat);
		$this->db->where('subs_id',$id);
		$this->db->update('newsletter',$arr);
		
	}
	
}

?>