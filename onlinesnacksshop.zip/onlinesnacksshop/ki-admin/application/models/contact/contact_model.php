<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Contact_model extends CI_Model
{
	public function con_list_model()
	{
		
		$qry = $this->db->get('contact');
		return $qry->result();
		
	}
	public function con_add_model()
	{  
		
		$created=date('Y-m-d H:i:s');
		$data = array(
			'first_name' => $this->input->post('first_name'),
			'mobile_no' => $this->input->post('mobile_no'),
			'email' => $this->input->post('email'),
			'created'=>$this->input->post('created'),
			'comment' => $this->input->post('comment')
			
					);

		
		$qry = $this->db->insert('contact',$data);
		return $qry;
	}
	public function delete_contact($contact_id)
	{
		$this->db->delete('contact',array('contact_id' => $contact_id));
	}
	public function get_rec($contect_id)
	{
		$this->db->where('contact_id',$contect_id);
			$qry = $this->db->get('contact');
			$r= $qry->row();
			return $r;
	}
	public function con_view_model($contact_id = 0)
	{
		if($contact_id == 0)
		{
			$qry = $this->db->get('contact');
			return $qry->result();
		}
		else
		{
			$this->db->where('contact_id',$contact_id);
			$qry = $this->db->get('contact');
			return $qry->row();
		}
	}
	public function findrecord($contact_id)
	{
		$this->db->where('contact_id',$contact_id);
		$qry=$this->db->get('contact');
		
		if($qry->num_rows() == 0)
		{
			$this->session->set_userdata('norec','No Record Found');
			return TRUE;
		}
	}
	public function updatestatus($id)
	{
		
	$status=$this->input->post('status');
		$data = array('status'=>$status);
		$this->db->where('contact_id',$id);
		$this->db->update('contact',$data);
				return TRUE;

	}
	public function searching_contact($src_term)
	{
	
		$array = array('name'=>$src_term ,'email'=>$src_term);
		$this->db->or_like($array);
		$data=$this->db->get('contact');
		return $data->result();
	}
	
	
	public function get_page()
	{
			$this->db->order_by("contact_id", "desc");
			$qry = $this->db->get('contact');
			return $qry->result();
	}
	
	
	public function record_count()
	{
		$qry = $this->db->count_all('contact');
		return $qry;
	}
	
}
?>