<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');?>
<?php
Class Namkeen_model extends CI_Model
{
	//show namkeen model
	public function __construct()
	{
		parent::__construct();
	}
	public function get_namkeen($id=false)
	{
		if($id==false)
		{
			
			$query = $this->db->get('namkeen');
			return $query->result();
		}
		$query = $this->db->get_where('namkeen', array('namkeen_id' => $id));
		return $query->row(); 
	}
	public function get_namkeen_page()
	{

		$query = $this->db->get('namkeen');
		return $query->result();	
	
	}
	public function get_category_name()
	{
		
		$query = $this->db->get('category');
		return $query->result();	
	
	}
	//add namkeen model
	
	public function addnamkeen($fname)
	{
		//$c_id=$this->input->post('category_id');
		$title=$this->input->post('namkeen_title');
		$long=$this->input->post('namkeen_long');
       $sort=$this->input->post('namkeen_sort');
       $status=$this->input->post('namkeen_status');
       //$image=$this->input->post('namkeen_image');
       $price=$this->input->post('namkeen_price');
	   $qty=$this->input->post('namkeen_qty');
       $created= date('Y-m-d H:i:s');
       $updated= date('Y-m-d H:i:s');
       $data = array(
	   			'namkeen_title' => $title ,
				'namkeen_long'=>$long,
               'namkeen_sort' =>$sort,
               'namkeen_images'=>$fname,
               'namkeen_status'=>$status,
               'namkeen_price' =>$price,
			   'namkeen_qty'=>$qty,
               'namkeen_created'=>$created,
               'namkeen_updated'=>$updated);
       $result=$this->db->insert('namkeen', $data);
       if($result)
       {
       		return true;
       }
       else
       {
       		return false;
       }
	}
	//edit model
    public function editnamkeen($fname) 
	{
		$id=$this->input->post('namkeen_id');
		$title=$this->input->post('namkeen_title');
       $sort=$this->input->post('namkeen_sort');
	   $long=$this->input->post('namkeen_long');
       $price=$this->input->post('namkeen_price');
	   $qty=$this->input->post('namkeen_qty');
       $status=$this->input->post('namkeen_status');
       $updated= date('Y-m-d H:i:s');
		$data = array(
				'namkeen_title' => $title,
				'namkeen_images' => $fname,
				'namkeen_sort' => $sort,
				'namkeen_long'=>$long,
				 'namkeen_price' =>$price,
				 'namkeen_qty'=>$qty,
				'namkeen_status' => $status,
				'namkeen_updated' => $updated
			);
			$this->db->where('namkeen_id', $id);
				$this->db->update('namkeen', $data);
				return TRUE;
	}
	//delete model
	public function delete_namkeen($id) 
	{
		$this->db->delete('namkeen', array('namkeen_id' => $id));
		return TRUE;
	}
	//namkeen Album
	public function add_gallery($namkeen_id,$imageName)
		{
			
			$data=array(
				'namkeen_id' => $namkeen_id,
				'long_name'=>$imageName,
				'short_name'=>'thumb_'.$imageName
				);
			$this->db->where('namkeen_id',$namkeen_id);
			$this->db->insert('namkeen_photos',$data);
			
			
		}
		
		public function get_images($namkeen_id)
		{
			$this->db->where('namkeen_id',$namkeen_id);
			$image = $this->db->get('namkeen_photos');
			
			return $image->result();
		}
		public function delete_image($namkeen_id,$photo_id)
		{
			$this->db->select('short_name');		
			$this->db->select('long_name');
			$this->db->where('namkeen_id',$namkeen_id);
			$this->db->where('photo_id',$photo_id);
			
			$qry=$this->db->get('namkeen_photos');
			if($qry->num_rows < 1)
			{
				$this->session->set_userdata('err','Something Went Wrong . No Record With That ID Found!!!');
			}
			else
			{
				$res=$qry->row();
			
				$img_long =$res->long_name;
				$img_short =$res->short_name;
				
				if(file_exists('../uploads/namkeen_image/'.$namkeen_id.'/full/'.$img_long) && file_exists('../uploads/namkeen_image/'.$namkeen_id.'/thumbs/'.$img_short)  )
				{
					unlink('../uploads/namkeen_image/'.$namkeen_id.'/full/'.$img_long);
					unlink('../uploads/namkeen_image/'.$namkeen_id.'/thumbs/'.$img_short);
					$this->db->where('namkeen_id',$namkeen_id);
					$this->db->where('photo_id',$photo_id);
					$this->db->delete('namkeen_photos');
					return TRUE;
				}
				else
				{
					$this->db->delete('namkeen_photos', array('photo_id' => $photo_id));
					return FALSE;
				}
		   }			
		}
		public function get_photo($photo_id)
		{
			$this->db->where('photo_id',$photo_id);
			$image = $this->db->get('namkeen_photos');
			return $image->row();
		}

}
?>