<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');?>
<?php
Class Product_model extends CI_Model
{
	//show product model
	public function __construct()
	{
		parent::__construct();
	}
	public function get_product($id=false)
	{
		if($id==false)
		{
		
			$query = $this->db->get('product');
			return $query->result();
		}
		$query = $this->db->get_where('product', array('product_id' => $id));
		return $query->row(); 
	}
	public function get_product_page()
	{
		
		$query = $this->db->get('product');
		return $query->result();	
	
	}
	public function get_category_name()
	{
		
		$query = $this->db->get('category');
		return $query->result();	
	
	}
	//add product model
	
	public function addproduct($fname)
	{
		$c_id=$this->input->post('category_id');
		$title=$this->input->post('product_title');
       $desc=$this->input->post('product_desc');
       $status=$this->input->post('product_status');
       //$image=$this->input->post('product_image');
       $price=$this->input->post('product_price');
	   $qty=$this->input->post('product_qty');
       $created= date('Y-m-d H:i:s');
       $updated= date('Y-m-d H:i:s');
       $data = array(
	   			'category_id' =>$c_id,
	   			'product_title' => $title ,
               'product_desc' =>$desc,
               'product_img' =>$fname,
               'product_status'=>$status,
               'product_price' =>$price,
			   'product_qty' =>$qty,
               'product_created'=>$created,
               'product_updated'=>$updated);
       $result=$this->db->insert('product', $data);
       if($result)
       {
       		return true;
       }
       else
       {
       		return false;
       }
	}
	//edit model
    public function editproduct($fname) 
	{
		$id=$this->input->post('product_id');
		$c_id=$this->input->post('category_id');
		$title=$this->input->post('product_title');
       $desc=$this->input->post('product_desc');
       $price=$this->input->post('product_price');
	   $qty=$this->input->post('product_qty');
       $status=$this->input->post('product_status');
       $updated= date('Y-m-d H:i:s');
		$data = array(
				'category_id' =>$c_id,
				'product_title' => $title,
				'product_img' => $fname,
				'product_desc' => $desc,
				 'product_price' =>$price,
				 'product_qty' => $qty,
				'product_status' => $status,
				'product_updated' => $updated
			);
			$this->db->where('product_id', $id);
				$this->db->update('product', $data);
				return TRUE;
	}
	//delete model
	public function delete_product($id) 
	{
		$this->db->delete('product', array('product_id' => $id));
		return TRUE;
	}
	//Product Album
	public function add_gallery($product_id,$imageName)
		{
			
			$data=array(
				'product_id' => $product_id,
				'long_name'=>$imageName,
				'short_name'=>'thumb_'.$imageName
				);
			$this->db->where('product_id',$product_id);
			$this->db->insert('product_photos',$data);
			
			
		}
		
		public function get_images($product_id)
		{
			$this->db->where('product_id',$product_id);
			$image = $this->db->get('product_photos');
			
			return $image->result();
		}
		public function delete_image($product_id,$photo_id)
		{
			$this->db->select('short_name');		
			$this->db->select('long_name');
			$this->db->where('product_id',$product_id);
			$this->db->where('photo_id',$photo_id);
			
			$qry=$this->db->get('product_photos');
			if($qry->num_rows < 1)
			{
				$this->session->set_userdata('err','Something Went Wrong . No Record With That ID Found!!!');
			}
			else
			{
				$res=$qry->row();
			
				$img_long =$res->long_name;
				$img_short =$res->short_name;
				
				if(file_exists('../uploads/product_image/'.$product_id.'/full/'.$img_long) && file_exists('../uploads/product_image/'.$product_id.'/thumbs/'.$img_short)  )
				{
					unlink('../uploads/product_image/'.$product_id.'/full/'.$img_long);
					unlink('../uploads/product_image/'.$product_id.'/thumbs/'.$img_short);
					$this->db->where('product_id',$product_id);
					$this->db->where('photo_id',$photo_id);
					$this->db->delete('product_photos');
					return TRUE;
				}
				else
				{
					$this->db->delete('product_photos', array('photo_id' => $photo_id));
					return FALSE;
				}
		   }			
		}
		public function get_photo($photo_id)
		{
			$this->db->where('photo_id',$photo_id);
			$image = $this->db->get('product_photos');
			return $image->row();
		}

}
?>