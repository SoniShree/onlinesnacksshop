<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');?>
<?php
Class News_model extends CI_Model
{
	//show news model
	public function __construct()
	{
		parent::__construct();
	}
	public function get_news($id=false)
	{
		if($id==false)
		{
	
			$query = $this->db->get('news');
			return $query->result();
		}
		$query = $this->db->get_where('news', array('news_id' => $id));
		return $query->row(); 
	}
	public function get_news_page()
	{

		$query = $this->db->get('news');
		return $query->result();	
	
	}
	public function enable_news($id)
		{
			$data=array('news_status'=>1);
			return $this->db->where('news_id',$id)->update('news',$data);
		}
		
		public function disble_news($id)
		{
			$data=array('news_status'=>0);
			return $this->db->where('news_id',$id)->update('news',$data);
		}
		public function delete_multiple($id)
		{
			return $this->db->where('news_id',$id)->delete('news');
		} 
	//add news model
	
	
	public function addnews($fname)
	{

		$title=$this->input->post('news_title');
       $desc=$this->input->post('news_desc');
       $status=$this->input->post('news_status');
       //$image=$this->input->post('news_image');
       $created= date('Y-m-d H:i:s');
       $updated= date('Y-m-d H:i:s');
       $data = array('news_title' => $title ,
               'news_desc' =>$desc,
               'news_img'=>$fname,
               'news_status'=>$status,
               'news_created'=>$created,
               'news_updated'=>$updated);
       $result=$this->db->insert('news', $data);
       if($result)
       {
       		return true;
       }
       else
       {
       		return false;
       }
	}
	//edit model
    public function editnews($fname) 
	{
		$id=$this->input->post('news_id');
		$title=$this->input->post('news_title');
       $desc=$this->input->post('news_desc');
       $status=$this->input->post('news_status');
       $updated= date('Y-m-d H:i:s');
		$data = array(

				'news_title' => $title,
				'news_img'=>$fname,
				'news_desc' => $desc,
				'news_status'=>$status,
				'news_updated'=>$updated
			);
			$this->db->where('news_id', $id);
				$this->db->update('news', $data);
				return TRUE;
	}
	//delete model
	public function delete_news($id) 
	{
		$this->db->delete('news', array('news_id' => $id));
		return TRUE;
	}
	
	
}
?>