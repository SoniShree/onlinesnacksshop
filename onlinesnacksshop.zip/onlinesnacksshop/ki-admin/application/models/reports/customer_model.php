<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');?>
<?php
Class customer_model extends CI_Model
{
	//show customer model
	public function __construct()
	{
		parent::__construct();
	}
	public function get_customer_page()
	{
		
		$query = $this->db->get('customer');
		return $query->result_array();	
	}
	public function get_total($id)
	{
		$this->db->where("customer_id", $id);
		$this->db->select_sum('total');
		$query = $this->db->get('order_detail');
		return $query->result_array();	
	}
	
}
?>