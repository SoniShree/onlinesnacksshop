<?php
	class Sales_model extends CI_Model
	{
		public function customerdetail($id)		
		{
			$this->db->where('cid',$id);
			return $this->db->get('customer')->row();
		}		
		public function get_sales()
		{	
			$this->db->select('order_detail.*,orders.*,customer.*');
	    	$this->db->from('order_detail');
			$this->db->join('orders', 'orders.customer_id = order_detail.customer_id', 'inner'); 						
			$this->db->join('customer', 'orders.customer_id = customer.customer_id', 'inner'); 						
    		return $this->db->get()->result();			
		}
		public function get_order($id)
		{
			$this->db->select('payment.*,customer.*');
	    	$this->db->from('payment');
			$this->db->where('payment.status',$this->input->post('status'));
    		$this->db->join('customer', 'payment.c_id = customer.cid', 'inner'); 			
			return $this->db->get()->result();			
			
			$this->db->				
			$this->db->where('order_id',$id);		
			$query = $this->db->get('order');
    		return $query->row();			
		}	
		public function get_order_item($id)
		{
			$this->db->where('order_id',$id);
			$query = $this->db->get('order_detail');
    		return $query->result();			
		}
		public function get_orderno()	
		{
			return $this->db->get('order')->result();
		}
		public function get_customer($id)
		{			
			$this->db->where('cid',$id);
			return $this->db->get('customer')->row();
		}
		public function get_item()
		{
			return $this->db->get('product')->result();
		}
		public function product($id)
		{
			return $this->db->where('product_id',$id)->get('product')->row();			
		}
		public function color($id)
		{
			return $this->db->where('color_id',$id)->get('color')->row();			
		}public function fabric($id)
		{
			return $this->db->where('fabric_id',$id)->get('fabric')->row();			
		}
		public function status_wise()
		{			
			$this->db->select('payment.*,customer.*');
	    	$this->db->from('payment');
			$this->db->where('payment.status',$this->input->post('status'));
    		$this->db->join('customer', 'payment.c_id = customer.cid', 'inner'); 			
			return $this->db->get()->result();			
		}
		public function enable_payment($id)
		{
			$data=array('status'=>1);
			return $this->db->where('payment_id',$id)->update('payment',$data);
		}
		
		public function disblepayment($id)
		{
			$data=array('status'=>0);
			return $this->db->where('payment_id',$id)->update('payment',$data);
		}
		public function deletepayment($id)
		{
			return $this->db->where('payment_id',$id)->delete('payment');
		}
		public function add_payment($data)
		{
			$this->db->insert('payment',$data);
			return $this->db->insert_id();
		}
		public function add_payment_detail($data)
		{
			return $this->db->insert('payment_detail',$data);
		}
		public function update_payment_detail($arr,$oi_id)		
		{
			$this->db->where('payment_detail_id',$oi_id);
			return $this->db->update('payment_detail',$arr);
		}
		public function view_payment($id)
		{						
			$this->db->select('payment.*,customer.*');
	    	$this->db->from('payment');
    		$this->db->join('customer', 'payment.cid = customer.cid', 'inner'); 
			$this->db->where('payment_id',$id);			
			$query=$this->db->get();
			if($query->num_rows()>0)
			{
				return $query=$query->row(); 
			}						
		}
		public function deletepaymentDetail($id)
		{
			return $this->db->where('payment_detail_id',$id)->delete('payment_detail');
		}
		public function getpayment($id)
		{
			return $this->db->where('payment_id',$id)->get('payment')->row();
		} 
		public function  view_payment_item($id)
		{
			$this->db->select('payment.*,payment_detail.*');
	    	$this->db->from('payment');
    		$this->db->join('payment_detail', 'payment.payment_id = payment_detail.payment_id', 'inner'); 
			$this->db->where('payment.payment_id',$id);			
			$query=$this->db->get();
			if($query->num_rows()>0)
			{
				return $query=$query->result(); 
			}
		}	
		public function delete_payment($id)  
		{			
			return $this->db->where('payment_id',$id)->delete('payment');
		}		
		public function update_payment($arr,$id)
		{
			return $this->db->where('payment_id',$id)->update('payment',$arr);
		}
		public function id_check($id)
		{
			$this->db->where('payment_id',$id);
			$query=$this->db->get('payment');			
			return $query->num_rows();			
		}
	}
?>