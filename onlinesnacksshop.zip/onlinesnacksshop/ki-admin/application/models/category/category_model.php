<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');?>
<?php
Class category_model extends CI_Model
{
	//show category model
	public function __construct()
	{
		parent::__construct();
	}
	public function get_category($id=false)
	{
		if($id==false)
		{
			
			$query = $this->db->get('category');
			return $query->result();
		}
		$query = $this->db->get_where('category', array('category_id' => $id));
		return $query->row(); 
	}
	public function get_category_page()
	{

		$query = $this->db->get('category');
		return $query->result();	
	
	}
	public function get_category_row()
	{

			$query = $this->db->get('news');
			return $query->num_rows;
	}
	//add category model
	public function addcategory($fname)
	{

		$title=$this->input->post('category_title');
       $desc=$this->input->post('category_desc');
       $status=$this->input->post('category_status');
       //$image=$this->input->post('category_image');
       $created= date('Y-m-d H:i:s');
       $updated= date('Y-m-d H:i:s');
       $data = array('category_title' => $title ,
               'category_desc' =>$desc,
               'category_img'=>$fname,
               'category_status'=>$status,
               'category_created'=>$created,
               'category_updated'=>$updated);
       $result=$this->db->insert('category', $data);
       if($result)
       {
       		return true;
       }
       else
       {
       		return false;
       }
	}
	//edit model
    public function editcategory($fname) 
	{
		$id=$this->input->post('category_id');
		$title=$this->input->post('category_title');
       $desc=$this->input->post('category_desc');
       $status=$this->input->post('category_status');
       $updated= date('Y-m-d H:i:s');
		$data = array(

				'category_title' => $title,
				'category_img'=>$fname,
				'category_desc' => $desc,
				'category_status'=>$status,
				'category_updated'=>$updated
			);
			$this->db->where('category_id',$id);
				$result=$this->db->update('category',$data);
				
				return TRUE;

	}
	//delete model
	public function delete_category($id) 
	{
		$this->db->delete('category', array('category_id' => $id));
		return TRUE;
	}
}
?>