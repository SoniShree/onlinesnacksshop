<?php
class Misc_model extends CI_Model 
{

	public function __construct()
	{
		$this->load->database();
		
	}
	public function get_email_list($id)
	{
		$this->db->select(array('email_id','subs_id'));
		if($id!="")
		{
			$ids=explode(',',$id);
			foreach($ids as $i)
			{
				$this->db->or_where('subs_id',$i);
			}
		}
		$this->db->where('status',1);
		$emaillist = $this->db->get('newsletter');
		return $emaillist->result();
		
	}
	
}

?>