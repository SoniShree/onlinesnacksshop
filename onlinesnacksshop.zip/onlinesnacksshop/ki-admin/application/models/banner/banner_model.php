<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');?>
<?php
Class Banner_model extends CI_Model
{
	public function __construct()
	{
		parent::__construct();
	}
	public function get_banner($id=false)
	{
		if($id==false)
		{
			
			$query = $this->db->get('banner');
			return $query->result();
		}
		$query = $this->db->get_where('banner', array('banner_id' => $id));
		return $query->row(); 
	}
	public function get_banner_page()
	{

		$query = $this->db->get('banner');
		return $query->result();	
	
	}
	//add banner model
	public function addbanner($fname)
	{
		$title=$this->input->post('banner_name');
       $desc=$this->input->post('banner_desc');
       $status=$this->input->post('status');
       $created= date('Y-m-d H:i:s');
       $updated= date('Y-m-d H:i:s');
       $data = array(
	   	
	   			'banner_name' => $title ,
               'banner_desc' =>$desc,
               'banner_img'=>$fname,
               'status'=>$status,
               'banner_created'=>$created,
               'banner_updated'=>$updated);
       $result=$this->db->insert('banner', $data);
       if($result)
       {
       		return true;
       }
       else
       {
       		return false;
       }
	}
	//edit model
    public function editbanner($fname) 
	{
		$id=$this->input->post('banner_id');
		$title=$this->input->post('banner_name');
       $desc=$this->input->post('banner_desc');
       $status=$this->input->post('banner_status');
       $updated= date('Y-m-d H:i:s');
		$data = array(
		
				'banner_name' => $title,
				'banner_img' => $fname,
				'banner_desc' => $desc,
				'status' => $status,
				'banner_updated' => $updated
			);
			$this->db->where('banner_id', $id);
				$this->db->update('banner', $data);
				return TRUE;
	}
	//delete model
	public function delete_banner($id) 
	{
		$this->db->delete('banner', array('banner_id' => $id));
		return TRUE;
	}
}
?>