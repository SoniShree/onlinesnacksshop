<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');?>
<?php
Class Wishlist_model extends CI_Model
{
	//show product model
	public function __construct()
	{
		parent::__construct();
	}
	public function get_wishlist()
	{
		$qry=$this->db->get('wishlist');
		return $qry->result();
	}
	public function get_Wishlist_record($id)
	{
		$this->db->select('*');
		$this->db->from('product');
		$this->db->where('customer_id',$id);
		$this->db->join('wishlist','wishlist.product_id=product.product_id');
		$result=$this->db->get();
		return $result->result(); 

	}
	public function get_Wishlist_record_customer($id)
	{
		if($id==false)
		{
			$this->db->where('customer_id',$id);
			$query = $this->db->get('customer');
			return $query->result();
		}
		$query = $this->db->get_where('customer', array('customer_id' => $id));
		return $query->row(); 
	}
	
}
?>