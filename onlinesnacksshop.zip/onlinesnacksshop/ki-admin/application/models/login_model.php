<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');?>
<?php
Class Login_Model extends CI_Model
{
	public function __construct()
	{
		parent::__construct();
		$this->load->helper('date');
	}
	public function login()
	{
		
	 	$username = $this->input->post('username');
		$password = $this->input->post('password');
	   $query = $this -> db -> get_where('login', array('username' => $username,'password' => md5($password)));
	   $result['record']=$query->row();
	   if($query -> num_rows() == 1)
	   {
	   		$id=$result['record']->id;
	   		$this->session->set_userdata('id',$id);
	   		$last_login=$result['record']->last_login;
	   		$this->session->set_userdata('last_login',$last_login);
	   		$now= date('Y-m-d H:i:s');
	   		$date = array('last_login' => $now );
	 		$this->db->where('id', $result['record']->id );
 			$this->db->update('login', $date); 

			return TRUE;
	   }
	   else
	   {
		 return FALSE;
	   }
	}
}
?>