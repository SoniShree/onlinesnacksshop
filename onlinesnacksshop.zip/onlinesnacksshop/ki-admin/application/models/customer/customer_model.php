<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');?>
<?php
Class customer_model extends CI_Model
{
	//show customer model
	public function __construct()
	{
		parent::__construct();
	}
	public function get_customer($id=false)
	{
		if($id==false)
		{
			
			$query = $this->db->get('customer');
			return $query->result();
		}
		$query = $this->db->get_where('customer', array('customer_id' => $id));
		return $query->row(); 
	}
	public function get_customer_page()
	{

		$query = $this->db->get('customer');
		return $query->result();	
	
	}
	
	
	public function addcustomer()
	{

		$name=$this->input->post('customer_fname');
				$lname=$this->input->post('customer_lname');
		$username=$this->input->post('customer_username');
       $password=md5($this->input->post('customer_password'));
       $status=$this->input->post('customer_status');
       $address=$this->input->post('customer_address');
       $zipcode=$this->input->post('customer_zipcode');
       $mobile=$this->input->post('customer_mobile');
       $email=$this->input->post('customer_email');
       //$image=$this->input->post('customer_image');
       $created= date('Y-m-d H:i:s');
       $updated= date('Y-m-d H:i:s');
       $data = array('customer_fname' => $name ,
	   				'customer_lname' => $lname ,
               'customer_username' =>$username,
               'customer_password'=>$password,
               'customer_status'=>$status,
               'customer_address'=>$address,
               'customer_zipcode'=>$zipcode,
               'customer_mobile'=>$mobile,
			   'customer_type'=>'dealer',
               'customer_email'=>$email,
               'customer_created'=>$created,
               'customer_updated'=>$updated);
	   $result=$this->db->insert('customer', $data);
       if($result)
       {
       		return true;
       }
       else
       {
       		return false;
       }
	}
	//edit model
    public function editcustomer($id) 
	{
		
	   $status=$this->input->post('customer_status');
	   
       $updated= date('Y-m-d H:i:s');
	  
		$data = array(

				'customer_status'=>$status,
				'customer_updated'=>$updated
			);
			
			$this->db->where('customer_id', $id);
				$this->db->update('customer', $data);
				return TRUE;
	}
	//delete model
	public function delete_customer($id) 
	{
		$this->db->delete('customer', array('customer_id' => $id));
		return TRUE;
	}
	
	
}
?>