<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');?>
<?php
Class cms_model extends CI_Model
{
	//show cms model
	public function __construct()
	{
		parent::__construct();
	}
	public function get_cms($id=false)
	{
		if($id==false)
		{
			
			$query = $this->db->get('cms');
			return $query->result();
		}
		$query = $this->db->get_where('cms', array('cms_id' => $id));
		return $query->row(); 
	}
	public function get_cms_page()
	{

		$query = $this->db->get('cms');
		return $query->result();	
	
	}
	//add cms model
	public function addcms()
	{

		$title=$this->input->post('cms_title');
       $desc=$this->input->post('cms_desc');
       $url_key=$this->input->post('url_key');
       $status=$this->input->post('cms_status');
       $meta_keywords=$this->input->post('meta_keywords');
       $meta_desc=$this->input->post('meta_desc');
       $created= date('Y-m-d H:i:s');
       $updated= date('Y-m-d H:i:s');
       $data = array('cms_title' => $title,
               'content' =>$desc,
               'url_key'=>$url_key,
               'cms_status'=>$status,
               'cms_created'=>$created,
               'cms_updated'=>$updated,

               'meta_keywords'=>$meta_keywords,
               'meta_desc'=>$meta_desc
               );
       $result=$this->db->insert('cms', $data);
       if($result)
       {
       		return true;
       }
       else
       {
       		return false;
       }
	}
	//edit model
    public function editcms() 
	{
		$id=$this->input->post('cms_id');
		$title=$this->input->post('cms_title');
	
       $desc=$this->input->post('cms_desc');
       $status=$this->input->post('cms_status');
	  
       $meta_keywords=$this->input->post('meta_keywords');
       $meta_desc=$this->input->post('meta_desc');
       $updated= date('Y-m-d H:i:s');
		$data = array(

				'cms_title' => $title ,
               'content' =>$desc,
               'cms_status'=>$status,
               'cms_updated'=>$updated,
		
               'meta_keywords'=>$meta_keywords,
               'meta_desc'=>$meta_desc
			);
			$this->db->where('cms_id', $id);
				$this->db->update('cms', $data);
				return TRUE;
	}
	//delete model
	public function delete_cms($id) 
	{
		$this->db->delete('cms', array('cms_id' => $id));
		return TRUE;
	}
	function check_if_url_exists($url)
		{
			$this->db->where('url_key',$url);
			$result = $this->db->get('page_manager');
			
			if($result->num_rows() > 0)
			{
				return FALSE;
			}
			else
			{
				return TRUE;
			}
		}
}
?>