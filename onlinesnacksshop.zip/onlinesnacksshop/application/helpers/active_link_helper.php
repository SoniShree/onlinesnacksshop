<?php
function active_link($controller)
{
	$CI =& get_instance();

	$class = $CI->router->fetch_class();
	return ($class == $controller) ? 'class="active"' : '';
}
?>