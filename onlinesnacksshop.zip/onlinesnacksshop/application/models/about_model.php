<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');?>
<?php
class About_model extends CI_Model
{
	public function get_info()
	{
			$this->db->where('url_key','about');
			$query = $this->db->get('cms');
			return $query->result();
	}	
}
?>