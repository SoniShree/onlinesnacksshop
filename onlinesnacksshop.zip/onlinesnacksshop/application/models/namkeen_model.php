<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');?>
<?php
Class namkeen_Model extends CI_Model
{
	public function __construct()
	{
		parent::__construct();
	}
	public function get_product($id=false)
	{
		if($id==false)
		{
				$this->db->where('product_status',1);
			$this->db->order_by("product_id", "desc");	
			$query = $this->db->get('product','3');
			return $query->result();
		}
		$this->db->where('product_status',1);
		$query = $this->db->get_where('product', array('product_id' => $id));

		return $query->row(); 
	}
	public function get_namkeen_all()
	{
		$this->db->where('namkeen_status',1);
		$this->db->order_by('namkeen_id','desc');
		$res=$this->db->get('namkeen');
		if($res->num_rows() > 0)
		{
			return $res->result();
		}
		else
		{
			return false;
		}
		
	}
	public  function retrieve_products($id)
	{
		$this->db->where('namkeen_status',1);
		$this->db->where('namkeen_id',$id);
		$query = $this->db->get('namkeen',$id);
		$product=$query->row();
		return $product;
	}	
	public function get_namkeen_photos($id)
	{
		$this->db->where('namkeen_id',$id);
		$image = $this->db->get('namkeen_photos','4');
			
		return $image->result();
	}
}