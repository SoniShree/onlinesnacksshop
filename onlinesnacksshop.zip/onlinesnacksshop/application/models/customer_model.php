<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Customer_model extends CI_Model
{
	public function add_cust($data)
	{
		$result=$this->db->insert('customer', $data);

	   if($result)
       {
       		return true;
       }
       else
       {
       		return false;
       }

	}
	public function settings()
	{	
		$user=$this->session->userdata('user');
		$this->db->where('customer_username',$user);
		$result = $this->db->get('customer');
		$qry['recode']=$result->row();
		$this->session->set_userdata('username',$qry['recode']->customer_username);
		$this->session->set_userdata('pwd',$qry['recode']->customer_password);
		return $result->row();
	}
	public function updatecustomer()
	{
		
		$data = array(
		'customer_fname' => $this->input->post('fname'),
		'customer_lname' => $this->input->post('lname')
		);
		$this->db->where('customer_id', $this->input->post('customer_id'));
 		$result=$this->db->update('customer', $data); 
 		if($result)
 		{
 			
 			return TRUE;	
 		}
	}
	public function chngpwd()
	{	
		
		if(md5($this->input->post('cpassword'))==$this->session->userdata('pwd'))
		{
			if($this->input->post('npassword')==$this->input->post('cnpassword'))
			{
				$data = array(
				'customer_password' => md5($this->input->post('cnpassword'))
				);
				$user=$this->session->userdata('user');
				$this->db->where('customer_username',$user);
 				$result=$this->db->update('customer', $data); 
				$this->session->set_userdata('cpwd',"Password Changed Successfully...");
 				return TRUE;
			}
			else
			{
				$this->session->set_userdata('err1pwd',"Password Should Me Match...");
			}
			
		}
		else
		{
			$this->session->set_userdata('err1pwd',"Current Password Mismatch...");
		}
	}
	public function get_category()
	{
		$this->db->select('*');
		$this->db->from('product');
		
		$this->db->join('category','category.category_id=product.category_id');
		$result=$this->db->get();
		return $result->result(); 

	}
	public function get_category_page()
	{
		$this->db->where('category_status','1');
		$query = $this->db->get('category');
		return $query->result();	
	
	}
	public function get_order_details($o_id)
	{
		$odr1='orderplaced';
		$odr2='pending';
		$odr3='processing';
		$odr4='shipped';
		$odr5='delivered';
		$c_id=$this->session->userdata('c_id');
		$this->db->where_not_in('status','cancelled');
		$this->db->where('customer_id',$c_id);
		$this->db->where('order_number',$o_id);
		$query = $this->db->get('orders');
		//echo $this->db->last_query();die;
		return $query->result();	
	
	}
	public function cencel_my_order($o_id)
	{
		$status="cancelled";
		$data=array('status'=>$status);
		$c_id=$this->session->userdata('c_id');
		$this->db->where('customer_id',$c_id);
		$this->db->where('order_number',$o_id);
 		$result=$this->db->update('orders', $data);
	}
	public function get_details($o_id)
	{
		
		$c_id=$this->session->userdata('c_id');
		//$this->db->select('*');
		//$this->db->from('orders');
		//$this->db->where_not_in('status','cancelled');
		$this->db->where('customer_id',$c_id);
		$this->db->where('order_number',$o_id);
		//$query = $this->db->join('order_detail','order_detail.customer_id=orders.customer_id');
		$result=$this->db->get('order_detail');
		return $result->result();
	}
}
?>