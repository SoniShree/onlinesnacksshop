<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');?>
<?php
Class Product_Model extends CI_Model
{
	//show product model
	public function __construct()
	{
		parent::__construct();
	}
	public function get_product($id=false)
	{
		if($id==false)
		{
				$this->db->where('product_status',1);
			$this->db->order_by("product_id", "desc");	
			$query = $this->db->get('product','3');
			return $query->result();
		}
		$this->db->where('product_status',1);
		$query = $this->db->get_where('product', array('product_id' => $id));

		return $query->row(); 
	}
	public function get_banner_page()
	{
			$this->db->where('status',1);
			$res=$this->db->get('banner');
		if($res->num_rows() > 0)
		{
			return $res->result_array();
		}
		else
		{
			return false;
		}
		
	}
	public function get_product_page()
	{
		$this->db->where('product_status',1);
		$res=$this->db->get('product','4');
		if($res->num_rows() > 0)
		{
			return $res->result_array();
		}
		else
		{
			return false;
		}
		
	}
	public function get_product_page1()
	{
		$this->db->where('product_status',1);
		$res=$this->db->get('product','4','5');
		if($res->num_rows() > 0)
		{
			return $res->result_array();
		}
		else
		{
			return false;
		}
		
	}
	public function get_product_page2()
	{
		$this->db->where('product_status',1);
		$res=$this->db->get('product','6');
		if($res->num_rows() > 0)
		{
			return $res->result_array();
		}
		else
		{
			return false;
		}
		
	}
	public function get_product_all($limit,$offset)
	{
		$this->db->where('product_status',1);
		$this->db->order_by('product_id','desc');
		$res=$this->db->get('product',$limit,$offset);
		if($res->num_rows() > 0)
		{
			return $res->result();
		}
		else
		{
			return false;
		}
		
	}
	public function get_product_row()
	{
				$this->db->where('product_status',1);
			$query = $this->db->get('product');
			return $query->num_rows;
	}
	public function get_new_product()
	{
						$this->db->where('product_status',1);
		$this->db->order_by('product_id','desc');
		$res=$this->db->get('product','3');
		if($res->num_rows() > 0)
		{
			return $res->result();
		}
		else
		{
			return false;
		}
		
	}
}
?>