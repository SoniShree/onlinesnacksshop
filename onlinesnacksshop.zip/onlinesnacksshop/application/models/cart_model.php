<?php
class Cart_model extends CI_Model
{
	public function insert($data)
	{	
		
		$customer_id=$this->session->userdata('c_id');
		$p_id=$this->input->post('product_id');
		$this->session->userdata('p_id',$p_id);
		$this->db->where('customer_id',$customer_id);
		
		$this->db->where('product_id',$p_id);
		$res=$this->db->get('order_detail');
		if($res->row())
		{
			$this->session->set_userdata('already_exist','This Product is alresdy exist');
			return false;
		}
		else
		{
			$result=$this->db->insert('order_detail',$data);
			if($result)
			{
				return true;
			}
			else
			{
				return false;
			}
		}
	}
	public function Customer_id($name)
	{
		return $this->db->select('customer_id')->where('customer_username',$name)->get('customer')->row();	
	}
	public function cart_info($name)
	{
			//echo $name;
			$res=$this->db->where('customer_name',$name)->get('order_detail');	
			//print_r($res);
			if($res->num_rows()>0)
			{			
				return $res->result();		
			}
			else
			{
				return "Cart is Empty"	;
			}
	}
	/*public function cart_delete($c_id,$user)
	{
		$this->db->where('customer_id',$c_id);
		$this->db->where('customer_name',$user);
		$res=$this->db->delete('order_detail');	
	}*/

	function update_cart($rowid, $qty, $price, $amount) {
 		$data = array(
			'rowid'   => $rowid,
			'qty'     => $qty,
			'price'   => $price,
			'amount'   => $amount
		);

		$this->cart->update($data);
	}
	/*function get_cart($c_id,$user)
	{
		$this->db->where('customer_id',$c_id);
		$this->db->where('customer_name',$user);
		$res=$this->db->get('order_detail');
		return $res->result();
	}*/
	function get_cart($c_id,$user)
	{
		$this->db->where('customer_id',$c_id);
		$this->db->where('customer_name',$user);
		$res=$this->db->get('cart_detail');
		return $res->result();
	}
	public function insert_cart($data)
	{	
		$customer_id=$this->session->userdata('c_id');
		$p_id=$this->input->post('product_id');
		$this->session->userdata('p_id',$p_id);
		$this->db->where('customer_id',$customer_id);
		$this->db->where('product_id',$p_id);
		$res=$this->db->get('cart_detail');
		if($res->row())
		{
			$this->session->set_userdata('already_exist','This Product is alresdy exist');
			return false;
		}
		else
		{
			$result=$this->db->insert('cart_detail',$data);
			if($result)
			{
				return true;
			}
			else
			{
				return false;
			}
		}
	}
	public function insert_cart_order($data)
	{	
		$customer_id=$this->session->userdata('c_id');
		
		$p_id=$this->input->post('product_id');
		$this->session->userdata('p_id',$p_id);
		$this->db->where('customer_id',$customer_id);
		$this->db->where('product_id',$p_id);
		$res=$this->db->get('order_detail');
		if($res->row())
		{
			$this->session->set_userdata('already_exist','This Product is alresdy exist');
			return false;
		}
		else
		{
			$result=$this->db->insert('order_detail',$data);
			if($result)
			{
				return true;
			}
			else
			{
				return false;
			}
		}
	}
	public function cart_delete($c_id,$user)
	{
		$this->db->where('customer_id',$c_id);
		$this->db->where('customer_name',$user);
		$res=$this->db->delete('cart_detail');	
	}
}

?>