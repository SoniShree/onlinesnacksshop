<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Checkout_model extends CI_Model
{
	public function add_order($data)
	{
		$result=$this->db->insert('orders', $data);

	   if($result)
       {
       		return true;
       }
       else
       {
       		return false;
       }

	}
	public function get_billing_info($c_id)
	{
		$this->db->where('customer_id',$c_id);
		$qry=$this->db->get('orders');
		return $qry->result();
	}
	public function cart_delete($c_id)
	{
		$this->db->where('customer_id',$c_id);
		$res=$this->db->delete('cart_detail');	
	}
	
}
?>