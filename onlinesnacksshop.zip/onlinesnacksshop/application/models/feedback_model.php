<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class feedback_model extends CI_Model
{
	public function contact_details()
	{
		$this->db->where('status',1);
		$this->db->order_by('contact_id','desc');
		$result=$this->db->get('contact','4');
		return $result->result();
	}
}
?>