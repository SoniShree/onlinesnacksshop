<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');?>
<?php
class Terms_model extends CI_Model
{
	public function get_info()
	{
			$this->db->where('url_key','terms');
			$query = $this->db->get('cms');
			return $query->result();
	}	
}
?>