<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Forget_model extends CI_model 
{
	
	public function check_email($check_email)
	{
		
		$this->db->select('email');
		$this->db->where($check_email);
	  	$qry = $this->db->get('login');
		return $qry->result();	
	}
	
	public function get_random_password($chars_min=8, $chars_max=10, $use_upper_case=true, $include_numbers=true, $include_special_chars=true)
    {
        $length = rand($chars_min, $chars_max);
        $selection = 'aeuoyibcdfghjklmnpqrstvwxz';
        if($include_numbers) 
		{
            $selection .= "1234567890";
        }
        if($include_special_chars) 
		{
            $selection .= "!@04f7c318ad0360bd7b04c980f950833f11c0b1d1quot;#$%&[]{}?|";
        }
                                
        $password = "";
        for($i=0; $i<$length; $i++) 
		{
            $current_letter = $use_upper_case ? (rand(0,1) ? strtoupper($selection[(rand() % strlen($selection))]) : $selection[(rand() % strlen($selection))]) : $selection[(rand() % strlen($selection))];            
            $password .=  $current_letter;
        }                
        
        return $password;
    }
	
	public function update($emailentered,$login_array)
	{
		$this->db->where('email',$emailentered);
		$this->db->update('login',$login_array);
		return;
	}
	
	public function sendemail($emailentered)
	{
	  $qry1=$this->db->query("select email,first_name from login where email='$emailentered'");
	  return $qry1->result();
	}
	
}
