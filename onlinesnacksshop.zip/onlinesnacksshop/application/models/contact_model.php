<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Contact_model extends CI_Controller
{
	public function add_cust($data)
	{
		$result=$this->db->insert('contact', $data);
       if($result)
       {
       		return true;
       }
       else
       {
       		return flase;
       }

	}
	public function get_info()
	{
			$this->db->where('url_key','contact');
			$query = $this->db->get('cms');
			return $query->result();
	}
	public function get_info_footer()
	{
			$this->db->where('url_key','footer');
			$query = $this->db->get('cms');
			return $query->result();
	}
}
?>