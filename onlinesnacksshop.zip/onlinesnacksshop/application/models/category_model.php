<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');?>
<?php
class category_model extends CI_Model
{
	public function __construct()
	{
		parent::__construct();
	}
	/*public function get_category($id=false)
	{
		if($id==false)
		{
			$this->db->where('category_status','1');
			$this->db->order_by("category_id", "category_desc");	
			$query = $this->db->get('category');
			return $query->result();
		}
		$query = $this->db->get_where('category', array('category_id' => $id));
		return $query->row(); 
	}*/
	public function get_category()
	{
		$this->db->select('*');
		$this->db->from('product','3');
		$this->db->join('category','category.category_id=product.category_id');
		$result=$this->db->get();
		return $result->result(); 

	}
	public function get_category_page()
	{
		$this->db->where('category_status','1');
		$this->db->order_by("category_id", "desc");	
		$query = $this->db->get('category','12');
		if($query->num_rows>0)
		{
			return $query->result();	
		}
		else
		{
			return false;
		}
	
	}
	public function get_category_page_all()
	{
		$this->db->where('category_status','1');
		$this->db->order_by("category_id", "desc");	
		$query = $this->db->get('category','9');
		if($query->num_rows>0)
		{
			return $query->result();	
		}
		else
		{
			return false;
		}
	
	}

	
	public function product_list($cat_id)
	{
		$this->db->where('category_id',$cat_id);
		$result=$this->db->get('product');
		return $result->result();
	}
	public function cat_name($cat_id)
	{
		$this->db->where('category_id',$cat_id);
		$result=$this->db->get('category');
		return $result->row();
	}
	

	public function get_info_footer()
	{
			$this->db->where('url_key','footer');
			$query = $this->db->get('cms');
			return $query->result();
	}
	
}
?>