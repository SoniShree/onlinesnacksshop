<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');?>
<?php
class news_model extends CI_Model
{
	public function __construct()
	{
		parent::__construct();
	}
	public function get_product($id=false)
	{
		if($id==false)
		{
				$this->db->where('news_status',1);
			$this->db->order_by("news_id", "news_desc");	
			$query = $this->db->get('news');
			return $query->result();
		}
			$this->db->where('news_status',1);
		$query = $this->db->get_where('news', array('news_id' => $id));
		return $query->row(); 
	}
	public function get_news_page()
	{
		$this->db->order_by("news_id", "desc");
		$this->db->where('news_status',1);
		$query = $this->db->get('news','2');
		return $query->result();	
	
	}
	public function get_news()
	{
		$this->db->order_by("news_id", "desc");
		$this->db->where('news_status',1);
		$query = $this->db->get('news','2');
		return $query->result();	
	
	}
	
}
?>