<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');?>
<?php
class menu_model extends CI_Model
{
	public function __construct()
	{
		parent::__construct();
	}
	public function get_category_page()
	{
		$this->db->where('category_status','1');
		$query = $this->db->get('category');
		return $query->result();	
	
	}
	public function get_product_page()
	{
		$this->db->where('category_status','1');
		$query = $this->db->get('product','3');
		return $query->result();	
	
	}
}
?>