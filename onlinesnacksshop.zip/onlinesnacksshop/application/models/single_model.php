<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');?>
<?php
Class single_model extends CI_Model
{
	//show news model
	public function __construct()
	{
		parent::__construct();
	}
	public function get_news($id=false)
	{
		if($id==false)
		{
			$this->db->where('news_status','1');
			$this->db->order_by("news_id", "desc");	
			$query = $this->db->get('news');
			return $query->result();
		}
		
		$query = $this->db->get_where('news', array('news_id' => $id));
		return $query->row(); 
	}
	public function get_news_page($limit,$offset)
	{
		$this->db->where('news_status','1');
		$this->db->order_by("news_id", "desc");	
		$query = $this->db->get('news',$limit,$offset);
		return $query->result();	
	
	}
	public function get_news_row()
	{
			$this->db->where('news_status','1');
			$query = $this->db->get('news');
			return $query->num_rows;
	}	
}
?>