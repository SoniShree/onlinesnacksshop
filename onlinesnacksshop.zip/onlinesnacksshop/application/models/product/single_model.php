<?php
class Single_model extends CI_Model
{
	public function __construct()
	{
		parent::__construct();
	}
	public  function retrieve_products($id,$c_id)
	 {
		$this->db->where('product_status',1);
		  $this->db->where('product_id',$id);
		  $query = $this->db->get('product',$id);
		  $product=$query->row();
		  return $product;
	 }	
	public function get_product_photos($id)
	{
		$this->db->where('product_id',$id);
		$image = $this->db->get('product_photos','4');
			
		return $image->result();
	}
	public function category_product($c_id)
	{
		$this->db->where('category_id',$c_id);
		$qry=$this->db->get('product');
		return $qry->result();
	}
}
?>