<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');?>
<?php
class product_view_model extends CI_Model
{
	public function __construct()
	{
		parent::__construct();
	}
	public function get_product($id)
	{
		if($id)
		{
			$this->db->where('product_status',1);
			$this->db->order_by("product_id", "product_desc");
			$this->db->where('category_id',$id);
			$query = $this->db->get('product');
			return $query->result();
		}
		$query = $this->db->get_where('product', array('category_id' => $id));
		return $query->row(); 
	}
	public function get_product_page()
	{
		$this->db->where('product_status',1);
		$query = $this->db->get('product','6');
		return $query->result();	
	
	}
	public function get_news_page()
	{
		$this->db->where('news_status',1);	
		$query = $this->db->get('news','3');
		return $query->result();	
	
	}
	public function get_category_name($id)
	{
		$this->db->where('category_status',1);
		$this->db->where('category_id',$id);
		$query=$this->db->get('category');
		return $query->result();
	}
	
}
?>