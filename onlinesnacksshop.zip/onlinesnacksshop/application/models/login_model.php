<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');?>
<?php
Class Login_Model extends CI_Model
{
	
	public function __construct()
	{
		parent::__construct();
		$this->load->helper('date');
	}
	public function login()
	{
		
	 	$username = $this->input->post('username');
		$password = $this->input->post('password');
		$this->db->where('customer_status',1);
		 $this ->db->where('customer_username',$username);
		 $this ->db->where('customer_password',md5($password));
	     $query = $this ->db->get('customer');
		
	   if($query->num_rows() == 1)
	   {
		 return TRUE;
	   }
	   else
	   {
		 return FALSE;
	   }
	}
	public function get_customerid($username)
	{
		$this->db->select('*');
		$this->db->where('customer_username',$username);
		$result=$this->db->get('customer');
		return $result->result_array();
	}
	
	
	public function userdata($email)
	{

		$result = $this->db->get_where('customer', array('customer_email' => $email));
		return $result->row();
	}
	public function get_random_password($chars_min=8, $chars_max=10, $use_upper_case=true, $include_numbers=true, $include_special_chars=true)
    {
        $length = rand($chars_min, $chars_max);
        $selection = 'aeuoyibcdfghjklmnpqrstvwxz';
        if($include_numbers) 
		{
            $selection .= "1234567890";
        }
        if($include_special_chars) 
		{
            $selection .= "04f7c318ad0360bd7b04c980f950833f11c0b1d1quot";
        }
                                
        $password = "";
        for($i=0; $i<$length; $i++) 
		{
            $current_letter = $use_upper_case ? (rand(0,1) ? strtoupper($selection[(rand() % strlen($selection))]) : $selection[(rand() % strlen($selection))]) : $selection[(rand() % strlen($selection))];            
            $password .=  $current_letter;
        }                
        
        return $password;
    }
	public function update($email,$pwd)
	{
		$data = array('customer_password' => $pwd);
		$this->db->where('customer_id',$this->session->userdata('cust_id'));
		$result=$this->db->update('customer', $data); 
		
	}

}
?>