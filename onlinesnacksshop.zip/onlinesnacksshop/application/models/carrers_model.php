<?php
class Carrers_Model extends CI_Model 
{

	public function __construct()
	{
		$this->load->database();
	}
	public function add_resume($data)
	{
		$this->db->insert('carrers', $data);
		return TRUE;
	}
	public function addemail()
	{
		$email=$this->input->post('email');
		 $created= date('Y-m-d H:i:s');
		$data=array('email_id'=>$email,'status'=>1,'created'=>$created);
		$this->db->insert('newsletter',$data);
	}
	public function chkmail()
	{
		$email=$this->input->post('email');
		$this->db->select('email_id',$email);
		$this->db->where('email_id',$email);
		$res = $this->db->get('newsletter');
		return $res->num_rows();
	}
	public function unscub($id)
	{
		$this->db->where('subs_id',$id);
		$this->db->update('newsletter',array('status'=>0));
	}
	public function resub()
	{
		$email=$this->input->post('email');
		$this->db->where('email_id',$email);
		$this->db->where('status',0);
		$res = $this->db->get('newsletter');
		if($res->num_rows()==1)
		{
			$id=$res->row()->subs_id;
			$this->db->where('subs_id',$id);
			$this->db->update('newsletter',array('status'=>1));
			return true;
		}
		else
		{
			return false;
		}
	}
}

?>