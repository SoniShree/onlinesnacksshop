<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');?>
<?php
Class Namkeen_model extends CI_Model
{
	public function __construct()
	{
		parent::__construct();
	}
	public function get_namkeen()
	{
		$qry=$this->db->get('namkeen');
		return $qry->result();
	}
}
?>