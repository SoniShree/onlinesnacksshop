<?php
class Single_model extends CI_Model
{
	public function __construct()
	{
		parent::__construct();
	}
	public  function retrieve_namkeen($id)
	 {
		$this->db->where('namkeen_status',1);
		  $this->db->where('namkeen_id',$id);
		  $query = $this->db->get('namkeen',$id);

		  $products=$query->row();
		  return $products;
	 }	
	public function get_namkeen_photos($id)
	{
		$this->db->where('namkeen_id',$id);
		$image = $this->db->get('namkeen_photos');
			
		return $image->result();
	}
}
?>