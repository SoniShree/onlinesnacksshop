<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');?>
<?php
class namkeen_view_model extends CI_Model
{
	public function __construct()
	{
		parent::__construct();
	}
	public function get_namkeen($id,$limit,$offset)
	{
		if($id)
		{
			
			$this->db->order_by("namkeen_id");
			$this->db->where('namkeen_status',1);
			$query = $this->db->get('namkeen',$limit,$offset);
			return $query->result();
		}
		$query = $this->db->get_where('namkeen', array('namkeen_id' => $id));
		return $query->row(); 
	}
	public function get_namkeen_page()
	{
		$this->db->where('namkeen_status',1);
		$query = $this->db->get('namkeen','3');
		return $query->result();	
	
	}
	public function get_news_page()	
	{
		$this->db->where('news_status',1);	
		$query = $this->db->get('news','3');
		return $query->result();	
	
	}
	public function get_category_name($id)
	{
		$this->db->where('category_status',1);
		$this->db->where('category_id',$id);
		$query=$this->db->get('category');
		return $query->result();
	}
	
	public function get_namkeen_page1($limit,$offset)
	{
		
		$this->db->where('namkeen_status','1');
		$this->db->order_by("namkeen_id", "desc");	
		$query = $this->db->get('namkeen',$limit,$offset);
		return $query->result();	
	
	}
	public function get_namkeen_row($id)
	{
			$this->db->where('namkeen_status','1');
			$query = $this->db->get('namkeen');
			return $query->num_rows;
	}	

	
}
?>