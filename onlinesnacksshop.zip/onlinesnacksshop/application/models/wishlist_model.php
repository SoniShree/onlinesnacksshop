<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class wishlist_model extends CI_Model {

	public function __construct()
	{
		parent::__construct();
	}
	public function get_Wishlist_record($id)
	{
		$this->db->select('*');
		$this->db->from('product');
		$this->db->where('customer_id',$id);
		$this->db->join('wishlist','wishlist.product_id=product.product_id');
		$result=$this->db->get();
		return $result->result(); 

	}
	public function get_Wishlist_namkeen_record($id)
	{
		$this->db->select('*');
		$this->db->from('namkeen');
		$this->db->where('customer_id',$id);
		$this->db->join('wishlist','wishlist.namkeen_id=namkeen.namkeen_id');
		$result=$this->db->get();
		return $result->result(); 

	}
	public  function retrieve_products($id)
	 {
		$this->db->where('product_status',1);
		$this->db->where('product_id',$id);
		$query = $this->db->get('product',$id);
		$products=$query->row();
		return $products;
	 }
	 public  function retrieve_namkeen_products($id)
	 {
		$this->db->where('namkeen_status',1);
		$this->db->where('namkeen_id',$id);
		$query = $this->db->get('namkeen',$id);
		$products=$query->row();
		return $products;
	 }
	 public function get_product_id()
	{
		$id=$this->input->post('product_id');
		$this->db->where('product_id',$id);
		$query=$this->db->get('product');
		return $query->row();	
	}
	 public function get_customer_id()
	{
		$this->db->where('customer_id');
		$query = $this->db->get('customer');
		return $query->row();	
	}	

	public function insert_wishlist($data)
	{
		//$c_id=$this->session->userdata('c_id');
		$customer_id=$this->session->userdata('c_id');
		$p_id=$this->input->post('product_id');
		$this->session->userdata('p_id',$p_id);
		$created= date('Y-m-d H:i:s');
		$updated= date('Y-m-d H:i:s');
		$data =
		array(
			'customer_id' =>$customer_id,
			'product_id' => $p_id ,
			'created'=>$created,
			'updated'=>$updated
		);
		
		$this->db->where('customer_id',$customer_id);
		$this->db->where('product_id',$p_id);
		
		$res=$this->db->get('wishlist');
		if($res->row())
		{
			$this->session->set_userdata('already_exist','This Product is alresdy exist');
			return false;
		}
		else
		{
			$result=$this->db->insert('wishlist', $data);
			if($result)
			{
				return true;
			}
			else
			{
				return false;
			}
		}
	}
	public function insert_namkeen_wishlist($data)
	{
		//$c_id=$this->session->userdata('c_id');
		$customer_id=$this->session->userdata('c_id');
		$p_id=$this->input->post('product_id');
		$this->session->userdata('p_id',$p_id);
		$created= date('Y-m-d H:i:s');
		$updated= date('Y-m-d H:i:s');
		$data =
		array(
			'customer_id' =>$customer_id,
			'namkeen_id' => $p_id ,
			'created'=>$created,
			'updated'=>$updated
		);
		
		$this->db->where('customer_id',$customer_id);
		$this->db->where('namkeen_id',$p_id);
		
		$res=$this->db->get('wishlist');
		if($res->row())
		{
			$this->session->set_userdata('already_exist','This Product is alresdy exist');
			return false;
		}
		else
		{
			$result=$this->db->insert('wishlist', $data);
			if($result)
			{
				return true;
			}
			else
			{
				return false;
			}
		}
	}
	public function delete_wishlist($id)
	{
		$this->db->delete('wishlist', array('wishlist_id' => $id));
		return TRUE;
		
	}
	public function delete_wishlist_addproduct($p_id)
	{
		$c_id=$this->session->userdata('c_id');
		$this->db->where('product_id',$p_id);
		$this->db->where('customer_id',$c_id);
		$this->db->delete('wishlist');
		return TRUE;
		
	}
}