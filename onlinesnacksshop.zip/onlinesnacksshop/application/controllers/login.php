<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Login extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();
		
		if($this->session->userdata('is_logged_in')==TRUE)
		{
			redirect('home');
		}
		$this->load->library('cart');
		$this->load->model('news_model','pm');
		$this->load->model('login_model','user');
		$this->load->model('cart_model');
		$this->load->model('category_model','cm');
		$this->load->model('contact_model','contact');
		
	}
	public function index()
	{
		
		$data['category']=$this->cm->get_category_page();
		$data['cms_footer']=$this->contact->get_info_footer();
		if(is_array($data['category']))
		{
			foreach($data['category'] as $value)
			{
				$productside[$value->category_id]=$this->cm->product_list($value->category_id);
			}
		}
		else
		{
			$productside=array();
		}
		$data['productside']=$productside;
		$data['category_p']=$this->cm->get_category();
		
		$data['cms_footer']=$this->contact->get_info_footer();
		$data['news']=$this->pm->get_news_page();
		if($this->session->userdata('is_logged_in')==FALSE)
		{
			$data['title']="Login Page";
			$data['page']="pages/login";
			$this->load->view('template/content',$data);
		}
		else
		{
			//if($this->session->userdata('lasturl')){
				//redirect($this->session->userdata('lasturl'));
			//}
			//else
			redirect('home');
		}
		
		
	}
	public function validate_form()
	{
		$this->load->model('login_model','user');
		$this->load->model('news_model','pm');
		$data['news']=$this->pm->get_news_page();
		$this->load->model('category_model','cm');
		$data['category']=$this->cm->get_category_page();
		$data['cms_footer']=$this->contact->get_info_footer();
		if(is_array($data['category']))
		{
			foreach($data['category'] as $value)
			{
				$productside[$value->category_id]=$this->cm->product_list($value->category_id);
			}
		}
		else
		{
			$productside=array();
		}
		$data['productside']=$productside;
		$data['category_p']=$this->cm->get_category();
		$this->form_validation->set_rules('username', 'Username', 'required|trim|min_length[4]|max_length[20]');
		$this->form_validation->set_rules('password', 'Password', 'required|trim|min_length[6]|max_length[15]');
	    if ($this->form_validation->run() == TRUE)
        {
		   $result = $this->user->login();
		   if($result==TRUE)
		   {
				$username=$this->input->post('username');
				$user=$this->session->set_userdata('user',$username);
				
				$id1=$this->user->get_customerid($this->input->post('username'));
				
				$id=$id1[0]['customer_id'];
				$c_email=$id1[0]['customer_email'];
				$c_fname=$id1[0]['customer_fname'];
				$c_lname=$id1[0]['customer_lname'];
				$ndata=array('username' => $this->input->post('username') , 'is_logged_in' => TRUE );
				$this->session->set_userdata('c_id',$id);
				$this->session->set_userdata('c_email',$c_email);
				$this->session->set_userdata('fname',$c_fname);
				$this->session->set_userdata('lname',$c_lname);
				$this->session->set_userdata($ndata);
				$c_id=$this->session->userdata('c_id');
				$user=$this->session->userdata('user');
				$this->load->model('cart_model');
				$res=$this->cart_model->get_cart($c_id,$user);
				foreach($res as $r)
				{
					$data=array
					(
						'id' => $r->product_id,
						'name' =>$r->product_name,
						'desc'=>$r->product_desc,
						'price' => $r->product_price,
						'img'=>$r->img,
						'qty' =>$r->quantity
					);
					$this->cart->insert($data);
				}
				$this->cart_model->cart_delete($c_id,$user);
				echo 1;
			}
		   else
		   {
				echo 0;
		   }
		}
		else
		{
			echo 0;
		}
		
		
	}
	public function validate_form_page()
	{
		
		$this->load->model('news_model','pm');
		$data['news']=$this->pm->get_news_page();
		$this->load->model('category_model','cm');
		$data['category']=$this->cm->get_category_page();
		$data['cms_footer']=$this->contact->get_info_footer();
		if(is_array($data['category']))
		{
			foreach($data['category'] as $value)
			{
				$productside[$value->category_id]=$this->cm->product_list($value->category_id);
			}
		}
		else
		{
			$productside=array();
		}
		$data['productside']=$productside;
		$data['category_p']=$this->cm->get_category();
		$this->form_validation->set_rules('username', 'Username', 'required|trim|min_length[4]|max_length[20]');
		$this->form_validation->set_rules('password', 'Password', 'required|trim|min_length[6]|max_length[15]');
	    if ($this->form_validation->run() == TRUE)
        {
		   $result = $this->user->login();
		   if($result==TRUE)
		   {
				$username=$this->input->post('username');
				$user=$this->session->set_userdata('user',$username);
				
				$id1=$this->user->get_customerid($this->input->post('username'));
				
				$id=$id1[0]['customer_id'];
				$c_email=$id1[0]['customer_email'];
				$c_fname=$id1[0]['customer_fname'];
				$c_lname=$id1[0]['customer_lname'];
				$ndata=array('username' => $this->input->post('username') , 'is_logged_in' => TRUE );
				$this->session->set_userdata('c_id',$id);
				$this->session->set_userdata('c_email',$c_email);
				$this->session->set_userdata('fname',$c_fname);
				$this->session->set_userdata('lname',$c_lname);
				$this->session->set_userdata($ndata);
				$c_id=$this->session->userdata('c_id');
				$user=$this->session->userdata('user');
				
				$res=$this->cart_model->get_cart($c_id,$user);
				foreach($res as $r)
				{
					$data=array
					(
						'id' => $r->product_id,
						'name' =>$r->product_name,
						'desc'=>$r->product_desc,
						'price' => $r->product_price,
						'img'=>$r->img,
						'qty' =>$r->quantity
					);
					$this->cart->insert($data);
				}
				$this->cart_model->cart_delete($c_id,$user);
				if($this->session->userdata('lasturl')){
				redirect($this->session->userdata('lasturl'));
			}
			else

				redirect('home');
			}
		   else
		   {
		
			$this->session->set_userdata('err','Username Or Password Missmatch...');
			$data['title']="Login Page";
			$data['page']="pages/login";
			$this->load->view('template/content',$data);
		   }
		}
		else
		{
			
		$data['title']="Login Page";
		$data['page']="pages/login";
		$this->load->view('template/content',$data);
		}
		
		
	}
	
}
?>