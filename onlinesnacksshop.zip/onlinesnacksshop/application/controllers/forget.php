<?php //if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Forget extends CI_Controller 
{
	public function __construct()
	{
		parent::__construct();
		$this->load->model('login_model');
		$this->load->helper('html');
		$this->load->model('contact_model','contact');
		
	}
	public function index()
	{
		$data['cms_footer']=$this->contact->get_info_footer();
		$this->load->model('category_model','cm');
		$data['category']=$this->cm->get_category_page();
		if(is_array($data['category']))
		{
			foreach($data['category'] as $value)
			{
				$productside[$value->category_id]=$this->cm->product_list($value->category_id);
			}
		}
		else
		{
			$productside=array();
		}
		$data['productside']=$productside;
		$this->load->model('news_model','pm');
		$data['news']=$this->pm->get_news_page();
		$data['title']="Forget Password";
		$data['page']="pages/forget";
		$this->load->view('template/content',$data);
	}	
	public function forgetpwd()
	{
		$data['cms_footer']=$this->contact->get_info_footer();
		$this->session->set_userdata('txtemail',$this->input->post('email'));
		$arr=$this->login_model->userdata($this->session->userdata('txtemail'));
		if($arr)
		{
			$email=$arr->customer_email;
			$fname=$arr->customer_username;
					$this->session->set_userdata('cust_id',$arr->customer_id);
			if($email == $this->input->post('email'))
			{
				/*
				 'protocol' => 'smtp',
			  'smtp_host' => 'ssl://smtp.googlemail.com',
			  'smtp_port' => 465,
			  'smtp_user' => 'sarfarajkazi7@gmail.com', // change it to yours
			  'smtp_pass' => '9033200540', // change it to yours
				*/
				$config = Array(
			 
			  'mailtype' => 'html',
			  'charset' => 'iso-8859-1',
			  'wordwrap' => TRUE
			);
				  $this->load->library('email', $config);
				  $this->email->set_newline("\r\n");
				  $pwd=$this->login_model->get_random_password();
				  $this->email->from('info@pragnyafoodproducts.com','Pragnyafoodproducts'); // change it to yours
				  $this->email->to($email);// change it to yours
				  $this->email->subject("Dear $fname Your New Password Is Here...");
					$link=site_url('/forget/changepwd');
					//$msg= "<table border='1'><tr><td>Sahil</td><td>Bhojani</td></tr><tr><td>Soyeb</td><td>Mancurian</td></tr></table>";
				  $this->email->message("Dear, $fname You Asked To Reset Your Account Password.
	Your New Password Is...\n".$pwd);
					
				  if($this->email->send())
				 {
					 $this->login_model->update($email,md5($pwd));
						$this->session->set_userdata('email',"Your login details has been sent to your Mail Id&nbsp;$fname...");
						redirect('login');
				 }
				 else
				{
					$this->session->set_userdata('err',"Connnection Error");
						redirect('forget');
	
				}
		}
		
		else
		{
			$this->session->set_userdata('err','Wrong Email, Try Again!!!...');
			redirect('forget');
						
		}
		
	}
	else
	{
		$this->session->set_userdata('err','Wrong Email, Try Again!!!...');
		redirect('forget');
	}
}
}
?>