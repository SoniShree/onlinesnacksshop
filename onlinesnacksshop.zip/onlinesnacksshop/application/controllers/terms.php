<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Terms extends CI_Controller
{
	public function index()
	{
		$this->load->model('news_model','pm');
		$this->load->model('terms_model');
		$this->load->model('category_model','cm');
		$data['category']=$this->cm->get_category_page();
		$this->load->model('contact_model','contact');
		$data['cms_footer']=$this->contact->get_info_footer();
		if(is_array($data['category']))
		{
			foreach($data['category'] as $value)
			{
				$productside[$value->category_id]=$this->cm->product_list($value->category_id);
			}
		}
		else
		{
			$productside=array();
		}
		$data['productside']=$productside;
		
		$data['news']=$this->pm->get_news_page();
		
		 $data['cms']=$this->terms_model->get_info();
		$data['title']="Welcome To Website";
		$data['page']="pages/tac";
		$this->load->view('template/content',$data);
	}
}
?>