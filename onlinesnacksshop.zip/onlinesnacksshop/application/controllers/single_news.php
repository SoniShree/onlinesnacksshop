<?php
if( ! defined('BASEPATH')) exit('No direct script access allowed');
class single_news extends CI_Controller
{
	public function __construct()
   {
	  parent::__construct();
	  $this->load->model('single_model','sm');
	  //$this->load->model('website_model');
	  $this->load->helper('date');
	  $this->load->library('form_validation');
	  $this->load->library('pagination');
	  $this->load->model('category_model','cm');
	  $this->load->model('news_model','pm');	
	  $this->load->model('contact_model','contact');
   }
   public function index()
   
   {
		$this->load->model('category_model','cm');
		$data['category']=$this->cm->get_category_page();
		$data['cms_footer']=$this->contact->get_info_footer();
		if(is_array($data['category']))
		{
			foreach($data['category'] as $value)
			{
				$productside[$value->category_id]=$this->cm->product_list($value->category_id);
			}
		}
		else
		{
			$productside=array();
		}
		$data['productside']=$productside;
		$data['news']=$this->sm->get_news();
		$this->load->model('news_model','pm');
		$data['news']=$this->pm->get_news();
		$data['title']="";
		$data['page']='pages/single_news';
		$this->load->view('template/content',$data);

   }

   public function view($id=FALSE)
   {
	   $data['cms_footer']=$this->contact->get_info_footer();
	   if($id)
	   {
		  $data['news_item'] = $this->sm->get_news($id);
		  if (empty($data['news_item']))
		  {
			redirect('pagenotfound');
		  }
			
			$data['category']=$this->cm->get_category_page();
		    if(is_array($data['category']))
			{
				foreach($data['category'] as $value)
				{
					$productside[$value->category_id]=$this->cm->product_list($value->category_id);
				}
			}
			else
			{
				$productside=array();
			}
			$data['productside']=$productside;
			$data['category_p']=$this->cm->get_category();
			
			$data['news']=$this->pm->get_news();
			$data['page']='pages/index';
			$data['title']="News";
			$data['page']='pages/single_news';
			$this->load->view('template/content',$data);  
	   }
	   else
	   {
		   redirect('pagenotfound');
	   }
   }
   public function view_news()
   {
	   $data['cms_footer']=$this->contact->get_info_footer();
	   $this->load->model('category_model','cm');
	   $this->load->model('single_model','sm');
	   $data['category']=$this->cm->get_category_page();
	   if(is_array($data['category']))
		{
			foreach($data['category'] as $value)
			{
				$productside[$value->category_id]=$this->cm->product_list($value->category_id);
			}
		}
		else
		{
			$productside=array();
		}
		$data['productside']=$productside;
 $this->load->model('category_model','cm');
			
		$data['category_p']=$this->cm->get_category();
		$this->load->model('news_model','pm');
		$data['news']=$this->pm->get_news();
   	$data['num_rows']=$this->sm->get_news_row();
	
    
    $config['base_url'] = site_url().'/single_news/view_news/';
    $config['total_rows'] = $data['num_rows'];
    $config['per_page'] = $data['per_page']= 3;
    $config['num_links'] = 3;
    $config['uri_segment'] = 3;
    $config['full_tag_open'] = '<p>';
    $config['full_tag_close'] = '</p>';
    $config['cur_tag_open'] = '<a><b><u>';
    $config['cur_tag_close'] = '</u></b></a>';
    $this->pagination->initialize($config);
    $data['news_all']=$this->sm->get_news_page($config['per_page'], $this->uri->segment(3));
    $data['link']=$this->pagination->create_links();
   	$data['title']="";
	$data['page']='pages/news';
	$this->load->view('template/content',$data);
   }
}
?>