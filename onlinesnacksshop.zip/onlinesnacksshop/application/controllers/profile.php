<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Profile extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();
		if($this->session->userdata('is_logged_in')==FALSE)
		{
			
			redirect('home');
		}
		$this->load->model('customer_model','customer');
		$this->load->model('contact_model','contact');
		$this->load->model('category_model','cm');
	}
	public function index()
	{
                
		//$data['cms_footer']=$this->contact->get_info_footer();
		$this->load->model('category_model','cm');
		$data['category']=$this->cm->get_category_page();
		if(is_array($data['category']))
		{
			foreach($data['category'] as $value)
			{
				$productside[$value->category_id]=$this->cm->product_list($value->category_id);
			}
		}
		else
		{
			$productside=array();
		}
		$data['productside']=$productside;
		$data['customer_profile']=$this->customer->settings();
		$this->load->model('news_model','pm');
		$data['news']=$this->pm->get_news_page();
		$data['title']="Customer Profile";
		$data['page']='pages/profile';
		$this->load->view('template/content',$data);	
	}
	public function chngprofile()
	{
		$data['cms_footer']=$this->contact->get_info_footer();
		$this->load->model('category_model','cm');
		$data['category']=$this->cm->get_category_page();
		if(is_array($data['category']))
		{
			foreach($data['category'] as $value)
			{
				$productside[$value->category_id]=$this->cm->product_list($value->category_id);
			}
		}
		else
		{
			$productside=array();
		}
		$data['productside']=$productside;
		$this->load->model('news_model','pm');
		$data['news']=$this->pm->get_news_page();
		 $this->form_validation->set_rules('fname', 'FirstName', 'required|trim|min_length[2]|max_length[20]|alpha');
		 $this->form_validation->set_rules('lname', 'LastName', 'required|trim|min_length[2]|max_length[20]|alpha');
		 $this->form_validation->set_rules('address', 'Address', 'required|trim|min_length[5]|max_length[100]');
		if ($this->form_validation->run() == FALSE)
		{
			$this->index();

	  	}
	  else
	  {
				$result=$this->customer->updatecustomer();
				$this->session->set_userdata('update','Update Successfully...!!! ');
				redirect('profile');
	  }
	}
	public function pwdform()
	   {
		   $data['cms_footer']=$this->contact->get_info_footer();
		  $this->load->model('category_model','cm');
		$data['category']=$this->cm->get_category_page();
		if(is_array($data['category']))
		{
			foreach($data['category'] as $value)
			{
				$productside[$value->category_id]=$this->cm->product_list($value->category_id);
			}
		}
		else
		{
			$productside=array();
		}
		$data['productside']=$productside;
		  $data['customer_profile']=$this->customer->settings();
		  $this->load->model('news_model','pm');
		$data['news']=$this->pm->get_news_page();
		   $data['title']="Change Password";
		  $data['page']='pages/chngpwd';
		  $this->load->view('template/content',$data);
		 
	   }
   public function chngpwd()
   {
	   $data['cms_footer']=$this->contact->get_info_footer();
	   $this->load->model('category_model','cm');
		$data['category']=$this->cm->get_category_page();
		if(is_array($data['category']))
		{
			foreach($data['category'] as $value)
			{
				$productside[$value->category_id]=$this->cm->product_list($value->category_id);
			}
		}
		else
		{
			$productside=array();
		}
		$data['productside']=$productside;
		$this->load->model('news_model','pm');
		$data['news']=$this->pm->get_news_page();
   	$this->form_validation->set_rules('cpassword', 'Current Password', 'required|trim|min_length[4]|max_length[20]|');
   	$this->form_validation->set_rules('npassword', 'New Password', 'required|matches[cnpassword]|min_length[4]|max_length[20]');
	$this->form_validation->set_rules('cnpassword', 'Confirm Password', 'required|min_length[4]|max_length[20]');
	if ($this->form_validation->run() == FALSE)
	{
		$this->pwdform();
	}
	else
	{
		$this->load->model('customer_model','customer');
		$result=$this->customer->chngpwd();	
		
		redirect('profile/pwdform');
	}
  
   }
   public function order_details()
   {
       $this->load->model('category_model');
	   //$data['cms_footer']=$this->contact->get_info_footer();
		$data['category']=$this->category_model->get_category_page();
		if(is_array($data['category']))
		{
			foreach($data['category'] as $value)
			{
				$productside[$value->category_id]=$this->cm->product_list($value->category_id);
			}
		}
		else
		{
			$productside=array();
		}
		$data['productside']=$productside;
		$data['customer_profile']=$this->customer->settings();
		$this->load->model('news_model','pm');
		$data['news']=$this->pm->get_news_page();
	   //$this->load->model('customer_model','customer');
	   //$data['o_details']=$this->customer->get_order_details();
		$data['title']="Order Status";
		$data['page']='pages/order_details';
		$this->load->view('template/content',$data);
   }
   public function order_info()
   {
	   $data['cms_footer']=$this->contact->get_info_footer();
	   	
		$data['category']=$this->cm->get_category_page();
		if(is_array($data['category']))
		{
			foreach($data['category'] as $value)
			{
				$productside[$value->category_id]=$this->cm->product_list($value->category_id);
			}
		}
		else
		{
			$productside=array();
		}
		$data['productside']=$productside;
		$data['customer_profile']=$this->customer->settings();
		$this->load->model('news_model','pm');
		$data['news']=$this->pm->get_news_page();
		
		
		$o_id=$this->input->post('order_no');
		$this->load->model('customer_model','customer');
		$data['o_details']=$this->customer->get_order_details($o_id);
		if(empty($data['o_details']))
		{
			$this->session->set_userdata('ord_id',"Invalid Order Number Or This Order Was Cancelled Please Write The Correct Order Number");
		}
		else
		{
			$data['o_info']=$this->customer->get_details($o_id);
		}
		
		$data['title']="Order Status";
		$data['page']='pages/order_details';
		$this->load->view('template/content',$data);
   }
   public function cancel_order()
   {
	   $data['cms_footer']=$this->contact->get_info_footer();
	   $this->load->model('category_model','cm');
		$data['category']=$this->cm->get_category_page();
		if(is_array($data['category']))
		{
			foreach($data['category'] as $value)
			{
				$productside[$value->category_id]=$this->cm->product_list($value->category_id);
			}
		}
		else
		{
			$productside=array();
		}
		$data['productside']=$productside;
		$data['customer_profile']=$this->customer->settings();
		$this->load->model('news_model','pm');
		$data['news']=$this->pm->get_news_page();
		
		
		$o_id=$this->input->post('order_number');
		$this->load->model('customer_model','customer');
		$res=$this->customer->cencel_my_order($o_id);
		$email=$this->session->userdata('c_email');
		$fname=$this->session->userdata('fname');
		$lname=$this->session->userdata('lname');
		$odr_id=$this->session->userdata('order_no');
		$url=base_url();
		$msg='<div style="font-family:Tahoma">

  <table style="border:1px solid #ececec" align="center" border="0" cellpadding="0" cellspacing="0" width="640">
    <tbody>

    <tr><td>
       <table  style="width:100%;border-collapse:collapse"> 
           <tbody>
            <tr> 
             <td rowspan="2" style="width:115px;padding:20px 20px 0 0;vertical-align:top;font-size:13px;line-height:18px;font-family:Arial,sans-serif"> <a href="'."$url".'" target="_blank" style="text-decoration:none;"> <h2 style="width:250px">Pragnya Food Products</h2> </a> </td> 
           
             <td style="text-align:right;padding:5px 0;border-bottom:1px solid rgb(204,204,204);white-space:nowrap;vertical-align:top;font-size:13px;line-height:18px;font-family:Arial,sans-serif"> <span style="text-decoration:none;color:rgb(204,204,204);font-size:15px;font-family:Arial,sans-serif">&nbsp;&nbsp;</span>   </td>  
            </tr> 
            <tr> 
             <td colspan="3" style="text-align:right;padding:7px 0 5px 0;vertical-align:top;font-size:13px;line-height:18px;font-family:Arial,sans-serif"> <h2 style="font-size:20px;line-height:24px;margin:0;padding:0;font-weight:normal;color:rgb(0,0,0)!important">Order Has Been Cancelled</h2> Order '."$odr_id".' <br> </td> 
            </tr> 
           </tbody>
          </table>
        </td>
      </tr>
<tr>
<td>
<hr color="#000">
</td>
</tr>
      <tr>
          <td>&nbsp;</td>
      </tr>




                 <tr>
             <td style="border-left:10px solid rgb(255,255,255);border-right:10px solid rgb(255,255,255);border-bottom:10px solid rgb(255,255,255);padding:5px 10px 10px;font-family:Arial,Helvetica,sans-serif;margin:0px;padding:10px;list-style-position:inside;font-size:12px;line-height:15pt" width="585">Dear '."$fname&nbsp;$lname".', <br> <br>

         <br>
			You are receiving this notification because one or more items in your order '."$odr_id".' have been
	    cancelled.<br><br> We at Pragnya Food Products deeply regret the inconvenience caused to a valued customer like you, and extend our
		heartfelt apologies.
	
               
              
               <br>
              
               
               <table>
                <tbody><tr>
                  <td>
               <br>
               For any further concerns, call +91 937-771-2229 (24 hours, 7 days a week). <br>
               <br>

               Regards,<br>
               Pragnya Food Products
             </td>
           </tr>
         </tbody></table>
       </td>
       </tr>

         <tr>
          <td>
            
         </td>
       </tr>




       <tr>
        <td style="font-family:arial;font-size:13px;color:#000000">
          
      </td>
    </tr>

    <tr><td style="padding:15px;font-size:13px;font-family:arial">In the mean time, check more products at <a href='."$url".' style="text-decoration:none;color:rgb(0,102,153);font:12px/16px Arial,sans-serif" target="_blank">Pragnya Food Products</a> </td></tr>

  </tbody></table><div class="yj6qo"></div><div class="adL">

</div></div>';
/*
'protocol' => 'smtp',
			  'smtp_host' => 'ssl://smtp.googlemail.com',
			  'smtp_port' => 465,
			  'smtp_user' => 'sarfarajkazi7@gmail.com', // change it to yours
			  'smtp_pass' => '9033200540', // change it to yours*/
		$config = Array(
			  'mailtype' => 'html',
			  'charset' => 'iso-8859-1',
			  'wordwrap' => TRUE
			);
				$this->load->library('email', $config);
			  $this->email->set_newline("\r\n");
			  $this->email->from('info@pragnyafoodproducts.com','Pragnyafoodproducts'); // change it to yours
			  $this->email->to($email);// change it to yours
			  $this->email->subject("One Or More Items From Your Order Have Been Cancelled");
				
			  $this->email->message($msg);
			  $this->email->send();
			  
			  //for admin
			  $msg2='<div style="font-family:Tahoma">

  <table style="border:1px solid #ececec" align="center" border="0" cellpadding="0" cellspacing="0" width="640">
    <tbody>

    <tr><td>
       <table  style="width:100%;border-collapse:collapse"> 
           <tbody>
            <tr> 
             <td rowspan="2" style="width:115px;padding:20px 20px 0 0;vertical-align:top;font-size:13px;line-height:18px;font-family:Arial,sans-serif"> <a href="'."$url".'" target="_blank" style="text-decoration:none;"> <h2 style="width:250px">Pragnya Food Products</h2> </a> </td> 
           
             <td style="text-align:right;padding:5px 0;border-bottom:1px solid rgb(204,204,204);white-space:nowrap;vertical-align:top;font-size:13px;line-height:18px;font-family:Arial,sans-serif"> <span style="text-decoration:none;color:rgb(204,204,204);font-size:15px;font-family:Arial,sans-serif">&nbsp;&nbsp;</span>   </td>  
            </tr> 
            <tr> 
             <td colspan="3" style="text-align:right;padding:7px 0 5px 0;vertical-align:top;font-size:13px;line-height:18px;font-family:Arial,sans-serif"> <h2 style="font-size:20px;line-height:24px;margin:0;padding:0;font-weight:normal;color:rgb(0,0,0)!important">Order Has Been Cancelled</h2> Order # '."$odr_id".' <br> </td> 
            </tr> 
           </tbody>
          </table>
        </td>
      </tr>
<tr>
<td>
<hr color="#000">
</td>
</tr>
      <tr>
          <td>&nbsp;</td>
      </tr>




                 <tr>
             <td style="border-left:10px solid rgb(255,255,255);border-right:10px solid rgb(255,255,255);border-bottom:10px solid rgb(255,255,255);padding:5px 10px 10px;font-family:Arial,Helvetica,sans-serif;margin:0px;padding:10px;list-style-position:inside;font-size:12px;line-height:15pt" width="585">Dear Admin, <br> <br>

         <br>
			You are receiving this notification because one or more items '."$odr_id".' have been
	    cancelled.
               <br> 
               <table>
                <tbody><tr>
                  <td>
				<br>
               <br>

               Regards,<br>
               Pragnya Food Products
             </td>
           </tr>
         </tbody></table>
       </td>
       </tr>

         <tr>
          <td>
            
         </td>
       </tr>




       <tr>
        <td style="font-family:arial;font-size:13px;color:#000000">
          
      </td>
    </tr>

    <tr><td style="padding:15px;font-size:13px;font-family:arial">In the mean time, check <a href='."$url".' style="text-decoration:none;color:rgb(0,102,153);font:12px/16px Arial,sans-serif" target="_blank">Pragnya Food Products</a> </td></tr>

  </tbody></table><div class="yj6qo"></div><div class="adL">

</div></div>';
		/*
		  'protocol' => 'smtp',
			  'smtp_host' => 'ssl://smtp.googlemail.com',
			  'smtp_port' => 465,
			  'smtp_user' => 'sarfarajkazi7@gmail.com', // change it to yours
			  'smtp_pass' => '9033200540', // change it to yours
		*/
			  $config = Array(
			  'mailtype' => 'html',
			  'charset' => 'iso-8859-1',
			  'wordwrap' => TRUE
			);
			$this->load->library('email', $config);
			  $this->email->set_newline("\r\n");
			  $this->email->from('info@pragnyafoodproducts.com','Pragnyafoodproducts'); // change it to yours
			  $this->email->to('info@pragnyafoodproducts.com');// change it to yours
			  $this->email->subject("One Or More Items From Your Order Have Been Cancelled");
			  $this->email->message($msg2);
			  $this->email->send();
			 

			 
		if($res)
		{
			$this->session->set_userdata('cancel_odr',"Your Order Cancelled Succsessfully");
		}
		$data['title']="Order Status";
		$data['page']='pages/order_details';
		$this->load->view('template/content',$data);
   }
   public function order_information($odr_id=FALSE)
   {	
   		$data['cms_footer']=$this->contact->get_info_footer();
   		$this->load->model('category_model','cm');
		$data['category']=$this->cm->get_category_page();
		if(is_array($data['category']))
		{
			foreach($data['category'] as $value)
			{
				$productside[$value->category_id]=$this->cm->product_list($value->category_id);
			}
		}
		else
		{
			$productside=array();
		}
		$data['productside']=$productside;
		$data['customer_profile']=$this->customer->settings();
		$this->load->model('news_model','pm');
		$data['news']=$this->pm->get_news_page();
		$data['o_details']=$this->customer->get_order_details($odr_id);
		$data['o_info']=$this->customer->get_details($odr_id);
		
		$data['title']="Order Status";
		$data['page']='pages/order_details';
		$this->load->view('template/content',$data);
   }
   public function pdf()
   {
	   $data['cms_footer']=$this->contact->get_info_footer();
	   $o_id=$this->input->post('order_number');
	   $data['o_details']=$this->customer->get_order_details($o_id);
	    $this->session->set_userdata('o_details',$data['o_details']);
		if(empty($data['o_details']))
		{
			$this->session->set_userdata('ord_id',"Invalid Order Number Or This Order Was Cancelled Please Write The Correct Order Number");
		}
		else
		{
			$data['o_info']=$this->customer->get_details($o_id);
			$this->session->set_userdata('o_info',$data['o_info']);
		}
	   	$o_details=$this->session->userdata('o_details');
	   	$o_info=$this->session->userdata('o_info');		
		
		if($o_details)
		{
			foreach($o_details as $s)
			{
				$o=$s;
				
			}
		}
		else
		{
			redirect('');
		}
		
		$c_id=$this->session->userdata('c_id');
		//$this->session->set_userdata('order_no',$arr[2]);
		//$odr_id=$this->session->userdata('order_no');
		$gtotal=$this->session->userdata('gtotal');
		$date=date('Y-m-d H:i:s');
			$this->load->model('fpdf');
			$this->fpdf->AddPage();
			$this->fpdf->cell(0,10,"","",1,'C');
			$this->fpdf->cell(0,10,"","",1,'C');
			$this->fpdf->SetFont('Arial','B',30);
			$this->fpdf->cell(88,20,"Pragnya Food Product",'','','L');
			$this->fpdf->SetFont('Arial','B',10);
			$this->fpdf->cell(0,10,"","",1,'C');
			$this->fpdf->cell(50,20,"Tel: 9377712229",'','','L');
			$this->fpdf->cell(0,10,"","",1,'C');
			$this->fpdf->SetFont('Arial','B',10);
			$this->fpdf->cell(50,20,"Order No:-".$o->order_number,'','L');
			$this->fpdf->cell(0,10,"","",1,'C');
			$this->fpdf->SetFont('Arial','B',10);
			$this->fpdf->cell(50,20,"Date : ".date('Y/m/d'),'','','L');
			$this->fpdf->cell(0,10,"","",1,'C');
			$this->fpdf->cell(50,20,"First Name:- ".$o->ship_firstname,'','','L');
			$this->fpdf->cell(50,20,"Last Name:- ".$o->ship_lastname,'','','L');
			$this->fpdf->cell(0,10,"","",1,'C');
			$this->fpdf->cell(50,20,"Your Email:- ".$o->ship_email,'','','L');
			$this->fpdf->cell(0,10,"","",1,'C');
			$this->fpdf->cell(50,20,"Your Mobile.No :- ".$o->ship_phone,'','','L');
			$this->fpdf->cell(0,10,"","",1,'C');
			$this->fpdf->cell(50,20,"Address :- ".$o->ship_address1,'','','L');
			$this->fpdf->cell(0,10,"","",1,'C');
			$this->fpdf->cell(0,10,"","",1,'C');
			//
			$this->fpdf->SetFont('Arial','B',8);
			
			$this->fpdf->Cell(30,8,"Product Name",1,'','C');
			$this->fpdf->Cell(30,8,"Product Image",1,'','C');
			$this->fpdf->Cell(40,8,"Product Quantity",1,'','C');
			$this->fpdf->Cell(30,8,"Price",1,'','C');
			$this->fpdf->Cell(30,8,"SubTotal Amount",1,1,'C');
			$this->fpdf->SetFillColor(220,220,220);
	    	$this->fpdf->SetFont('');
			$fill = false;
			$grand_total=0;
			
			foreach ($o_info as $items)
			{
				$this->fpdf->Cell(30,8,ucfirst($items->product_name),'LR',0,'C',$fill);
				//$this->fpdf->Image();
				$this->fpdf->Cell(30,8,ucfirst($items->product_name),'LR',0,'C',$fill);
				$this->fpdf->Cell(40,8,number_format($items->quantity),'LR',0,'C',$fill);
				$this->fpdf->Cell(30,8,number_format($items->product_price),'LR',0,'C',$fill);
				$this->fpdf->Cell(30,8,number_format($items->total),'LR',0,'C',$fill);
				$this->fpdf->Ln();
				$fill = !$fill;
				$grand_total = $grand_total + $items->total;
			}
		
			$this->fpdf->Cell(160,0,"",1,1,'C');
			$this->fpdf->SetFont('Arial','B',8);	
			$this->fpdf->cell(30,20,"Delivery Charge : ".$o->shipping,'','','L');	
			$this->fpdf->SetFont('Arial','B',18);	
			$this->fpdf->cell(0,10,"","",1,'C');
			$this->fpdf->cell(100,30,"Total Amount : ".$o->g_total,'','','L');
			$this->fpdf->Output();

   }
}
?>