<?php
class Newsletter extends CI_Controller {
	 public function __construct()
	 {
		 parent::__construct();
		 $this->load->model('carrers_model');
		 $this->load->model('contact_model','contact');
	 }
	 public function regemail()
	 {
		 $data['cms_footer']=$this->contact->get_info_footer();
		 $this->load->library('form_validation');
		 $this->form_validation->set_rules('email', 'Email', 'trim|required|valid_email');
		 if ($this->form_validation->run() === FALSE)
		 {
			 
			 echo 0;
		 }
		 else
		 {
			 $resemail = $this->carrers_model->chkmail();
			 if($resemail == 1)
			 {
				 if($this->carrers_model->resub())
				 {
					 echo 3;
				 }
				 else
				 {
				 	echo 2;
				 }
			 }
			 else
			 {
			 	$this->carrers_model->addemail();
			 	echo 1;
			 }
		 }
	 }
	 public function unsubscribe($id)
	 {
		 if($id!="")
		 {
			 $this->carrers_model->unscub($id);
			 echo "<script>window.close();</script>";
		 }
	 }
}