<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Wishlist extends CI_Controller
{
	public function __construct()
   	{
		  parent::__construct();
		  $is_logged_in=$this->session->userdata('is_logged_in');
		  if(!isset($is_logged_in) || $is_logged_in != TRUE)
		  {
			redirect('login');
		  }
		  $this->load->model('category_model','cm');
		  $this->load->model('wishlist_model','wm');
		  $this->load->model('news_model','pm');
		  $this->load->model('contact_model','contact');
		  $p_id=$this->input->post('product_id');
		  $p_id=$this->session->set_userdata('product_id',$p_id);
   	}
	public function index()
	{
		
		$data['cms_footer']=$this->contact->get_info_footer();
		redirect('');
	}
	public function add($id=FALSE)
	{
		
		$data['cms_footer']=$this->contact->get_info_footer();
		$data['product_id']=$this->wm->get_product_id();
		  $data['customer_id']=$this->wm->get_customer_id();
		  $res=$this->wm->insert_wishlist($data);	
		  
		 if($id)
		{
			$data['products'] = $this->wm->retrieve_products($id);
			
			if(empty($data['products']))
			{
				redirect('pagenotfound');
			}
			$this->session->set_userdata('add','Your Product Added in the Wishlist');
			$data['category']=$this->cm->get_category_page();
			redirect('products');
		}
		else
		{
			redirect('pagenotfound');
		}
		redirect('wishlist');
	}
	public function add_namkeen($id=FALSE)
	{
		 $data['product_id']=$this->wm->get_product_id();
		  $data['customer_id']=$this->wm->get_customer_id();
		  //$res=$this->wm->insert_wishlist($data);	
		  $res2=$this->wm->insert_namkeen_wishlist($data);
		 if($id)
		{
			$data['namkeen'] = $this->wm->retrieve_namkeen_products($id);
			
			if(empty($data['namkeen']))
			{
				redirect('pagenotfound');
			}
			$this->session->set_userdata('add','Your Product Added in the Wishlist');
			$data['category']=$this->cm->get_category_page();
			redirect('namkeen');
		}
		else
		{
			redirect('pagenotfound');
		}
		redirect('wishlist');
	}
	public function delete($id=FALSE)
	{
		if($id)
		{
			$this->wm->delete_wishlist($id);
      		$this->session->set_userdata('del','Wishlist Product Deleted Succesfully...');
      		redirect('wishlist/view_wishlist/'.$this->session->userdata('c_id'));
		}
	}
	public function view_wishlist($id=FALSE)
	{
		
		$this->load->model('category_model','cm');
		$data['category']=$this->cm->get_category_page();
		if(is_array($data['category']))
		{
			foreach($data['category'] as $value)
			{
				$productside[$value->category_id]=$this->cm->product_list($value->category_id);
			}
		}
		else
		{
			$productside=array();
		}
		$data['productside']=$productside;
		
		$data['news']=$this->pm->get_news();
		
		$data['wishlist_item']=$this->wm->get_Wishlist_record($id);
		$data['wishlist_namkeen_item']=$this->wm->get_Wishlist_namkeen_record($id);
		
		
		$data['title']="My Wishlist";
		$data['page']="pages/wishlist_view";
		$this->load->view('template/content',$data);
	}
	
}
?>