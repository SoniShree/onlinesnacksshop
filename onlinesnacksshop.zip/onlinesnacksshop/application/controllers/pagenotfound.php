<?php
class Pagenotfound extends CI_Controller
{
	public function index()
	{
		$this->load->model('contact_model','contact');
		$this->load->model('category_model','cm');
		$data['category']=$this->cm->get_category_page();
		$data['cms_footer']=$this->contact->get_info_footer();
	   	if(is_array($data['category']))
		{
			foreach($data['category'] as $value)
			{
				$productside[$value->category_id]=$this->cm->product_list($value->category_id);
			}
		}
		else
		{
			$productside=array();
		}
		$data['productside']=$productside;
		$this->output->set_status_header('404'); 
		$data['title']='404:: Page Not Found';
		$data['page']="pages/404";
		$this->load->view('template/content',$data);
	}

}
	
   	

?>