<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Categories extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->model('category_model','cm');
		$this->load->model('product_model');
		$this->load->library('form_validation');
		$this->load->model('news_model','pm');
		$this->load->model('contact_model','contact');
	}
	public function index()
	{
		$data['cms_footer']=$this->contact->get_info_footer();
		$data['categories']=$this->cm->get_category_page_all();
		$data['category']=$this->cm->get_category_page();
		if(is_array($data['category']))
		{
			foreach($data['category'] as $value)
			{
				$productside[$value->category_id]=$this->cm->product_list($value->category_id);
			}
		}
		else
		{
			$productside=array();
		}
		$data['productside']=$productside;		
		$data['title']="Welcome To Website";
		$data['product']=$this->product_model->get_product_page();
		$data['product1']=$this->product_model->get_product_page1();
		$data['product2']=$this->product_model->get_product_page2();
		$data['banner']=$this->product_model->get_banner_page();
		
		$data['news']=$this->pm->get_news();
		$data['title']="Categories";
		$data['page']="pages/categories";
		$this->load->view('template/content',$data);
	}
	public function view_products($id=FALSE)
	{
		$data['cms_footer']=$this->contact->get_info_footer();
		if($id)
		{
			$data['category_product']=$this->cm->product_list($id);
			$data['categories']=$this->cm->get_category_page();
			$data['category']=$this->cm->get_category_page();
			if(is_array($data['category']))
			{
				foreach($data['category'] as $value)
				{
					$productside[$value->category_id]=$this->cm->product_list($value->category_id);
				}
			}
			else
			{
				$productside=array();
			}
			$data['productside']=$productside;		
			$data['title']="Welcome To Website";
			$data['product']=$this->product_model->get_product_page();
			$data['product1']=$this->product_model->get_product_page1();
			$data['product2']=$this->product_model->get_product_page2();
			$data['banner']=$this->product_model->get_banner_page();
			$this->load->model('news_model','pm');
			$data['news']=$this->pm->get_news();
			$data['cat_name']=$this->cm->cat_name($id);
			$data['title']="Categories";
			$data['page']="pages/category_product";
			$this->load->view('template/content',$data);
		}
	}

}