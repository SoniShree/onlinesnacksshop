<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class products extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->model('product_model');
		$this->load->library('form_validation');
		$this->load->model('category_model','cm');
		$this->load->library('pagination');
		$this->load->model('news_model','pm');
		$this->load->model('product/single_model','sm');
		$this->load->model('category_model','cm');
		$this->load->model('contact_model','contact');
	}

	public function index()
	{
		
		$data['news']=$this->pm->get_news_page();
		$this->load->model('category_model','cm');
		
		$data['cms_footer']=$this->contact->get_info_footer();
		$data['category_p']=$this->cm->get_category();
		$data['category']=$this->cm->get_category_page();
		if(is_array($data['category']))
		{
			foreach($data['category'] as $value)
			{
				$productside[$value->category_id]=$this->cm->product_list($value->category_id);
			}
		}
		else
		{
			$productside=array();
		}
		$data['productside']=$productside;
		$this->load->model('product_model');
		$data['num_rows']=$this->product_model->get_product_row();
		$this->load->library('pagination');
		$config['base_url'] = site_url().'/products/index/';
		$config['total_rows'] = $data['num_rows'];
		$config['per_page'] = $data['per_page']= 6;
		$config['num_links'] = 3;
		$config['uri_segment'] = 3;
		$config['full_tag_open'] = '<li>';
		$config['full_tag_close'] = '</li>';
		$config['cur_tag_open'] = '<a><b><u>';
		$config['cur_tag_close'] = '</u></b></a>';
		$this->pagination->initialize($config);
		$data['product']=$this->product_model->get_product_all($config['per_page'], $this->uri->segment(3));
		$data['link']=$this->pagination->create_links();
		$data['product_new']=$this->product_model->get_new_product();
		$data['title']="Products";
		$data['banner']=$this->product_model->get_banner_page();
		$data['page']="pages/products";
		$this->load->view('template/content',$data);
		
		
	}
	public function view_product()
	{
		$data['cms_footer']=$this->contact->get_info_footer();
		$this->load->model('category_model','cm');
		$data['category']=$this->cm->get_category_page();
		if(is_array($data['category']))
		{
			foreach($data['category'] as $value)
			{
				$productside[$value->category_id]=$this->cm->product_list($value->category_id);
			}
		}
		else
		{
			$productside=array();
		}
		$data['productside']=$productside;
		$this->load->model('news_model','pm');
		$data['news']=$this->pm->get_news_page();
		$this->load->model('product/product_model');
		$data['num_rows']=$this->pm->get_product_row();
		
		$config['base_url'] = site_url().'/product/product_view_all/view_product/';
		$config['total_rows'] = $data['num_rows'];
		$config['per_page'] = $data['per_page']= 6;
		$config['num_links'] = 6;
		$config['uri_segment'] = 3;
		$config['full_tag_open'] = '<p>';
		$config['full_tag_close'] = '</p>';
		$config['cur_tag_open'] = '<a><b><u>';
		$config['cur_tag_close'] = '</u></b></a>';
		$this->pagination->initialize($config);
		$data['product']=$this->pm->get_product_page($config['per_page'], $this->uri->segment(3));
		$data['link']=$this->pagination->create_links();
		$data['title']="";
		$data['page']='pages/product_view_all';
		$this->load->view('templates/content',$data);
	}
	public function view($id=FALSE)
	{
		$data['cms_footer']=$this->contact->get_info_footer();
		if($id)
		{
			$data['product_item'] = $this->pm->get_product($id);
			
			$data['title'] = "Products";
			if (empty($data['product_item']))
			{
				redirect('pagenotfound');
			}
			$this->load->model('category_model','cm');
			$this->load->model('product_view_model','pm');
			$this->load->model('product/product_model');
			$this->load->model('news_model','pm');
			$data['news']=$this->pm->get_news_page();
			//$data['product']=$this->product_model->get_product_page();
			$data['product_new']=$this->product_model->get_new_product();
			
			$data['category']=$this->cm->get_category_page();

			if(is_array($data['category']))
			{
				foreach($data['category'] as $value)
				{
					$productside[$value->category_id]=$this->cm->product_list($value->category_id);
				}
			}
			else
			{
				$productside=array();
			}
		$data['productside']=$productside;
			$data['category_nm']=$this->pm->get_category_name($id);
			$data['page']='pages/mens';
			$this->load->view('templates/content',$data);  
		}
		else
		{
			redirect('pagenotfound');
		}
	}
	public function products_summery()
	{
		$data['cms_footer']=$this->contact->get_info_footer();
		$this->load->model('category_model','cm');
		$data['category']=$this->cm->get_category_page();
		$data['category_p']=$this->cm->get_category();

		if(is_array($data['category']))
		{
			foreach($data['category'] as $value)
			{
				$productside[$value->category_id]=$this->cm->product_list($value->category_id);
			}
		}
		else
		{
			$productside=array();
		}
		$data['productside']=$productside;
		$this->load->model('news_model','pm');
		$data['news']=$this->pm->get_news_page();
		$data['title']="Products";
		$data['page']="pages/product_summary";
		$this->load->view('template/content',$data);
	}
	public function products_detail($id=FALSE,$c_id=FALSE)
	{
		
		$data['cms_footer']=$this->contact->get_info_footer();
			 
			$data['products'] = $this->sm->retrieve_products($id,$c_id); 
			$data['category_p']=$this->cm->get_category();
			$data['category_products']=$this->sm->category_product($c_id);
			$data['product_image']=$this->sm->get_product_photos($id);
			$data['category']=$this->cm->get_category_page();
			if(is_array($data['category']))
			{
				foreach($data['category'] as $value)
				{
					$productside[$value->category_id]=$this->cm->product_list($value->category_id);
				}
			}
			else
			{
				$productside=array();
			}
		$data['productside']=$productside;
			$this->load->model('news_model','pm');
			$data['news']=$this->pm->get_news_page();
			if(empty($data['products']))
			{
				redirect('pagenotfound');
			}
			
			//$data['category_nm']=$this->cm->get_category_name($id);
			$data['content'] = 'pages/single';
			
			$data['title']="Products";
			$data['page']="pages/product_details";
			$this->load->view('template/content',$data);
		
	}
}
?>