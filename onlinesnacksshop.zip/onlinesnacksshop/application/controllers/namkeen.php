<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class namkeen extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->model('namkeen_model');
		$this->load->library('form_validation');
		$this->load->model('category_model','cm');
		$this->load->model('news_model','pm');
		$this->load->model('contact_model','contact');
	}

	public function index()
	{
		
		$data['news']=$this->pm->get_news_page();
		$this->load->model('category_model','cm');
		
		$data['cms_footer']=$this->contact->get_info_footer();
		$data['category_p']=$this->cm->get_category();
		$data['category']=$this->cm->get_category_page();
		if(is_array($data['category']))
		{
			foreach($data['category'] as $value)
			{
				$productside[$value->category_id]=$this->cm->product_list($value->category_id);
			}
		}
		else
		{
			$productside=array();
		}
		$data['productside']=$productside;
		$this->load->model('namkeen_model');
		
		$data['namkeen']=$this->namkeen_model->get_namkeen_all();
		
		//$data['product_new']=$this->namkeen_model->get_new_product();
		$data['title']="Products";
		//$data['banner']=$this->namkeen_model->get_banner_page();
		$data['page']="pages/namkeen";
		$this->load->view('template/content',$data);
		
		
	}
	public function view_product()
	{
		$this->load->model('category_model','cm');
		$data['category']=$this->cm->get_category_page();
		$data['cms_footer']=$this->contact->get_info_footer();
		if(is_array($data['category']))
		{
			foreach($data['category'] as $value)
			{
				$productside[$value->category_id]=$this->cm->product_list($value->category_id);
			}
		}
		else
		{
			$productside=array();
		}
		$data['productside']=$productside;
		$this->load->model('news_model','pm');
		$data['news']=$this->pm->get_news_page();
		$this->load->model('product/product_model');
		$data['num_rows']=$this->pm->get_product_row();
		$this->load->library('pagination');
		$config['base_url'] = site_url().'/product/product_view_all/view_product/';
		$config['total_rows'] = $data['num_rows'];
		$config['per_page'] = $data['per_page']= 6;
		$config['num_links'] = 6;
		$config['uri_segment'] = 3;
		$config['full_tag_open'] = '<p>';
		$config['full_tag_close'] = '</p>';
		$config['cur_tag_open'] = '<a><b><u>';
		$config['cur_tag_close'] = '</u></b></a>';
		$this->pagination->initialize($config);
		$data['product']=$this->pm->get_product_page($config['per_page'], $this->uri->segment(3));
		$data['link']=$this->pagination->create_links();
		$data['title']="";
		$data['page']='pages/product_view_all';
		$this->load->view('templates/content',$data);
	}
	public function view($id=FALSE)
	{
		if($id)
		{
			$data['product_item'] = $this->pm->get_product($id);
			
			$data['title'] = "Products";
			if (empty($data['product_item']))
			{
				redirect('pagenotfound');
			}
			$this->load->model('category_model','cm');
			$this->load->model('product_view_model','pm');
			$this->load->model('product/product_model');
			$this->load->model('news_model','pm');
			$data['news']=$this->pm->get_news_page();
			//$data['product']=$this->product_model->get_product_page();
			$data['product_new']=$this->product_model->get_new_product();
			
			$data['category']=$this->cm->get_category_page();
			$data['cms_footer']=$this->contact->get_info_footer();
			if(is_array($data['category']))
			{
				foreach($data['category'] as $value)
				{
					$productside[$value->category_id]=$this->cm->product_list($value->category_id);
				}
			}
			else
			{
				$productside=array();
			}
		$data['productside']=$productside;
			$data['category_nm']=$this->pm->get_category_name($id);
			$data['page']='pages/mens';
			$this->load->view('templates/content',$data);  
		}
		else
		{
			redirect('pagenotfound');
		}
	}
	public function products_summery()
	{
		$this->load->model('category_model','cm');
		$data['category']=$this->cm->get_category_page();
		$data['category_p']=$this->cm->get_category();
		$data['cms_footer']=$this->contact->get_info_footer();
		if(is_array($data['category']))
		{
			foreach($data['category'] as $value)
			{
				$productside[$value->category_id]=$this->cm->product_list($value->category_id);
			}
		}
		else
		{
			$productside=array();
		}
		$data['productside']=$productside;
		$this->load->model('news_model','pm');
		$data['news']=$this->pm->get_news_page();
		$data['title']="Products";
		$data['page']="pages/product_summary";
		$this->load->view('template/content',$data);
	}
	public function namkeen_detail($id=FALSE)
	{
		
		$this->session->set_userdata('lasturl',$this->uri->uri_string());
			 $this->load->model('namkeen_model','sm');
			 $this->load->model('category_model','cm');
			$data['namkeen'] = $this->sm->retrieve_products($id); 
			$data['category_p']=$this->cm->get_category();
			//$data['category_products']=$this->sm->category_product($c_id);
			$data['namkeen_image']=$this->sm->get_namkeen_photos($id);
			$data['category']=$this->cm->get_category_page();
			$data['cms_footer']=$this->contact->get_info_footer();
			if(is_array($data['category']))
			{
				foreach($data['category'] as $value)
				{
					$productside[$value->category_id]=$this->cm->product_list($value->category_id);
				}
			}
			else
			{
				$productside=array();
			}
		$data['productside']=$productside;
			$this->load->model('news_model','pm');
			$data['news']=$this->pm->get_news_page();
			if(empty($data['namkeen']))
			{
				redirect('pagenotfound');
			}
			
			//$data['category_nm']=$this->cm->get_category_name($id);
			$data['content'] = 'pages/single';
			
			$data['title']="Products";
			$data['page']="pages/namkeen_details";
			$this->load->view('template/content',$data);
		
	}
}
?>