<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Reg extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();
		if($this->session->userdata('is_logged_in')==TRUE)
		{
			redirect('home');
		}
		$this->load->model('category_model','cm');
		$this->load->model('news_model','pm');
		$this->load->model('contact_model','contact');
	}
	public function index()
	{
		
		$data['category']=$this->cm->get_category_page();
		$data['cms_footer']=$this->contact->get_info_footer();
		if(is_array($data['category']))
		{
			foreach($data['category'] as $value)
			{
				$productside[$value->category_id]=$this->cm->product_list($value->category_id);
			}
		}
		else
		{
			$productside=array();
		}
		$data['productside']=$productside;
		
		$data['news']=$this->pm->get_news_page();
		$data['title']="Welcome To Website";
		$data['page']="pages/register";
		$this->load->view('template/content',$data);
	}
	public function signup()
	{
		$this->load->model('category_model','cm');
		$data['category']=$this->cm->get_category_page();
		if(is_array($data['category']))
		{
			foreach($data['category'] as $value)
			{
				$productside[$value->category_id]=$this->cm->product_list($value->category_id);
			}
		}
		else
		{
			$productside=array();
		}
		$data['productside']=$productside;
		$this->load->model('news_model','pm');
		$data['news']=$this->pm->get_news_page();
    	 $this->load->library('form_validation');
	     $this->form_validation->set_rules('txtfnm', 'FirstName', 'required|trim|min_length[2]|max_length[20]|alpha');
		 $this->form_validation->set_rules('txtlnm', 'LastName', 'required|trim|min_length[2]|max_length[20]|alpha');
	     $this->form_validation->set_rules('txtusernm', 'Username', 'required|trim|min_length[5]|max_length[20]|alpha_dash|is_unique[customer.customer_username]');
	     $this->form_validation->set_rules('txtmobile', 'Mobile No', 'required|trim|min_length[10]|max_length[10]|is_natural_no_zero|is_unique[customer.customer_mobile]');
	     $this->form_validation->set_rules('txtemail', 'Email', 'valid_email|is_unique[customer.customer_email]');
	     $this->form_validation->set_rules('txtpwd', 'Password', 'required|trim|min_length[5]|max_length[20]');
	     $this->form_validation->set_rules('txtcpwd', 'Confirm Password', 'matches[txtpwd]|required|trim|min_length[5]|max_length[20]');
		 $this->form_validation->set_rules('txtadd', 'Address', 'required|trim|min_length[5]|max_length[100]');
	    if ($this->form_validation->run() == FALSE)
        {
				$data['title']='Signin Page';
				$data['page']="pages/register";
				$this->load->view('template/content',$data);
			
        }
    
        else
        {
        	
          $data = array('customer_fname' => $this->input->post('txtfnm'),
		  			'customer_lname' => $this->input->post('txtlnm'),
					'customer_username' => $this->input->post('txtusernm'),	
					'customer_mobile ' => $this->input->post('txtmobile'),
					'customer_email' => $this->input->post('txtemail'),
					'customer_password' => md5($this->input->post('txtpwd')),
					'customer_type' => 'user',
					'customer_address' => $this->input->post('txtadd'),
					'customer_created'=> $created= date('Y-m-d H:i:s')
					
			);

            $this->load->model('customer_model','customer');
			$result=$this->customer->add_cust($data);	
		       if($result)
		       {
		       		$this->session->set_userdata('cust_add',"Registration Successfully...");
		       		redirect('reg');
		       }
		       else
		       {
					$data['title']='Signin Page';
					$data['page']="pages/register";
					$this->load->view('template/content',$data);	
		       }
        }    
	}
}
?>