<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Checkout extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();
		
		$this->load->model('cart_model');
		if($this->session->userdata('is_logged_in')==FALSE)
		{
			redirect('cart');
		}
		$this->load->model('news_model','pm');
		$this->load->model('category_model','cm');
		$this->load->library('cart');
		
		
		
	}
	
	public function index()
	{
		
		$data['category']=$this->cm->get_category_page();
		$data['cms_footer']=$this->cm->get_info_footer();
		if(is_array($data['category']))
		{
			foreach($data['category'] as $value)
			{
				$productside[$value->category_id]=$this->cm->product_list($value->category_id);
			}
		}
		else
		{
			$productside=array();
		}
		$data['productside']=$productside;
		$data['category_p']=$this->cm->get_category();
		$insert_room = array(
		'id' => $this->input->post('product_id'),
		'name' =>$this->input->post('product_title'),
		'desc'=>$this->input->post('product_desc'),
		'price' => $this->input->post('product_price'),
		'img'=>$this->input->post('product_img'),
		'qty' => 1
		);		
		$this->cart->insert($insert_room);

		
		$cart = array(
		'product_id' => $this->input->post('id'),
		'product_name' =>$this->input->post('name'),
		//'desc'=>$this->input->post('desc'),
		'product_price' => $this->input->post('price'),
		'img'=>$this->input->post('img'),
		'quantity' => $this->input->post('qty'),
		'total'=>$this->input->post('total')
		);
		$this->session->set_userdata('cart',$cart);
		$cart=$this->session->userdata('cart');
		$this->load->model('category_model','cm');
		$data['category']=$this->cm->get_category_page();
		$data['category_p']=$this->cm->get_category();
		
		$data['news']=$this->pm->get_news_page();
		$data['title']="Shopping Cart";
		$data['page']="pages/steps/checkout";
		$this->load->view('template/content',$data);
		
	}
	public function shipping()
	{
		$this->load->model('category_model','cm');
		$data['category']=$this->cm->get_category_page();
		$data['cms_footer']=$this->contact->get_info_footer();
		if(is_array($data['category']))
		{
			foreach($data['category'] as $value)
			{
				$productside[$value->category_id]=$this->cm->product_list($value->category_id);
			}
		}
		else
		{
			$productside=array();
		}
		$data['productside']=$productside;
		$data['category_p']=$this->cm->get_category();	
		$this->load->model('category_model','cm');
		$data['category']=$this->cm->get_category_page();
		$data['category_p']=$this->cm->get_category();
		$this->load->model('news_model','pm');
		$data['news']=$this->pm->get_news_page();
		$data['title']="Shopping Cart";
		$data['page']="pages/steps/shipping";
		$this->load->view('template/content',$data);
	}
	public function add_address()
	{
		$this->load->model('category_model','cm');
		$data['category']=$this->cm->get_category_page();
		$data['cms_footer']=$this->cm->get_info_footer();
		if(is_array($data['category']))
		{
			foreach($data['category'] as $value)
			{
				$productside[$value->category_id]=$this->cm->product_list($value->category_id);
			}
		}
		else
		{
			$productside=array();
		}
		$data['productside']=$productside;
		$data['category_p']=$this->cm->get_category();
		$this->load->model('category_model','cm');
		$data['category']=$this->cm->get_category_page();
		$data['category_p']=$this->cm->get_category();
		$this->load->model('news_model','pm');
		$data['news']=$this->pm->get_news_page();
		
		$this->form_validation->set_rules('txtfnm', 'FirstName', 'required|trim|min_length[2]|max_length[20]|alpha');
		 $this->form_validation->set_rules('txtlnm', 'LastName', 'required|trim|min_length[2]|max_length[20]|alpha');
		 $this->form_validation->set_rules('txtemail', 'Email', 'valid_email');
		 $this->form_validation->set_rules('txtmobile', 'Mobile No', 'required|trim|min_length[10]|max_length[10]|is_natural_no_zero');
		 $this->form_validation->set_rules('txtcity', 'City', 'required|trim|min_length[2]|max_length[20]|alpha');
		  $this->form_validation->set_rules('txtadd', 'Address', 'required|trim|min_length[5]|max_length[1000]');
		   $this->form_validation->set_rules('txtzipcode', 'Zipcode', 'required|trim|min_length[6]|max_length[6]|is_natural_no_zero');
		if ($this->form_validation->run() == FALSE)
		{
			$data['title']='Shopping Cart';
			$data['page']="pages/steps/checkout";
			$this->load->view('template/content',$data);
		
		}
		else
		{
	
			$address_array=array
			(
				'first_name'=>$this->input->post('txtfnm'),
				'last_name'=>$this->input->post('txtlnm'),
				'email'=>$this->input->post('txtemail'),
				'mobile'=>$this->input->post('txtmobile'),
				'address1'=>$this->input->post('txtadd'),
				'address2'=>$this->input->post('txtadd2'),
				'city'=>$this->input->post('txtcity'),
				'zipcode'=>$this->input->post('txtzipcode')
			);
			$this->session->set_userdata($address_array);
			$this->session->set_userdata('address_array',$address_array);
			$add=$this->session->userdata('address_array');
			$s_data=array
			(
				'ship_firstname'=>$this->input->post('txtfnm'),
				'ship_lastname'=>$this->input->post('txtlnm'),
				'ship_email'=>$this->input->post('txtemail'),
				'ship_phone'=>$this->input->post('txtmobile'),
				'ship_address1'=>$this->input->post('txtadd'),
				'ship_address2'=>$this->input->post('txtadd2'),
				'ship_city'=>$this->input->post('txtcity'),
				'ship_zip'=>$this->input->post('txtzipcode')
			);
			$this->session->set_userdata($s_data);
			$this->session->set_userdata('s_data',$s_data);
			$s_data=$this->session->userdata('s_data');
			$data['title']="Shopping Cart";
			$chk=$this->input->post('ship');
			if($chk)
			{
				$data['page']="pages/steps/checkout_step2";
				$this->load->view('template/content',$data);
			}
			else
			{
				$data['page']='pages/steps/shipping';
				$this->load->view('template/content',$data);
			}
		}
		
		
	}
	public function ship_address()
	{
		$this->load->model('category_model','cm');
		$data['category']=$this->cm->get_category_page();
		$data['cms_footer']=$this->cm->get_info_footer();
		$data['category_p']=$this->cm->get_category();
		$this->load->model('news_model','pm');
		$data['news']=$this->pm->get_news_page();
		$this->form_validation->set_rules('shipfnm', 'FirstName', 'required|trim|min_length[2]|max_length[20]|alpha');
		 $this->form_validation->set_rules('shiplnm', 'LastName', 'required|trim|min_length[2]|max_length[20]|alpha');
		 $this->form_validation->set_rules('shipemail', 'Email', 'valid_email');
		 $this->form_validation->set_rules('shipmobile', 'Mobile No', 'required|trim|min_length[10]|max_length[10]|is_natural_no_zero');
		 $this->form_validation->set_rules('shipcity', 'City', 'required|trim|min_length[2]|max_length[20]|alpha');
		  $this->form_validation->set_rules('shipadd', 'Address', 'required|trim|min_length[5]|max_length[1000]');
		   $this->form_validation->set_rules('shipzipcode', 'Zipcode', 'required|trim|min_length[6]|max_length[6]|is_natural_no_zero');
		if ($this->form_validation->run() == FALSE)
		{
			$data['title']='Shopping Cart';
			$data['page']="pages/steps/shipping";
			$this->load->view('template/content',$data);
		
		}
		else
		{
	
			$s_data=array
			(
				'ship_firstname'=>$this->input->post('shipfnm'),
				'ship_lastname'=>$this->input->post('shiplnm'),
				'ship_email'=>$this->input->post('shipemail'),
				'ship_phone'=>$this->input->post('shipmobile'),
				'ship_address1'=>$this->input->post('shipadd'),
				'ship_address2'=>$this->input->post('shipadd2'),
				'ship_city'=>$this->input->post('shipcity'),
				'ship_zip'=>$this->input->post('shipzipcode')
			);
			$this->session->set_userdata($s_data);
			$this->session->set_userdata('s_data',$s_data);
			$s_data=$this->session->userdata('s_data');
			$data['page']="pages/steps/checkout_step2";
			$this->load->view('template/content',$data);
		}
	}
	public function add_record()
	{
	
		$name=$this->session->userdata('username');
		$res=$this->cart_model->Customer_id($name);
		$order_no=random_string('numeric');
		$i=1;
		foreach ($this->cart->contents() as $items)
		{
			$res=$this->cart_model->Customer_id($name);
			$this->session->set_userdata('customer_id',$res->customer_id);	
			$data=array
			(
				'order_number'=>$order_no,
				'product_id'=>$items['id'],
				'customer_id'=>$res->customer_id,
				'customer_name'=>$this->session->userdata('username'),
				'quantity'=>$items['qty'],
				'product_price'=>$items['price'],
				'product_name'=>$items['name'],
				//'product_desc'=>$items['desc'],
				'img'=>$items['img'],
				'total'=>$items['subtotal']
			);
			$this->cart_model->insert_cart_order($data);
			$i++;	
		}
		$add=$this->session->userdata('address_array');
		$s_data=$this->session->userdata('s_data');
		if($s_data)
		{
			foreach($s_data as $s)
			{
				$arr[]=$s;	
			}
		}
		else
		{
			redirect('cart');
		}
		if($add)
		{
			foreach($add as $a)
			{
				$arr[]=$a;	
			}
		}
		else
		{
			redirect('cart');
		}
		$c_id=$this->session->userdata('c_id');
		//$order_no=random_string('numeric');
		$this->session->set_userdata('order_no',$order_no);
		$odr_id=$this->session->userdata('order_no');
		$gtotal=$this->session->userdata('gtotal');
		$s_charge=$this->session->userdata('d_charg');
		if($gtotal>999)
		{
			$s_charge=0;
		}
		$date=date('Y-m-d H:i:s');
		$details= array(
		'order_number'=>$order_no,
		'customer_id'=>$c_id,
		'ordered_on'=>$date,
		'shipped_on'=>$date,
		'g_total'=>$gtotal,
		'shipping'=>$s_charge,
		'ship_firstname'=>$arr['0'],
		'ship_lastname'=>$arr['1'],
		'ship_email'=>$arr['2'],
		'ship_phone'=>$arr['3'],
		'ship_address1'=>$arr['4'],
		'ship_address2'=>$arr['5'],
		'ship_city'=>$arr['6'],
		'ship_zip'=>$arr['7'],
		'bill_firstname'=>$arr['8'],
		'bill_lastname'=>$arr['9'],
		'bill_email'=>$arr['10'],
		'bill_phone'=>$arr['11'],
		'bill_address1'=>$arr['12'],
		'bill_address2'=>$arr['13'],
		'bill_city'=>$arr['14'],
		'bill_zip'=>$arr['15']
		);
		$this->load->model('steps/checkout_model','chkm');
		$result=$this->chkm->add_order($details);	
		if($result)
		{
			/*
			'protocol' => 'smtp',
			  'smtp_host' => 'ssl://smtp.googlemail.com',
			  'smtp_port' => 465,
			  'smtp_user' => 'sarfarajkazi7@gmail.com', // change it to yours
			  'smtp_pass' => '9033200540', // change it to yours
			*/
			$config = Array(
			  'mailtype' => 'html',
			  'charset' => 'iso-8859-1',
			  'wordwrap' => TRUE
			);
				  $this->load->library('email', $config);
			  $this->email->set_newline("\r\n");
			   $this->email->from('info@pragnyafoodproducts.com','Pragnyafoodproducts'); // change it to yours
			  $this->email->to($this->session->userdata('c_email'));// change it to yours
			  $this->email->subject("Order Has Placed");
			  	
   			    $s_fname=$arr['0'];
				$s_lname=$arr['1'];
				$s_email=$arr['2'];
				$s_mobile=$arr['3'];
				$s_address=$arr['4'];
				$s_address2=$arr['5'];
				$s_city=$arr['6'];
				$s_zip=$arr['7'];
				$url=base_url();
				$fname=$this->session->userdata('fname');
				$lname=$this->session->userdata('lname');
				
				$msg='<div style="margin:0;font:12px/16px Arial,sans-serif"> 
  <table style="width:640px;color:rgb(51,51,51);margin:0 auto;border-collapse:collapse"> 
   <tbody>
    <tr> 
     <td style="padding:0 20px 20px 20px;vertical-align:top;font-size:13px;line-height:18px;font-family:Arial,sans-serif"> 
      <table  style="width:100%;border-collapse:collapse"> 
       <tbody>
        <tr> 
         <td style="vertical-align:top;font-size:13px;line-height:18px;font-family:Arial,sans-serif"> 
          <table  style="width:100%;border-collapse:collapse"> 
           <tbody>
            <tr> 
             <td rowspan="2" style="width:115px;padding:20px 20px 0 0;vertical-align:top;font-size:13px;line-height:18px;font-family:Arial,sans-serif"> <a href='."$url".' target="_blank" style="text-decoration:none;"> <h2 style="width:220px">Pragnya Food Products</h2> </a> </td> 
           
             <td style="text-align:right;padding:5px 0;border-bottom:1px solid rgb(204,204,204);white-space:nowrap;vertical-align:top;font-size:13px;line-height:18px;font-family:Arial,sans-serif"> <span style="text-decoration:none;color:rgb(204,204,204);font-size:15px;font-family:Arial,sans-serif">&nbsp;&nbsp;</span>   </td>  
            </tr> 
            <tr> 
             <td colspan="3" style="text-align:right;padding:7px 0 5px 0;vertical-align:top;font-size:13px;line-height:18px;font-family:Arial,sans-serif"> <h2 style="font-size:20px;line-height:24px;margin:0;padding:0;font-weight:normal;color:rgb(0,0,0)!important">Order Confirmation</h2> Order # '."$order_no".' <br> </td> 
            </tr> 
           </tbody>
          </table> </td> 
        </tr> 
        <tr> 
         <td style="vertical-align:top;font-size:13px;line-height:18px;font-family:Arial,sans-serif"> 
          <table style="width:100%;border-collapse:collapse"> 
           <tbody>
            <tr> 
             <td style="vertical-align:top;font-size:13px;line-height:18px;font-family:Arial,sans-serif"> <h3 style="font-size:18px;color:rgb(204,102,0);margin:15px 0 0 0;font-weight:normal">Hello '."$fname $lname".',</h3><br> <p style="margin:1px 0 8px 0;font:12px/16px Arial,sans-serif"> Thank you for your order. This e-mail confirms that your order has been received by us. If we are not able to process your payment, we will save your order and send you an e-mail with an option to retry payment. </p><p style="margin:1px 0 8px 0;font:12px/16px Arial,sans-serif">If you would like to view the status of your order or make any changes to it, please visit Your Orders on <a href='."$url".' style="text-decoration:none;color:rgb(0,102,153);font:12px/16px Arial,sans-serif" target="_blank">Pragnya Food Products</a> </p> </td> 
            </tr>
            <tr> 
             <td style="vertical-align:top;font-size:13px;line-height:18px;font-family:Arial,sans-serif"> </td> 
            </tr> 
           </tbody>
          </table> </td> 
        </tr> 
        <tr> 
         <td style="vertical-align:top;font-size:13px;line-height:18px;font-family:Arial,sans-serif"> 
          <table style="border-collapse:collapse"> 
          </table> </td> 
        </tr> 
        <tr> 
         <td style="vertical-align:top;font-size:13px;line-height:18px;font-family:Arial,sans-serif"> 
          <table style="width:100%;border-top:3px solid rgb(45,55,65);border-collapse:collapse"> 
           <tbody>
            <tr> 
             <td style="font-size:14px;padding:11px 18px 18px 18px;background-color:rgb(239,239,239);width:50%;vertical-align:top;line-height:18px;font-family:Arial,sans-serif"> <p style="margin:2px 0 9px 0;font:14px Arial,sans-serif"> <span style="font-size:14px;color:rgb(102,102,102)">	<p style="margin:2px 0 9px 0;font:14px Arial,sans-serif"> <span style="font-size:14px;color:rgb(102,102,102)">Your shipping speed:</span> <br> <b> 2-4 Business Days  </b> </p> </td> 
             <td style="font-size:14px;padding:11px 18px 18px 18px;background-color:rgb(239,239,239);width:50%;vertical-align:top;line-height:18px;font-family:Arial,sans-serif"> <p style="margin:2px 0 9px 0;font:14px Arial,sans-serif"> <span style="font-size:14px;color:rgb(102,102,102)">Your order will be sent to:</span> <br> <b> '."$fname $lname,".' <br> '."$s_address,<br>$s_address2".' <br> Mobile No : '."$s_mobile".'  <br> Email : '."$s_email".' </b> </p> </td> 
            </tr> 
           </tbody>
          </table> </td> 
        </tr> 
        
        <tr> 
         <td style="vertical-align:top;font-size:13px;line-height:18px;font-family:Arial,sans-serif"> 
          <table style="width:100%;margin:20px 0 0 0;border-collapse:collapse"> 
           <tbody>
            <tr> 
             <td style="vertical-align:top;font-size:13px;line-height:18px;font-family:Arial,sans-serif"> <p style="font-size:10px;color:rgb(102,102,102);line-height:16px;margin:0 0 10px 0;font:10px"> This email was sent from a notification-only address that cannot accept incoming email. Please do not reply to this message. </p> </td> 
            </tr> 
            <tr>  
            </tr> 
           </tbody>
          </table> </td> 
        </tr> 
       </tbody>
      </table> 
     </td></tr></tbody></table></div>';
			  $this->email->message($msg);
			  $this->email->send();
			$this->session->set_userdata('complete',"Your Order Complete Sucessfully");

			/*$this->load->model('fpdf');
			$this->fpdf->AddPage();
			$img=base_url('images/logo.png');
			$this->fpdf->Image($img,150,0,40,30,'PNG');
			$this->fpdf->cell(0,10,"","",1,'C');
			$this->fpdf->cell(0,10,"","",1,'C');
			$this->fpdf->SetFont('Arial','B',30);
			$this->fpdf->cell(88,20,"Pragnya Food Product",'','','L');
			$this->fpdf->SetFont('Arial','B',10);
			$this->fpdf->cell(0,10,"","",1,'C');
			$this->fpdf->cell(50,20,"Tel: 9377712229",'','','L');
			$this->fpdf->cell(0,10,"","",1,'C');
			$this->fpdf->SetFont('Arial','B',10);
			$this->fpdf->cell(50,20,"Order No:-".$order_no,'','','L');
			$this->fpdf->cell(0,10,"","",1,'C');
			$this->fpdf->SetFont('Arial','B',10);
			$this->fpdf->cell(50,20,"Date : ".date('Y/m/d'),'','','L');
			$this->fpdf->cell(0,10,"","",1,'C');
			$this->fpdf->cell(50,20,"First Name:- ".$arr['0'],'','','L');
			$this->fpdf->cell(50,20,"Last Name:- ".$arr['1'],'','','L');
			$this->fpdf->cell(0,10,"","",1,'C');
			$this->fpdf->cell(50,20,"Your Email:- ".$arr['2'],'','','L');
			$this->fpdf->cell(0,10,"","",1,'C');
			$this->fpdf->cell(50,20,"Your Mobile.No :- ".$arr['3'],'','','L');
			$this->fpdf->cell(0,10,"","",1,'C');
			$this->fpdf->cell(50,20,"Address :- ".$arr['4'],'','','L');
			$this->fpdf->cell(0,10,"","",1,'C');
			$this->fpdf->cell(0,10,"","",1,'C');
			//
			$this->fpdf->SetFont('Arial','B',8);
			
			$this->fpdf->Cell(30,8,"Product Name",1,'','C');
			$this->fpdf->Cell(30,8,"Product Image",1,'','C');
			$this->fpdf->Cell(40,8,"Product Quantity",1,'','C');
			$this->fpdf->Cell(30,8,"Price",1,'','C');
			$this->fpdf->Cell(30,8,"SubTotal Amount",1,1,'C');
			$this->fpdf->SetFillColor(220,220,220);
	    	$this->fpdf->SetFont('');
			$fill = false;
			$grand_total=0;
			foreach ($this->cart->contents() as $items)
			{

				$this->fpdf->Cell(30,8,ucfirst($items['name']),'LR',0,'C',$fill);
				//$this->fpdf->Image();
				$this->fpdf->Cell(30,8,ucfirst($items['name']),'LR',0,'C',$fill);
				$this->fpdf->Cell(40,8,number_format($items['qty']),'LR',0,'C',$fill);
				$this->fpdf->Cell(30,8,number_format($items['price']),'LR',0,'C',$fill);
				$this->fpdf->Cell(30,8,number_format($items['subtotal']),'LR',0,'C',$fill);
				$this->fpdf->Ln();
				$fill = !$fill;
				$grand_total = $grand_total + $items['subtotal'];
			}
		//
			$this->fpdf->Cell(160,0,"",1,1,'C');
			$this->fpdf->SetFont('Arial','B',8);		
			$this->fpdf->cell(30,20,"Total Amount : ".$grand_total,'','','L');
			$this->fpdf->Output();	*/
		
			$this->load->model('category_model','cm');
			$data['category']=$this->cm->get_category_page();
			$data['category_p']=$this->cm->get_category();
			$data['billing_info']=$this->chkm->get_billing_info($c_id);
			$this->load->model('news_model','pm');
			$data['news']=$this->pm->get_news_page();
			$this->chkm->cart_delete($c_id);
			$this->cart->destroy();
			$this->session->unset_userdata('d_charg');
			$this->session->unset_userdata('count');
			$this->session->unset_userdata('grndtotal');
			$this->session->unset_userdata('address_array');
			$this->session->unset_userdata('s_data');
			$this->session->unset_userdata('cart');
			$this->session->unset_userdata('first_name');
			$this->session->unset_userdata('last_name');
			$this->session->unset_userdata('email');
			$this->session->unset_userdata('mobile');
			$this->session->unset_userdata('address1');
			$this->session->unset_userdata('address2');
			$this->session->unset_userdata('city');
			$this->session->unset_userdata('zipcode');
			$this->session->unset_userdata('ship_firstname');
			$this->session->unset_userdata('ship_lastname');
			$this->session->unset_userdata('ship_email');
			$this->session->unset_userdata('ship_phone');
			$this->session->unset_userdata('ship_address1');
			$this->session->unset_userdata('ship_address2');
			$this->session->unset_userdata('ship_city');
			$this->session->unset_userdata('ship_zip');
			redirect('profile/order_information/'.$odr_id);
		}
		
	}
}
?>