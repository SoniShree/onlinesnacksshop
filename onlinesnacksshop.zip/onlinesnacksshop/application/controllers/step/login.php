<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Login extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();
		if($this->session->userdata('is_logged_in')==TRUE)
		{
			redirect('cart');
		}
	}
	public function index()
	{
		$this->load->model('category_model','cm');
		$data['category']=$this->cm->get_category_page();
		$data['category_p']=$this->cm->get_category();
		$this->load->model('news_model','pm');
		$data['news']=$this->pm->get_news_page();
		if($this->session->userdata('is_logged_in')==FALSE)
		{
			$data['title']="Login Page";
			$data['page']="pages/login";
			$this->load->view('template/content',$data);
		}
		else
		{
			redirect('cart');
		}
		
		
	}
	public function validate_form()
	{
		$this->load->model('login_model','user');
		$this->load->model('news_model','pm');
		$data['news']=$this->pm->get_news_page();
		$this->load->model('category_model','cm');
		$data['category']=$this->cm->get_category_page();
		$data['category_p']=$this->cm->get_category();
		$this->form_validation->set_rules('username', 'Username', 'required|trim|min_length[4]|max_length[10]');
		$this->form_validation->set_rules('password', 'Password', 'required|trim|min_length[6]|max_length[15]');
	    if ($this->form_validation->run() == TRUE)
        {
		   $result = $this->user->login();
		   if($result==TRUE)
		   {
				$ndata=array('username' => $this->input->post('username') , 'is_logged_in' => TRUE );
				$this->session->set_userdata($ndata);
				redirect('cart');
			}
		   else
		   {
		
			$this->session->set_userdata('err','Username Or Password Missmatch...');
			$data['title']="Login Page";
			$data['page']="pages/login";
			$this->load->view('template/content',$data);
		   }
		}
		else
		{
			
		$data['title']="Login Page";
		$data['page']="pages/login";
		$this->load->view('template/content',$data);
		}
		
		
	}
}
?>