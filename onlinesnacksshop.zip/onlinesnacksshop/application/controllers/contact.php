<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Contact extends CI_Controller
{
	public function index()
	{
		$this->load->model('category_model','cm');
		$this->load->model('news_model','pm');
		$this->load->model('contact_model','contact');
		$data['category']=$this->cm->get_category_page();
		$data['cms_footer']=$this->contact->get_info_footer();
		if(is_array($data['category']))
		{
			foreach($data['category'] as $value)
			{
				$productside[$value->category_id]=$this->cm->product_list($value->category_id);
			}
		}
		else
		{
			$productside=array();
		}
		$data['productside']=$productside;
		
		$data['news']=$this->pm->get_news_page();
		 $this->load->library('form_validation');
	     $this->form_validation->set_rules('txtfnm', 'FirstName', 'required|trim|min_length[2]|max_length[20]|alpha');
	     $this->form_validation->set_rules('txtemail', 'Email', 'valid_email');
	     $this->form_validation->set_rules('txtmobile', 'Mobile No', 'required|min_length[10]|max_length[10]');
	     $this->form_validation->set_rules('txtlnm', 'LastName','required|trim|min_length[2]|max_length[20]|alpha');
	     $this->form_validation->set_rules('txtmsg', 'Message','required');
		
		if ($this->form_validation->run() == FALSE)
        {
			 $data['cms']=$this->contact->get_info();
				$data['title']="Contact Us Page";
				$data['page']="pages/contact";
				$this->load->view('template/content',$data);
					
        }
    
        else
        {
        	 $created= date('Y-m-d H:i:s');
          $data = array('contact_fname' => $this->input->post('txtfnm'),
					'contact_mobile ' => $this->input->post('txtmobile'),
					'contact_email' => $this->input->post('txtemail'),
					'contact_lname' =>  $this->input->post('txtlnm'),
					'contact_message' => $this->input->post('txtmsg'),
					'created'=>$created					
			);
    		
			$result=$this->contact->add_cust($data);	
		       if($result)
		       {
		       		$this->session->set_userdata('contact_add',"Thank's For Your Feedback...");
		       		redirect('contact');
		       }
		       else
		       {
		       		$data['title']="Contact Us Page";
					$data['page']="pages/contact";
					$this->load->view('template/content',$data);
		       }
        }    
	}
}
?>