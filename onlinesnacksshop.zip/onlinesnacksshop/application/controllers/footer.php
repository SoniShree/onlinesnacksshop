<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Footer extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->library('cart');
		$this->load->model('cart_model');
		$this->load->model('product_model');
		$this->load->library('form_validation');

	}
	public function index()
	{
		$data['cms_footer']=$this->contact->get_info_footer();
		$data['title']="Contact Us Page";
		$this->load->model('category_model','cm');
		$data['category']=$this->cm->get_category_page();
		if(is_array($data['category']))
		{
			foreach($data['category'] as $value)
			{
				$productside[$value->category_id]=$this->cm->product_list($value->category_id);
			}
		}
		else
		{
			$productside=array();
		}
		$data['productside']=$productside;
		$data['category_p']=$this->cm->get_category();
		$data['title']="Welcome To Website";
		$data['product']=$this->product_model->get_product_page();
		$data['product1']=$this->product_model->get_product_page1();
		$data['product2']=$this->product_model->get_product_page2();
		$data['banner']=$this->product_model->get_banner_page();
		$this->load->model('news_model','pm');
		$data['news']=$this->pm->get_news();
		
		$data['page']="pages/index";
		$this->load->view('template/content',$data);
	}
	public function logout()
	{
			$name=$this->session->userdata('username');
			$res=$this->cart_model->Customer_id($name);
			$i=1;
			foreach ($this->cart->contents() as $items)
			{
				$res=$this->cart_model->Customer_id($name);
				$this->session->set_userdata('customer_id',$res->customer_id);	
				$data=array
				(
					'product_id'=>$items['id'],
					'customer_id'=>$res->customer_id,
					'customer_name'=>$this->session->userdata('username'),
					'quantity'=>$items['qty'],
					'product_price'=>$items['price'],
					'product_name'=>$items['name'],
					'product_desc'=>$items['desc'],
					'img'=>$items['img'],
					'total'=>$items['subtotal']
				);
				$this->cart_model->insert_cart($data);
				$i++;	
			}
			$this->cart->destroy();
			//$this->session->unset_userdata($address_array);
			$this->session->unset_userdata('username');
			$this->session->unset_userdata('customer_id');
			$this->session->unset_userdata('order_no');
			$this->session->unset_userdata('count');
			$this->session->unset_userdata('c_email');
			$this->session->unset_userdata('fname');
			$this->session->unset_userdata('lname');
			$this->session->unset_userdata('d_charg');
			$this->session->unset_userdata('grndtotal');
			$this->session->unset_userdata('is_logged_in');
			redirect('home');
	}
	
}
?>