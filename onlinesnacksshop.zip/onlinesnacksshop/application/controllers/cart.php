<?php
class Cart extends CI_Controller 
{
	public function __construct()
	{
		parent::__construct();
		$this->load->library('cart');
		$this->load->model('product_model');
		$this->load->model('cart_model');
		$this->load->model('news_model','pm');
		$this->load->model('category_model','cm');
		$this->load->model('wishlist_model');
		
		
		//$this->load->library('cart');
		
		
	}
	public function index()
	{
		//$this->load->library('cart');
		//$this->load->model('contact_model','contact');
		$data['category']=$this->cm->get_category_page();
		$data['cms_footer']=$this->cm->get_info_footer();
		
		if(is_array($data['category']))
		{
			foreach($data['category'] as $value)
			{
				$productside[$value->category_id]=$this->cm->product_list($value->category_id);
			}
		}
		else
		{
			$productside=array();
		}
		$data['productside']=$productside;
		//$data['products']=$products;
		
		$data['title']="Cart";
		$data['news']=$this->pm->get_news_page();
		$data['page'] = 'pages/product_summary';
		$this->load->view('template/content',$data);
		
	}

	
	public function add($id=FALSE)
	{
		//$res = $this->product_model->view_pro($id);
		$insert_room = array(
		'id' => $this->input->post('product_id'),
		'name' =>$this->input->post('product_title'),
		'desc'=>$this->input->post('product_desc'),
		'price' => $this->input->post('product_price'),
		'img'=>$this->input->post('product_img'),
		'qty' => $this->input->post('qty')
		);		
		
		$this->cart->insert($insert_room);
		
		if($this->input->post('cartbtn'))
		{
			
			$p_id=$this->input->post('product_id');
			
			$this->wishlist_model->delete_wishlist_addproduct($p_id);
		}
		
		
		//$this->session->set_userdata('add','peroduct add');
		//$data['res'] = $this->product_model->view_pro($id);
		//$this->page('pages/product_summary',$data);
		redirect('cart');
	} 
	function remove($rowid) 
	{
		if ($rowid=="all")
		{
			$this->input->cookie($arr);
			delete_cookie($arr);
			$this->cart->destroy();
		}
		else
		{
			$data = array(
				'rowid'   => $rowid,
				'qty'     => 0
			);

			$this->cart->update($data);
		}
		
		redirect('cart');
	}	
	public function update_cart()
	{	
		
		$this->form_validation->set_rules('qty','qty', 'maxlength="3" size="1" style="text-align: right" required|is_natural_no_zero');
		if ($this->form_validation->run() == FALSE)
		{
			$this->session->set_userdata('err','Quantity must checked');
			redirect('cart');
		}
		else
		{
			foreach($_POST['cart'] as $id => $cart)
			{			
				$price = $cart['price'];
				$amount = $price * $cart['qty'];
				$this->cart_model->update_cart($cart['rowid'],$cart['qty'], $price, $amount);
				$this->session->set_userdata('msg','Quantity update');
			}
			
		}
		redirect('cart');
	}
	function empty_cart()
		{
			$this->input->cookie($arr);
			delete_cookie($arr);
			$this->cart->destroy();
			redirect('cart'); 
		}
		function complete()
		{
			$this->cart->destroy();
			redirect('cart');
		}
	
}
