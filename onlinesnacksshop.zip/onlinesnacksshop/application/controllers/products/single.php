<?php

class Single extends CI_Controller
{
	public function __construct()
   {
      parent::__construct();
      $this->load->model('product/single_model','sm');
   }
	public function view($id=FALSE)
	{
		if($id)
		{
			$data['products'] = $this->sm->retrieve_products($id); 
			$data['product_image']=$this->sm->get_product_photos($id);
			if(empty($data['products']))
			{
				redirect('pagenotfound');
			}
			$this->load->model('category_model','cm');
			$data['category']=$this->cm->get_category_page();
			//$data['category_nm']=$this->cm->get_category_name($id);
			$data['content'] = 'pages/single';
			$data['title']='Single';
			$this->load->view('templates/header', $data);
			$this->load->view('templates/menu', $data);
			$this->load->view('pages/single', $data);
			$this->load->view('templates/footer', $data);
		}
		else
		{
			redirect('pagenotfound');
		}
	}
}
?>