<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class product_view extends CI_Controller 
{
	public function __construct()
	{
		parent::__construct();
		$this->load->model('product/product_view_model','pm');
		
		$this->load->helper('date');
		$this->load->library('form_validation');

    
   }
	public function view($id=FALSE)
	{
		if($id)
		{
			$data['product_item'] = $this->pm->get_product($id);
			
			$data['title'] = "Products";
			if (empty($data['product_item']))
			{
				redirect('pagenotfound');
			}
			$this->load->model('category_model','cm');
			$this->load->model('product_view_model','pm');
			$this->load->model('product/product_model');
			//$data['product']=$this->product_model->get_product_page();
			$data['product_new']=$this->product_model->get_new_product();
			
			$data['category']=$this->cm->get_category_page();
			$data['category_nm']=$this->pm->get_category_name($id);
			$data['page']='pages/mens';
			$this->load->view('templates/content',$data);  
		}
		else
		{
			redirect('pagenotfound');
		}
		
	}
}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */