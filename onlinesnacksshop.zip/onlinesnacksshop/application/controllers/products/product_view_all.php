<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class product_view_all extends CI_Controller 
{
	public function __construct()
	{
		parent::__construct();
		$this->load->model('product/product_view_model','pm');
		
		$this->load->helper('date');
		$this->load->library('form_validation');
	
	
	}
	public function index()
	{
		$this->load->model('category_model','cm');
		$data['category']=$this->cm->get_category_page();
		
		$this->load->model('product/product_model');
		$data['product']=$this->product_model->get_product_all();
		$data['product_new']=$this->product_model->get_new_product();
		
		$data['title']='Products';
		$data['page']='pages/product_view_all';
		$this->load->view('templates/content',$data);  
		
	}
	public function view_product()
	{
		$this->load->model('product/product_model');
		$data['num_rows']=$this->pm->get_product_row();
		$this->load->library('pagination');
		$config['base_url'] = site_url().'/product/product_view_all/view_product/';
		$config['total_rows'] = $data['num_rows'];
		$config['per_page'] = $data['per_page']= 3;
		$config['num_links'] = 3;
		$config['uri_segment'] = 3;
		$config['full_tag_open'] = '<p>';
		$config['full_tag_close'] = '</p>';
		$config['cur_tag_open'] = '<a><b><u>';
		$config['cur_tag_close'] = '</u></b></a>';
		$this->pagination->initialize($config);
		$data['product']=$this->pm->get_product_page($config['per_page'], $this->uri->segment(3));
		$data['link']=$this->pagination->create_links();
		$data['title']="";
		$data['page']='pages/product_view_all';
		$this->load->view('templates/content',$data);
	}
}
?>