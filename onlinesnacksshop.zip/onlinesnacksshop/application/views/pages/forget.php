<!-- Header End====================================================================== -->
<div id="mainBody">
	<div class="container">
	<div class="row">
<!-- Sidebar ================================================== -->
	<?php $this->load->view('template/sidebar') ?>
<!-- Sidebar end=============================================== -->
	<div class="span9">
    <ul class="breadcrumb">
		<li><a href="index.html">Home</a> <span class="divider">/</span></li>
		<li class="active">Forget Password</li>
    </ul>
	<h3> Forget Password</h3>
        <?php if($this->session->userdata('err')){
	  ?>
	 <div class="alert alert-block alert-error fade in">
		<button type="button" class="close" data-dismiss="alert">×</button>
		<strong>
      <?php 
			echo $this->session->userdata('err');
			$this->session->unset_userdata('err');
			?>
		
        
        </strong>
	 </div>
	 <?php }?>	
	<hr class="soft"/>
	
	<div class="row">
	
		<div class="span1"> &nbsp;</div>
		<div class="span4" style="margin-left:150px;">
			<div class="well">
			<h5>Forget Password?</h5>
			<form class="loginFrm" method="post" action="<?php echo site_url('forget/forgetpwd'); ?>">
			  <div class="control-group">
				
				<div class="controls">
				   <input type="email"  id="input_email"   name="email" placeholder="Email" class="span3" required/>
                   
				</div>
			  </div>
			
			  <div class="control-group">
				<div class="controls">
				  <button type="submit" class="btn">Reset</button>
                <?php echo anchor('login','Back To Login'); ?>

				</div>
                 
			  </div>
			</form>
		</div>
		</div>
	</div>	
	
</div>
</div></div>
</div>
<!-- MainBody End ============================= -->
<!-- Footer ================================================================== -->
