<script>
function cheakvalue()
{
	
	var data=parseInt(document.getElementById('qty').value);
	if(data < 0)
	{
		window.location = "cart/remove";
		alert('quantity must Checked!!!');
	}
}
</script>
<!-- Header End====================================================================== -->
<div id="mainBody">
	<div class="container">
	<div class="row">
<!-- Sidebar ================================================== -->
	<?php $this->load->view('template/sidebar') ?>
<!-- Sidebar end=============================================== -->
	<div class="span9">
    <ul class="breadcrumb">
		<li><a href="index.html">Home</a> <span class="divider">/</span></li>
		<li class="active"> SHOPPING CART</li>
    </ul>
	<h3>  SHOPPING CART [ <small>
    <?php
	$c=0; 
	if ($cart = $this->cart->contents())
	{	
		foreach ($cart as $item):
			$c++;
		 endforeach; 
		 $this->session->set_userdata('count',$c);
		echo $c;
	}
	
	?>
    
    
    Item(s) </small>]<a href="products" class="btn btn-large pull-right"><i class="icon-arrow-left"></i> Continue Shopping </a></h3>	
	<hr class="soft"/>
    
    <?php if($this->session->userdata('g_t')){
	  ?>
	<div class="alert alert-info fade in">
		<button type="button" class="close" data-dismiss="alert">×</button>
		<strong>
      <?php 
			echo $this->session->userdata('g_t');
			$this->session->unset_userdata('g_t');
			?>
		
        
        </strong>
	 </div>
	 <?php }?>
	<!--<table class="table table-bordered">
		<tr><th> I AM ALREADY REGISTERED  </th></tr>
		 <tr> 
		 <td>
			<form class="form-horizontal">
				<div class="control-group">
				  <label class="control-label" for="inputUsername">Username</label>
				  <div class="controls">
					<input type="text" id="inputUsername" placeholder="Username">
				  </div>
				</div>
				<div class="control-group">
				  <label class="control-label" for="inputPassword1">Password</label>
				  <div class="controls">
					<input type="password" id="inputPassword1" placeholder="Password">
				  </div>
				</div>
				<div class="control-group">
				  <div class="controls">
					<button type="submit" class="btn">Sign in</button> OR <a href="register.html" class="btn">Register Now!</a>
				  </div>
				</div>
				<div class="control-group">
					<div class="controls">
					  <a href="forgetpass.html" style="text-decoration:underline">Forgot password ?</a>
					</div>
				</div>
			</form>
		  </td>
		  </tr>
	</table>-->
	<?php 
	if ($cart = $this->cart->contents())
	{	
	
	?>		
	<table class="table table-bordered">
              <thead>
                <tr>
                <th>Serial No.</th>
                	<th>Product Title</th>
                  <th>Product</th>
                  
                  <th>Quantity/Update</th>
				  <th>Price</th>
                  <th>Discount</th>
                 
                  <th>Total</th>
				</tr>
              </thead>
 			   <tbody>
                           <?php
		echo form_open('cart/update_cart');
		$grand=0; $grand_total = 0; $i = 1;
		$cnt=0;
		$this->session->set_userdata('d_charg',50);
		foreach ($cart as $item)
		{
			$cnt=$cnt+1;
			echo form_hidden('cart['. $item['id'] .'][id]', $item['id']);
			echo form_hidden('cart['. $item['id'] .'][rowid]', $item['rowid']);
			echo form_hidden('cart['. $item['id'] .'][name]', $item['name']);
			echo form_hidden('cart['. $item['id'] .'][price]', $item['price']);
			echo form_hidden('cart['. $item['id'] .'][qty]', $item['qty']);
			
		?>
           
                <tr>
                <td><?php echo $cnt; ?></td>
                <td><?php echo $item['name']; ?></td>
                  <td> <img width="60" src="
				  
				  <?php if(file_exists("./uploads/product_image/thumbs/".$item['img'] ))
				{?>
				 <?php echo base_url("./uploads/product_image/thumbs/").'/'.$item['img'] ?>
				<?php 
				}
				else
				{
					?>
					 <?php echo base_url("images/comingsoon.jpg")?>
					<?php 
				
				}
				?>"
				   alt="<?php echo $item['img']; ?>"/></td>
                 
				  <td>
					<div class="input-append">
                    <input class="span1" type="number"  name="<?php echo 'cart['. $item['id'] .'][qty]'?>" style="max-width:34px" value="<?php echo $item['qty']?>" placeholder="1" id="qty" size="16"  min="1" >
                    <button class="btn btn-danger" type="button" onClick="window.location='<?php echo site_url('cart/remove/'.$item['rowid'])?>'"><i class="icon-remove icon-white"></i></button>				</div>
				  </td>
                  <td>Rs.<?php echo $item['price'].'.00'; ?></td>
                  <td></td>
                  
                  <td>Rs.
					<?php echo $item['subtotal'].'.00'; ?>
                  </td>
                </tr>
                <?php $grand_total = $grand_total + $item['subtotal'];
				$d_charge=$this->session->userdata('d_charg');
				if($grand_total<1000)
				{
					$grand=$grand_total+$d_charge;
				}
				else
				{
					$grand=$grand_total;
				}
				
				
				$this->session->set_userdata('gtotal',$grand);
				?>
                
				<?php }
				
				 ?>
                <tr>
                  <td colspan="6" style="text-align:right">Total Price:	</td>
                  <td>Rs.<?php 
				  echo number_format($grand_total,2);
				  $this->session->set_userdata('grnd_total',$grand);
				  $grndtotal=number_format($grand,2);
				  
				  $this->session->set_userdata('grndtotal',$grndtotal);
				  
				   ?></td>
                </tr>
				 <tr>
                  <td colspan="6" style="text-align:right">Total Discount:	</td>
                  <td> </td>
                </tr>
                <tr>
                  <td colspan="6" style="text-align:right">Delivery Charge:	</td>
                  <td>
                  
                  <?php 
					if($grand_total<1000)
					{
						echo $d_charge.'.00';
					}
					else
					{
						echo "00.00";
					}
				?>
                  </td>
                </tr>
                 
				 <tr>
                  <td colspan="6" style="text-align:right"><strong>TOTAL ( Rs.<?php echo  number_format($grand,2)?> - __ + __) =</strong></td>
                  <td class="label label-important" style="display:block"> <strong>Rs. <?php echo  number_format($grand,2)?> </strong></td>
                </tr>
				</tbody>
            </table><?php 
	$cart = $this->cart->contents();
	if(empty($cart))
	{
		
	}
	else
	{?>
		<a href="<?php echo site_url('products');?>" class="btn btn-large"><i class="icon-arrow-left"></i> Continue Shopping </a>
		<?php 
		if($this->session->userdata('is_logged_in'))
		{ ?>
			<?php if($grand_total>500) 
            {?>
            
            <a href="<?php echo site_url('step/checkout');?>" class="btn btn-large pull-right">Next <i class="icon-arrow-right"></i></a>
            <?php }
			else
			{ $this->session->set_userdata('g_t','Buy Products More Then 500 Rs.');?>
            <a href="<?php echo site_url('cart');?>" class="btn btn-large pull-right">Next <i class="icon-arrow-right"></i></a>
            <?php } ?>
			
	<?php } 
		else
		{?>
			<a href="<?php echo site_url('login');?>" class="btn btn-large pull-right">Next <i class="icon-arrow-right"></i></a>
		<?php } 
		}?>
	
			<?php
            echo form_submit('cartupdate','Update','id="update" class="btn btn-large pull-right"');?>
            <?php 
			$arr=array(
			'id'=>'cart['. $item['id'] .'][id]', $item['id'],
			'row_id'=>'cart['. $item['id'] .'][rowid]', $item['rowid'],
			'name'=>'cart['. $item['id'] .'][name]', $item['name'],
			'price'=>'cart['. $item['id'] .'][price]', $item['price'],
			'qty'=>'cart['. $item['id'] .'][qty]', $item['qty'],
			);
			$this->input->set_cookie($arr);?>
            <?php }else
			{
			?>
            <div class="alert alert-block alert-error fade in">
            <button type="button" class="close" data-dismiss="alert">×</button>
            <strong>
          <?php 
		  $this->session->unset_userdata('count');
			$this->session->unset_userdata('grndtotal');
			echo "Your Shopping Cart is Empty!!!";
			
			?>
                </strong>
             </div>
            
            <?php
            }
			?>
</div>
</div></div>
</div>

<!-- MainBody End ============================= -->
