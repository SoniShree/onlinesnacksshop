﻿<div id="carouselBlk">
	<div id="myCarousel" class="carousel slide">
		<div class="carousel-inner">
		  <div class="item active">
		  <div class="container">
			<a href="<?php echo base_url(); ?>"><img style="width:1680px;height:430px;"  src="<?php echo base_url() ?>uploads/banner_image/1/default_banner.jpg" /></a>
			<div class="carousel-caption">
				 
				</div>
		  </div>
		  </div>
            <?php 
			if($banner)
			{
				?>
          <?php foreach($banner as $p) {?>   
		  <div class="item">
		  <div class="container">
			<img  style="width:1680px;height:430px;"  src="
			<?php if(file_exists("./uploads/banner_image/".$p['banner_img']))
				{?>
				 <?php echo base_url("./uploads/banner_image/").'/'.$p['banner_img'] ?>
				<?php 
				}
				else
				{
					?>
					 <?php echo base_url("images/comingsoon.jpg")?>
					<?php 
				
				}
				?>
			" alt=""/>
				<div class="carousel-caption">
				
				</div>
		  </div>
		  </div>
          <?php } } ?>
          
		</div>
		<a class="left carousel-control" href="#myCarousel" data-slide="prev">&lsaquo;</a>
		<a class="right carousel-control" href="#myCarousel" data-slide="next">&rsaquo;</a>
	  </div> 
</div>
<div id="mainBody">
	<div class="container">
	<div class="row">
<!-- Sidebar ================================================== -->

	<?php $this->load->view('template/sidebar') ?>
<!-- Sidebar end=============================================== -->
		<div class="span9">		
			<div class="well well-small">
			<h4>Featured Products <small class="pull-right"> Featured products</small></h4>
			<div class="row-fluid">
			<div id="featured" class="carousel slide">
			<div class="carousel-inner">
            <div class="item active">
			  <ul class="thumbnails">
				    <?php 
			if($product)
			{
				?>
          <?php foreach($product as $p) {?> 
				<li class="span3">
				  <div class="thumbnail">
				  <i class="tag"></i>
                   <a href="<?php echo site_url('products/products_detail/'.$p['product_id'].'/'.$p['category_id']);?>"><img src="
					<?php if(file_exists("./uploads/product_image/thumbs/".$p['product_img']))
					{?>
					 <?php echo base_url("./uploads/product_image/thumbs/").'/'.$p['product_img'] ?>
					<?php 
					}
					else
					{
						?>
						 <?php echo base_url("images/comingsoon.jpg")?>
						<?php 
					
					}
					?>"
					 alt="<?php echo $p['product_img']; ?>" style="height:200px;"></a>
					
					<div class="caption">
					  <h5><?php echo $p['product_title'] ?></h5>
					  <h4><a class="btn" href="<?php echo site_url('products/products_detail/'.$p['product_id'].'/'.$p['category_id']);?>"><i class="icon-zoom-in"></i>VIEW</a> <span class="pull-right">Rs.&nbsp;<?php echo $p['product_price'] ?></span></h4>
					</div>
				  </div>
				</li>
                <?php } } ?>
				
			  </ul>
			  </div>
			   <div class="item">
			  <ul class="thumbnails">
				    <?php 
			if($product1)
			{
				?>
          <?php foreach($product1 as $p) {?> 
				<li class="span3">
				  <div class="thumbnail">
				  <i class="tag"></i>
                    <a href="<?php echo site_url('products/products_detail/'.$p['product_id'].'/'.$p['category_id']);?>"><img src="
					<?php if(file_exists("./uploads/product_image/thumbs/".$p['product_img']))
					{?>
					 <?php echo base_url("./uploads/product_image/thumbs/").'/'.$p['product_img'] ?>
					<?php 
					}
					else
					{
						?>
						 <?php echo base_url("images/comingsoon.jpg")?>
						<?php 
					
					}
					?>"
					 style="height:200px;"></a>
					
					<div class="caption">
					  <h5><?php echo $p['product_title'] ?></h5>
					  <h4><a class="btn" href="<?php echo site_url('products/products_detail/'.$p['product_id'].'/'.$p['category_id']);?>"><i class="icon-zoom-in"></i>VIEW</a> <span class="pull-right">Rs.&nbsp;<?php echo $p['product_price'] ?></span></h4>
					</div>
				  </div>
				</li>
                <?php } } ?>
				
			  </ul>
			  </div>
			  </div>
			  <a class="left carousel-control" href="#featured" data-slide="prev">‹</a>
			  <a class="right carousel-control" href="#featured" data-slide="next">›</a>
			  </div>
			  </div>
		</div>
		<h4>Latest Products </h4>
			  <ul class="thumbnails">
           <?php 
			if($product2)
			{
				?>
          <?php foreach($product2 as $p) {?> 
				<li class="span3">
				  <div class="thumbnail">
				  <i class="tag"></i>
                    <a href="<?php echo site_url('products/products_detail/'.$p['product_id'].'/'.$p['category_id']);?>"><img src="
					<?php if(file_exists("./uploads/product_image/thumbs/".$p['product_img']))
					{?>
					 <?php echo base_url("./uploads/product_image/thumbs/").'/'.$p['product_img'] ?>
					<?php 
					}
					else
					{
						?>
						 <?php echo base_url("images/comingsoon.jpg")?>
						<?php 
					
					}
					?>"
					 style="height:200px;"></a>
					
					<div class="caption">
					  <h5><?php echo $p['product_title'] ?></h5>
					  <h4><a class="btn" href="<?php echo site_url('products/products_detail/'.$p['product_id'].'/'.$p['category_id']);?>"><i class="icon-zoom-in"></i>VIEW</a> <span class="pull-right">Rs.&nbsp;<?php echo $p['product_price'] ?></span></h4>
					</div>
				  </div>
				</li>
                <?php } } ?>
				
			  </ul>
			  </div>
              
              
				
			 	

		</div>
		</div>
	</div>

