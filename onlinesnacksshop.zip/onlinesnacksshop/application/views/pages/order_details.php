<div id="mainBody">
  <div class="container">
    <div class="row"> 
      <!-- Sidebar ================================================== -->
      <?php $this->load->view('template/sidebar') ?>
      <!-- Sidebar end=============================================== -->
      <div class="span9">
        <ul class="breadcrumb">
          <li><a href="<?php echo site_url('');?> ?>">Home</a> <span class="divider">/</span></li>
          <li >Change Profile</li>
          <li class="active">Order Status</li>
        </ul>
               <?php if($this->session->userdata('complete')){
	  ?>
        	<div class="alert alert-info fade in" style="float:right;height:10px;text-align:inherit;line-height: 10px !important;">
		<button type="button" class="close" data-dismiss="alert">×</button>
		<strong>
		 <?php 
			echo $this->session->userdata('complete');
			$this->session->unset_userdata('complete');
			?>
        </strong>	
	 </div>
      <?php }?>

        <h3>Check Your Order Status </h3>
        <table class="table table-bordered">
			<tbody>
				 <tr>
                  <td> 
				<?php
		echo form_open('profile/order_info','class="form-horizontal"');?>
				<div class="control-group">
				<label class="control-label" style="width:220px;text-align:left;"><strong>Enter Your Order Number:- </strong> </label>
				<div class="controls">
				<input type="text" name="order_no" value="<?php echo $this->input->post('order_no'); ?>" class="input-medium" placeholder="ORDER NUMBER" style="height:30px;">&nbsp;&nbsp;&nbsp;
				<button type="submit" class="btn" style="background:#36F;color:#FFF;width:170px;height:40px;"> Check Status </button>
				</div>
				</div>
				</form>
				</td>
                </tr>
                <tr>
                <td>
                <?php
				if($this->session->userdata('cancel_odr'))
				{
					?>
					
					 <div class="alert alert-block alert-error fade in">
					<button type="button" class="close" data-dismiss="alert">×</button>
					<strong>
				  <?php 
					echo $this->session->userdata('cancel_odr');
					$this->session->unset_userdata('cancel_odr');
					?>
		
        
                </strong>
             </div>
				<?php }
				if(isset($o_details))
				{
					foreach($o_details as $o_details)
					{
						if($this->session->userdata('cancel_odr'))
						{
							echo $this->session->userdata('cancel_odr');
							
						}
						else
						{?>
							<table>
                            <tr>
                            <td><strong>Your Notes >></strong>
						<?php echo '<strong style="color:#69F">Your Order Has been&nbsp;&nbsp;&nbsp;'.$o_details->status.'&nbsp;&nbsp;&nbsp;It Will Be Deliverd On Your Shipping Address In 3-4 Commercial Days... &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Thank You</strong><br><br><br>'. form_open('profile/pdf','class="form-horizontal" target="_blank"');
						$cus_id=$this->input->post('c_id');
						echo form_hidden('order_number', $o_details->order_number);
						echo form_hidden('customer_id', $cus_id);
					?></td>
                    <tr>
                    <td>
						<strong>You Can Generte your Bill From Click Here.</strong><input type="submit" class="btn" value="Create Bill PDF" style="background:#C60;color:#FFF;" />
                    </form>
                        </td>
                        </td>
                        <tr>
                        <td>
						<?php echo form_open('profile/cancel_order','class="form-horizontal"');
						$cus_id=$this->input->post('c_id');
						echo form_hidden('order_number', $o_details->order_number);
						echo form_hidden('customer_id', $cus_id);
						?>
                        
                        <strong>If You Want To Cancel Your Order Please Click Here</strong>
                        <input type="submit" class="btn" value="Cancel My Order" style="background:#C60;color:#FFF;" onclick="return confirm('Are You Sure..? You Want To Cancel Your Order..')"/>
                        
                        </form>
                        </td></tr>
                        </table>
					<?php }
					}
				}
				else
				{
					echo "";
				}
				if($this->session->userdata('ord_id'))
				{
					?>
					
					 <div class="alert alert-block alert-error fade in">
					<button type="button" class="close" data-dismiss="alert">×</button>
					<strong>
				  <?php 
					echo $this->session->userdata('ord_id');
					$this->session->unset_userdata('ord_id');
					?>
		
        
                </strong>
             </div>
				<?php }
				?>
                
                
                </td>
                </tr>
				
			</tbody>
			</table>

		<?php 
		if(!empty($o_info))
		{?>
        	<h3><strong>Order No:-&nbsp;<?php echo $o_details->order_number;?></strong></h3>
            <table class="table table-bordered">
              <thead>
                <tr>
                <th>Serial No.</th>
                <th>Customer Name</th>
                  <th>Product Name</th>
                  <th>Product Image</th>
                  <th>Quantity(In KG)</th>
                  <th>Order Date&Time</th>
				  <th>Price(Per KG)</th>
                  <th>Total</th>
				</tr>
              </thead>
 			   <tbody>
       <?php
		$grand_total = 0; $i = 1;
		$cnt=0;
		foreach ($o_info as $o_info)
		{
			$cnt=$cnt+1;
		?>
           
                <tr>
                <td><?php echo $cnt; ?></td>
                <td><?php echo $o_info->customer_name; ?></td>
                  
                  <td><?php echo $o_info->product_name; ?></td>
                  <td align="center"> <img style="width:60px;height:50px;"  src="
				  
				  <?php if(file_exists("./uploads/product_image/thumbs/".$o_info->img  ))
					{?>
					 <?php echo base_url("./uploads/product_image/thumbs/").'/'.$o_info->img ?>
					<?php 
					}
					else
					{
						?>
						 <?php echo base_url("images/comingsoon.jpg")?>
						<?php 
					
					}
					?>
				  " alt="<?php echo $o_info->img; ?>"/></td>
				  <td>
					<div class="input-append">
                    <label class="span1" style="max-width:34px"><?php echo $o_info->quantity?></label>
                   	</div>
				  </td>
                  <td><?php echo $o_details->ordered_on; ?></td>
                  <td>Rs.<?php echo $o_info->product_price; ?></td>
                  <td>Rs.
					<?php echo $o_info->total; ?>
                  </td>
                </tr>
                <?php $grand_total = $grand_total + $o_info->total;?>
				<?php } ?>
                <tr>
                  <td colspan="7" style="text-align:right">Total Price:	</td>
                  <td>Rs.<?php echo number_format($grand_total,2) ?></td>
                </tr>
                <tr>
                  <td colspan="7" style="text-align:right">Delivery Charge:	</td>
                  <td>Rs.<?php echo $o_details->shipping ?></td>
                </tr>
				 <tr>
                  <td colspan="7" style="text-align:right"><strong>TOTAL</strong></td>
                  <td class="label label-important" style="display:block"> <strong>Rs. <?php echo  number_format($o_details->g_total,2)?> </strong></td>
                </tr>
				</tbody>
            </table>
            <?php
		}
		else
		{
		}?>
            <div class="control-group">
            </div>
      </div>
    </div>
  </div>
</div>
<!-- MainBody End ============================= --> 
