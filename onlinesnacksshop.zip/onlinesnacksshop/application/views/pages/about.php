
<!-- Header End====================================================================== -->
<div id="mainBody">
	<div class="container">
	<div class="row">
    <?php $this->load->view('template/sidebar') ?>
<!-- Sidebar ================================================== -->
	
<!-- Sidebar end=============================================== -->
	<div class="span9">
    <ul class="breadcrumb">
		<li><a href="index.html">Home</a> <span class="divider">/</span></li>
		<li class="active">About Us </li>
    </ul>
	<h3>About Us</h3>	
	<hr class="soft"/>

<?php if($cms){ foreach($cms as $about) { ?>
	
    <?php echo $about->content; ?>

<?php } }?>

</div>
</div></div>
</div>