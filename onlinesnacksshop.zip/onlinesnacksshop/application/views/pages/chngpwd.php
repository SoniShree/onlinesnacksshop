﻿<div id="mainBody">
  <div class="container">
    <div class="row"> 
      <!-- Sidebar ================================================== -->
      <?php $this->load->view('template/sidebar') ?>
      <!-- Sidebar end=============================================== -->
      <div class="span9">
        <ul class="breadcrumb">
          <li><a href="<?php echo site_url('');?>">Home</a> <span class="divider">/</span></li>
          <li class="active">Change Password</li>
        </ul>
        <h3> Change Password</h3>
        <div class="well"> 
  <?php if($this->session->userdata('cpwd')){
	  ?>
	<div class="alert alert-info fade in">
		<button type="button" class="close" data-dismiss="alert">×</button>
		<strong>
      <?php 
			echo $this->session->userdata('cpwd');
			$this->session->unset_userdata('cpwd');
			?>
		
        
        </strong>
	 </div>
	 <?php }?>
      <?php if($this->session->userdata('err1pwd')){
	  ?>
	<div class="alert alert-info fade in">
		<button type="button" class="close" data-dismiss="alert">×</button>
		<strong>
      <?php 
			echo $this->session->userdata('err1pwd');
			$this->session->unset_userdata('err1pwd');
			?>
		
        
        </strong>
	 </div>
	 <?php }?>
               <!--
	<div class="alert fade in">
		<button type="button" class="close" data-dismiss="alert">×</button>
		<strong>Lorem Ipsum is simply dummy</strong> text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s
	 </div>
	 <div class="alert alert-block alert-error fade in">
		<button type="button" class="close" data-dismiss="alert">×</button>
		<strong>Lorem Ipsum is simply</strong> dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s
	 </div> -->
        	<?php echo form_open('profile/chngpwd','class="form-horizontal"'); ?>
            <?php echo form_hidden('customer_id',$customer_profile->customer_id); ?>
            <h4>Your Personal Information&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <p align="right" class="btn btn-mini btn-primary"><?php echo anchor('profile','Change Profile'); ?></p></h4>
            
            
            <br />
            <span style="color:#0C0">
            
            </span>
                        <div class="control-group">
              <label class="control-label" for="input_email">Current Password:- </label>
              <div class="controls">
                <input type="password" name="cpassword"  placeholder="Current Password" required="required">
                   <span style="color:red"><?php echo form_error('cpassword'); ?></span>
               </div>
            </div>
            <div class="control-group">
              <label class="control-label" for="inputFname1">New Password:- </label>
              <div class="controls">
                <input type="password" name="npassword"   placeholder="New Password" required="required">
                <span style="color:red"><?php echo form_error('npassword'); ?></span> </div>
            </div>
            <div class="control-group">
              <label class="control-label" for="inputLnam">Confirm Password:- </label>
              <div class="controls">
                <input type="password" name="cnpassword"  required="required" placeholder="Confirm Password">
                <span style="color:red"><?php echo form_error('cnpassword'); ?></span> </div>
            </div>
            
            
            <div class="control-group">
              <div class="controls">
                <input class="btn btn-large btn-success" type="submit" value="Change" />
              </div>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- MainBody End ============================= --> 
