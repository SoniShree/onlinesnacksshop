<!-- Header End====================================================================== -->
<div id="mainBody">
	<div class="container">
	<div class="row">
<!-- Sidebar ================================================== -->
	<?php $this->load->view('template/sidebar') ?>
<!-- Sidebar end=============================================== -->
	<div class="span9">
    <ul class="breadcrumb">
    <li><a href="<?php echo site_url('');?>">Home</a> <span class="divider">/</span></li>
    <li><a href="<?php echo site_url('single_news/view_news');?>">News</a> <span class="divider">/</span></li>
    <li class="active">Single News</li>
    </ul>	
	<div class="row">	  
			<div id="gallery" class="span3">
            <a href="<?php echo base_url("./uploads/news_image/thumbs/").'/'.$news_item->news_img ?>" >
				<a href="<?php echo base_url("./uploads/news_image/thumbs/").'/'.$news_item->news_img ?>"><img class="a" id="img1" src="
				
				<?php if(file_exists("./uploads/news_image/thumbs/".$news_item->news_img ))
					{?>
					 <?php echo base_url("./uploads/news_image/thumbs/").'/'.$news_item->news_img  ?>
					<?php 
					}
					else
					{
						?>
						 <?php echo base_url("images/comingsoon.jpg")?>
						<?php 
					
					}
					?>"
				
				alt="<?php echo $news_item->news_img; ?>" width="500" /></a>
            </a>
			<div id="differentview" class="moreOptopm carousel slide">
                <div class="carousel-inner">
                   <?php 
					/*<div class="item active">
                   if($product_image)
					{
					foreach ($product_image as $product_image)
		 			{ ?>
                   <a href="<?php echo base_url('./uploads/product_image/thumbs/'.$product_image->product_id.'/thumbs').'/'.$product_image->long_name; ?>"> <img src="<?php echo base_url('./uploads/product_image/thumbs/'.$product_image->product_id.'/thumbs').'/'.$product_image->long_name; ?>" height="50px;" width="55px;" ></a>
                   <?php  } 
				   
					
					}
                  
                  </div>*/?>
                  
                </div>
              <!--  
			  <a class="left carousel-control" href="#myCarousel" data-slide="prev">‹</a>
              <a class="right carousel-control" href="#myCarousel" data-slide="next">›</a> 
			  -->
              </div>
			  <div style="width:750px;"><p>
				 <h3><?php echo ucfirst($news_item->news_title); ?></h3>
				
				</p>
                </div>
			 <div class="btn-toolbar" >
			  <div class="btn-group">
				
			  </div>
			</div>
            
			</div>
            <br /><br />
            
			<div class="span6">
            				<hr class="soft clr"/>
				<h4><?php echo ucfirst($news_item->news_desc); ?></h4>

				
				
				<br class="clr"/>
			<a href="#" name="detail"></a>
			<hr class="soft"/>
			</div>
			
			

	</div>
</div>
</div> </div>
</div>
<!-- MainBody End ============================= -->
