﻿<div id="mainBody">
  <div class="container">
    <div class="row"> 
      <!-- Sidebar ================================================== -->
      <?php $this->load->view('template/sidebar') ?>
      <!-- Sidebar end=============================================== -->
      <div class="span9">
        <ul class="breadcrumb">
          <li><a href="<?php echo site_url('');?> ?>">Home</a> <span class="divider">/</span></li>
          <li class="active">Change Profile</li>
        </ul>
        <h3> Change Profile</h3>
        <div class="well"> 
  <?php if($this->session->userdata('update')){
	  ?>
	<div class="alert alert-info fade in">
		<button type="button" class="close" data-dismiss="alert">×</button>
		<strong>
      <?php 
			echo $this->session->userdata('update');
			$this->session->unset_userdata('update');
			?>
		
        
        </strong>
	 </div>
	 <?php }?>
               <!--
	<div class="alert fade in">
		<button type="button" class="close" data-dismiss="alert">×</button>
		<strong>Lorem Ipsum is simply dummy</strong> text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s
	 </div>
	 <div class="alert alert-block alert-error fade in">
		<button type="button" class="close" data-dismiss="alert">×</button>
		<strong>Lorem Ipsum is simply</strong> dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s
	 </div> -->
        	<?php echo form_open('profile/chngprofile','class="form-horizontal"'); ?>
            <?php echo form_hidden('customer_id',$customer_profile->customer_id); ?>
            <?php echo validation_errors() ?>
            <h4>Your Personal Information&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <p align="right" class="btn btn-mini btn-primary"><?php echo anchor('profile/pwdform','Change Password','style="color:#fff;"'); ?></p>
            
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<p align="right" class="btn btn-mini btn-primary"><?php echo anchor('profile/order_details','My Oreder Status','style="color:#fff;"'); ?></p></h4>
            <br />
            <span style="color:#0C0">
            
            </span>
                        <div class="control-group">
              <label class="control-label" for="input_email">Username:- </label>
              <div class="controls">
                <input type="text" name="txtusernm" value="<?php echo $customer_profile->customer_username; ?>" disabled="disabled"  id="input_email" placeholder="Username" required="required">
               </div>
            </div>
            <div class="control-group">
              <label class="control-label" for="inputFname1">First name:- </label>
              <div class="controls">
                <input type="text" name="fname"  id="inputFname1" value="<?php echo $customer_profile->customer_fname; ?>" placeholder="First Name" required="required">
                <span style="color:red"><?php echo form_error('fname'); ?></span> </div>
            </div>
            <div class="control-group">
              <label class="control-label" for="inputLnam">Last name:- </label>
              <div class="controls">
                <input type="text" name="lname" id="inputLnam" value="<?php echo $customer_profile->customer_lname; ?>" required="required" placeholder="Last Name">
                <span style="color:red"><?php echo form_error('lname'); ?></span> </div>
            </div>

            <div class="control-group">
              <label class="control-label" for="input_email">Email:- </label>
              <div class="controls">
                <input type="text" id="input_email" disabled="disabled" value="<?php echo $customer_profile->customer_email; ?>" name="txtemail" placeholder="Email" required="required">
			 </div>
            </div>
            <div class="control-group">
              <label class="control-label" for="inputLname">Mobile No:- </label>
              <div class="controls">
                <input type="text" id="inputLname" disabled="disabled" value="<?php echo $customer_profile->customer_mobile; ?>" name="txtmobile" placeholder="Mobile No" required="required" />
            </div>
            </div>
            <div class="control-group">
              <label class="control-label" for="address">Address:-</label>
              <div class="controls">
                <textarea  name="address" id="aditionalInfo" cols="26" rows="3" placeholder="Address"  required="required"><?php echo $customer_profile->customer_address; ?></textarea>
                <span style="color:red"><?php echo form_error('address'); ?></span> </div>
            </div>
            
            <div class="control-group">
              <div class="controls">
                <input class="btn btn-large btn-success" type="submit" value="Change" />
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- MainBody End ============================= --> 
