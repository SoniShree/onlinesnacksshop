<div id="mainBody">
	<div class="container">
	<div class="row">
<!-- Sidebar ================================================== -->
	<?php $this->load->view('template/sidebar') ?>
<!-- Sidebar end=============================================== -->
	<div class="span9">
    <ul class="breadcrumb">
		<li><a href="<?php echo site_url('');?>">Home</a> <span class="divider">/</span></li>
		<li class="active">Categories</li>
    </ul>
	<h3>Our Categories<small class="pull-right">
    <?php 
	$cnt=0;
	if($categories)
	{
		foreach($categories as $cn)
		{
			$cnt++;
		}
		echo $cnt;
		?>
        Categories are available </small></h3>	
        <?php
	}
	else
	{
		?>
        
    No Categories are available </small></h3>	
    <?php } ?>
	
	<hr class="soft"/>
	
	  
<div id="myTab" class="pull-right">
 <a href="#listView" data-toggle="tab"><span class="btn btn-large"><i class="icon-list"></i></span></a>
 <a href="#blockView" data-toggle="tab"><span class="btn btn-large btn-primary"><i class="icon-th-large"></i></span></a><br><br><br>
</div>
<br class="clr"/>
<div class="tab-content">
	<div class="tab-pane" id="listView">
    <?php 
	if($categories)
	{
	foreach($categories as $c) {?>
		<div class="row">	  
			<div class="span2">
				<img src="
				<?php
				if(file_exists("./uploads/category_image/thumbs/".$c->category_img))
				{?>
				 <?php echo base_url("./uploads/category_image/thumbs/").'/'.$c->category_img ?>
				<?php 
				}
				else
				{
					?>
					 <?php echo base_url("images/comingsoon.jpg")?>
					<?php 
				
				}
				?>
				" height="200px;" width="200px;"/>
			</div>
            
			<div class="span4">
	
                <h3><?php echo $c->category_title ?> </h3>
				<hr class="soft"/>
				<h5><?php echo $c->category_title ?> </h5>
				<p>
				<?php echo substr($c->category_desc,0,40);echo "...";?>
				</p>
				<br class="clr"/>
			</div>
			<div class="span3 alignR">
			<form class="form-horizontal qtyFrm">
			
			<br/>
			
           			
                    
			 
			 <h4 style="text-align:center"><a class="btn" href="<?php echo site_url('categories/view_products/'.$c->category_id) ?>">View More products</a></h4> 
			
				</form>
			</div>
		</div>
		<hr class="soft"/>
       <?php  }} ?>
		
	</div>

	<div class="tab-pane  active" id="blockView" >
		<ul class="thumbnails">
        <?php 
		if($categories)
		{
		foreach($categories as $c) {?>
			<li class="span3">
			  <div class="thumbnail" >
				<a href="<?php echo site_url('categories/view_products/'.$c->category_id) ?>" ><img src="
			<?php if(file_exists("./uploads/category_image/thumbs/".$c->category_img))
				{?>
				 <?php echo base_url("./uploads/category_image/thumbs/").'/'.$c->category_img ?>
				<?php 
				}
				else
				{
					?>
					 <?php echo base_url("images/comingsoon.jpg")?>
					<?php 
				
				}
				?>
				"style="height:200px;width:220px;" /></a>
				<div class="caption">
				  <h5><?php echo $c->category_title ?></h5>
				  <p> 
					<?php echo substr($c->category_desc,0,15); echo "..."; ?>
				  </p>
					
                    		<h4 style="text-align:center"><a class="btn" href="<?php echo site_url('categories/view_products/'.$c->category_id) ?>">View More products</a></h4> 
                    
				</div>
			  </div>
			</li>
            <?php }} ?>
			
		  </ul>
	<hr class="soft"/>
	</div>
</div>

	<!--<a href="compair.html" class="btn btn-large pull-right">Compair Product</a>-->
	<div class="pagination">
    
			<ul>
          	
			
			</ul>
			</div>
			<br class="clr"/>
</div>
</div>
</div>
</div>
<!-- MainBody End ============================= -->
