<div id="mainBody">
<div class="container">
	<hr class="soften">
	<h1>Visit us</h1>
	<hr class="soften"/>	
    	<div class="row">
	<div class="span12" style="width:700px;">
    <iframe src="https://www.google.com/maps/embed?pb=!1m24!1m8!1m3!1d1860.3503536542391!2d72.96148847845326!3d21.16430583948116!3m2!1i1024!2i768!4f13.1!4m13!1i0!3e6!4m4!1s0x0%3A0x4e344c526158fce4!3m2!1d21.164382999999997!2d72.961589!4m5!1s0x3be05b33a7fbb8e1%3A0x4e344c526158fce4!2sKadodara+Cross+Road%2C+NH8%2C+Kadodara%2C+Gujarat+394327!3m2!1d21.164382999999997!2d72.961589!5e0!3m2!1sen!2sin!4v1430633196954" width="700" height="415" frameborder="0" style="border:0"></iframe>
	</div>
	

		<div class="span4">
		<h4>Email Us</h4>
        <span style="color:#0C0">
        <?php if($this->session->userdata('contact_add')){
			echo $this->session->userdata('contact_add');
			$this->session->unset_userdata('contact_add');
			
		}?>
        
        </span>
        <span>&nbsp;</span>
		<br />
		<form class="form-horizontal" method="post" action="<?php echo site_url('contact/contact'); ?>">
        <fieldset>
          <div class="control-group">
           
              <input type="text" name="txtfnm" placeholder="First Name" class="input-xlarge" required="required"/>
              <span style="color:red"><?php echo form_error('txtfnm'); ?></span>
           
          </div>
          <div class="control-group">
           
              <input type="text" name="txtlnm" placeholder="Last Name" class="input-xlarge" required="required"/>
              <span style="color:red"><?php echo form_error('txtlnm'); ?></span>
           
          </div>
		   <div class="control-group">
            
              <input type="text" placeholder="Email" name="txtemail" class="input-xlarge" required="required"/>
              <span style="color:red"><?php echo form_error('txtemail'); ?></span>
           
          </div>
		   <div class="control-group">
           
              <input type="text" placeholder="Mobile No" name="txtmobile" class="input-xlarge" required="required"/>
              <span style="color:red"><?php echo form_error('txtmobile'); ?></span>
          
          </div>
          <div class="control-group">
              <textarea rows="3" id="textarea" name="txtmsg" class="input-xlarge" required="required"></textarea>
              <span style="color:red"><?php echo form_error('txtmsg'); ?></span>
           
          </div>

            <button class="btn btn-large" type="submit">Send Messages</button>

        </fieldset>
      </form>
		</div>
	</div>
    	<div class="row">
		<div class="span4">
		<h4>Contact Details</h4>
        <?php if($cms){ foreach($cms as $contact) { ?>
    		<?php echo $contact->content; ?>
	<?php } }?>		
		</div>
			
</div>
</div>
<!-- MainBody End ============================= -->
	