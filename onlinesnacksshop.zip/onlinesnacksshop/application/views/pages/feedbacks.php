<div id="mainBody">
	<div class="container">
	<div class="row">
	<?php $this->load->view('template/sidebar') ?>

	<div class="span9">
    <ul class="breadcrumb">
		<li><a href="index.html">Home</a> <span class="divider">/</span></li>
		<li class="active">Registration</li>
    </ul>
	<h3> FeedBacks </h3>	
	
		
				<?php foreach($feedback as $feed) { ?>
    <div class="well">
        <div class="control-group">
		
        	<div class="controls">
            <div style="float:left;padding-right:10px;" >
          
            <img src="<?php echo base_url('images/feed.png'); ?>" height="70" width="70" />
          
            </div>
            <div style="word-wrap:break-word" >
            
                    <br /><p><b>Name : </b><?php echo $feed->contact_fname;?> <?php echo $feed->contact_lname; ?></p>
            <br />
                     <p> <b>Comment :</b>
                    <?php echo $feed->contact_message; ?></p>
            
            </div>
            
                    
              
             </div>
         </div>

</div>                   <?php } ?>
            
		

</div>
</div>
</div>
</div>

<!-- MainBody End ============================= -->
