<!-- Header End====================================================================== -->
<div id="mainBody">
	<div class="container">
	<div class="row">
<!-- Sidebar ================================================== -->
	<?php $this->load->view('template/sidebar') ?>
<!-- Sidebar end=============================================== -->
	<div class="span9">
    <ul class="breadcrumb">
    <li><a href="<?php echo site_url('');?>">Home</a> <span class="divider">/</span></li>
    <li><a href="<?php echo site_url('products');?>">Products</a> <span class="divider">/</span></li>
    <li class="active">Product Details</li>
    </ul>	
	<div class="row">	  
			<div id="gallery" class="span3">
            <a href="<?php echo base_url("./uploads/product_image/thumbs/").'/'.$products->product_img ?>">
				<a href="<?php echo base_url("./uploads/product_image/thumbs/").'/'.$products->product_img ?>">
                <img class="a" id="img1" src="
				
				<?php if(file_exists("./uploads/product_image/thumbs/".$products->product_img))
				{?>
				 <?php echo base_url("./uploads/product_image/thumbs/").'/'.$products->product_img ?>
				<?php 
				}
				else
				{
					?>
					 <?php echo base_url("images/comingsoon.jpg")?>
					<?php 
				
				}
				?>
				" alt="<?php echo $products->product_img; ?>" width="500" /></a>
            </a>
			<div id="differentview" class="moreOptopm carousel slide">
                <div class="carousel-inner">
                  <div class="item active">
                    <?php 
					if($product_image)
					{
					foreach ($product_image as $product_image)
		 			{ ?>
                   <a href="<?php echo base_url('./uploads/product_image/thumbs/'.$product_image->product_id.'/thumbs').'/'.$product_image->long_name; ?>"> <img src="
				   
                   <?php if(file_exists('./uploads/product_image/thumbs/'.$product_image->product_id.'/thumbs').'/'.$product_image->long_name)
				{?>
				 <?php echo base_url('./uploads/product_image/thumbs/'.$product_image->product_id.'/thumbs').'/'.$product_image->long_name; ?>
				<?php 
				}
				else
				{
					?>
					 <?php echo base_url("images/comingsoon.jpg")?>
					<?php 
				
				}
				?>
                   
				   " height="55" width="55" ></a>
                   <?php  } 
				   
					
					}?>
                  
                  </div>
                  <div class="item">
                 
                   <a href="themes/images/products/large/f3.jpg" > <img style="width:29%" src="<?php echo base_url(); ?>bootstrap/themes/images/products/large/f3.jpg" alt=""/></a>
                   <a href="themes/images/products/large/f1.jpg"> <img style="width:29%" src="<?php echo base_url(); ?>bootstrap/themes/images/products/large/f1.jpg" alt=""/></a>
                   <a href="themes/images/products/large/f2.jpg"> <img style="width:29%" src="<?php echo base_url(); ?>bootstrap/themes/images/products/large/f2.jpg" alt=""/></a>
                  </div>
                </div>
              
              </div>
			  
			 
			</div>
			<div class="span6">
				<h3><?php echo $products->product_title; ?></h3>
				
				<hr class="soft"/>
				    <?php
					echo form_open('cart/add','class="form-horizontal qtyFrm"');
					?>
				  <div class="control-group">
					<label class="control-label"><span>Rs. <?php echo $products->product_price; ?>/- [Per Kg.]</span></label>
                     <table>
                   <tr><td>
                   <strong>Available in&nbsp;&nbsp;&nbsp;</strong></td>
                   <td>
                   <select class="span2" name="qty" >
                   <!--<option value="0.5">0.5 Kg.</option>-->
                   <option value="1" selected="selected">1 Kg.</option>
                   <option value="2">2 Kg.</option>
                   <option value="5">5 Kg.</option>
                   </select>
                   </td>
                   </tr>
                   </table>
					<div class="controls">
                   <?php
                    echo form_hidden('product_id', $products->product_id);
					echo form_hidden('product_title', $products->product_title);
					echo form_hidden('product_desc', $products->product_desc);
					echo form_hidden('product_price', $products->product_price);
					echo form_hidden('product_img', $products->product_img);
					
					echo form_submit('cartbtn','Add to Cart','class="btn btn-large btn-primary pull-right"');
					?>
                   </div>
				  </div>
                  <?php echo form_close(); ?>				
				<hr class="soft"/>
                 <?php
					echo form_open('wishlist/add'.'/'. $products->product_id);
					
					$p_id=$products->product_id;
					
					
					
					echo form_hidden('customer_id',$this->session->userdata('user'));
					echo form_hidden('product_id', $products->product_id);
					echo form_hidden('product_title', $products->product_title);
					echo form_hidden('product_price', $products->product_price);
					echo form_hidden('product_img', $products->product_img);
					echo form_hidden('qty',1);
					?><p style="float:right;">
                    
					<?php
					
				//	 echo form_submit('action', 'Add to Wishlist','class="btn btn-large btn-success"');
					?>
                    <?php if($this->session->userdata('is_logged_in'))
					{?>
						<button type="submit" onclick="return alert('Product Add In Wishlist');" class="btn btn-large btn-success">Add To Wishlist</button>
				<?php }
					else
					{?>
                    <button type="submit" onclick="return alert('Please Login First Then Add Product In Wishlist..');" class="btn btn-large btn-success">Add To Wishlist</button>
                    <?php }?>
                    </p>
					
					
					<?php
					echo form_close();
					?>
				
				<form class="form-horizontal qtyFrm pull-right">
				  
				</form>
				<hr class="soft clr"/>
				<p>
				<?php echo $products->product_desc; ?>
				
				</p>
				<a class="btn btn-small pull-right" href="#detail">More Details</a>
				<br class="clr"/>
			<a href="#" name="detail"></a>
			<hr class="soft"/>
			</div>
			
			<div class="span9">
            <ul id="productDetail" class="nav nav-tabs">
              <li class="active"><a href="#home" data-toggle="tab">Product Details</a></li>
              <li><a href="#profile" data-toggle="tab">Related Products</a></li>
            </ul>
            <div id="myTabContent" class="tab-content">
              <div class="tab-pane fade active in" id="home">
			  <h4>Product Information</h4>
                <table class="table table-bordered">
				<tbody>
				<tr class="techSpecRow"><th colspan="2">Product Details</th></tr>
				<tr class="techSpecRow"><td class="techSpecTD1">Product Name: </td><td ><?php echo $products->product_title; ?></td></tr>
				<tr class="techSpecRow"><td class="techSpecTD1">Price(/Kg):</td><td ><?php echo $products->product_price ?></td></tr>
				<tr class="techSpecRow"><td class="techSpecTD1">Quantity(In KG):</td><td > <?php echo $products->product_qty; ?></td></tr>
				<tr class="techSpecRow"><td class="techSpecTD1">Product Available in:</td><td>500Gm,1KG,2KG,5KG</td></tr>
				<tr class="techSpecRow"><td class="techSpecTD1">Expiery Date:</td><td >After Packing 6 Month</td></tr>
				</tbody>
				</table>
				
				<!--<br/>
				OND363338
				</p>

				<h4>Editorial Reviews</h4>
				<h5>Manufacturer's Description </h5>
				<p>
				With a generous 18x Fujinon optical zoom lens, the S2950 really packs a punch, especially when matched with its 14 megapixel sensor, large 3.0" LCD screen and 720p HD (30fps) movie capture.
				</p>

				<h5>Electric powered Fujinon 18x zoom lens</h5>
				<p>
				The S2950 sports an impressive 28mm – 504mm* high precision Fujinon optical zoom lens. Simple to operate with an electric powered zoom lever, the huge zoom range means that you can capture all the detail, even when you're at a considerable distance away. You can even operate the zoom during video shooting. Unlike a bulky D-SLR, bridge cameras allow you great versatility of zoom, without the hassle of carrying a bag of lenses.
				</p>
				<h5>Impressive panoramas</h5>
				<p>
				With its easy to use Panoramic shooting mode you can get creative on the S2950, however basic your skills, and rest assured that you will not risk shooting uneven landscapes or shaky horizons. The camera enables you to take three successive shots with a helpful tool which automatically releases the shutter once the images are fully aligned to seamlessly stitch the shots together in-camera. It's so easy and the results are impressive.
				</p>

				<h5>Sharp, clear shots</h5>
				<p>
				Even at the longest zoom settings or in the most challenging of lighting conditions, the S2950 is able to produce crisp, clean results. With its mechanically stabilised 1/2 3", 14 megapixel CCD sensor, and high ISO sensitivity settings, Fujifilm's Dual Image Stabilisation technology combines to reduce the blurring effects of both hand-shake and subject movement to provide superb pictures.
				</p>-->
              </div>
		<div class="tab-pane fade" id="profile">
		<div id="myTab" class="pull-right">
		 <a href="#listView" data-toggle="tab"><span class="btn btn-large"><i class="icon-list"></i></span></a>
		 <a href="#blockView" data-toggle="tab"><span class="btn btn-large btn-primary"><i class="icon-th-large"></i></span></a>
		</div>
		<br class="clr"/>
		<hr class="soft"/>
		<div class="tab-content">
			<div class="tab-pane" id="listView">
            <?php 
			if($category_products)
			{
			foreach($category_products as $c_p) { ?>
				<div class="row">	  
					<div class="span2">
                    <img src="
				   
                   <?php if(file_exists("./uploads/product_image/thumbs/$c_p->product_img"))
				{?>
				 <?php echo base_url("./uploads/product_image/thumbs/").'/'.$c_p->product_img ?>
				<?php 
				}
				else
				{
					?>
					 <?php echo base_url("images/comingsoon.jpg")?>
					<?php 
				
				}
				?>
                   
				   " style="height:200px;width:200px;">

					</div>
					<div class="span4">
						<h3><?php echo $c_p->product_title; ?></h3>				
						<hr class="soft"/>
						
						<p>
						<?php echo $c_p->product_desc; ?>
						</p>
						
						<br class="clr"/>
					</div>
					<div class="span3 alignR">
					<form class="form-horizontal qtyFrm">
					<h3>Rs. <?php echo $c_p->product_price; ?></h3>
					<br/>
					<div class="btn-group">
					 
					  <a  href="<?php echo site_url('products/products_detail/'.$c_p->product_id.'/'.$c_p->category_id);?>" class="btn btn-large"><i class="icon-zoom-in"></i>&nbsp;View</a>
					 </div>
						</form>
					</div>
			</div>
			<hr class="soft"/>
			<?php }
			
			}
			else
			{ ?>
           <h1>No Record found</h1>
            <?php 
			}
			?>
			
			
		</div>
			<div class="tab-pane active" id="blockView">
				<ul class="thumbnails">
               <?php 
			   if($category_products)
			   {
			   foreach($category_products as $c_p) { ?>
					<li class="span3">
					  <div class="thumbnail">
						<a href="<?php echo site_url('products/products_detail/'.$c_p->product_id.'/'.$c_p->category_id);?>" >
                          <img src="
				   
                   <?php if(file_exists("./uploads/product_image/thumbs/$c_p->product_img"))
				{?>
				 <?php echo base_url("./uploads/product_image/thumbs/").'/'.$c_p->product_img ?>
				<?php 
				}
				else
				{
					?>
					 <?php echo base_url("images/comingsoon.jpg")?>
					<?php 
				
				}
				?>
                   
				   " style="height:200px;width:200px;"></a>
						<div class="caption">
						  <h5><?php echo $c_p->product_title; ?></h5>
						  <p> 
							
						  </p>
                          <span class="btn btn-primary" style="float:left">Rs.&nbsp;<?php echo $c_p->product_price; ?> </span>
                     </span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                     <span><a class="btn" href="<?php echo site_url('products/products_detail/'.$c_p->product_id.'/'.$c_p->category_id); ?>"><i class="icon-zoom-in"></i> &nbsp;View</a></span>

						</div>
					  </div>
					</li>
                    <?php  }
			   }
			   else
			   {  ?>
               <h1>No Products Found</h1>
				   <?php
			   }
			  ?>
					
					
					
					
					
				  </ul>
			<hr class="soft"/>
			</div>
		</div>
				<br class="clr">
					 </div>
		</div>
          </div>

	</div>
</div>
</div> </div>
</div>
<!-- MainBody End ============================= -->
