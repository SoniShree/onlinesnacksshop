<!-- Header End====================================================================== -->
<div id="mainBody">
	<div class="container">
	<div class="row">
<!-- Sidebar ================================================== -->
	<?php $this->load->view('template/sidebar') ?>
<!-- Sidebar end=============================================== -->
	<div class="span9">
    <ul class="breadcrumb">
		<li><a href="index.html">Home</a> <span class="divider">/</span></li>
		<li class="active">Login</li>
    </ul>
	<h3> Login</h3>
        <?php if($this->session->userdata('err')){
	  ?>
	 <div class="alert alert-block alert-error fade in">
		<button type="button" class="close" data-dismiss="alert">×</button>
		<strong>
      <?php 
			echo $this->session->userdata('err');
			$this->session->unset_userdata('err');
			?>
		
        
        </strong>
	 </div>
	 <?php }?>
       <?php if($this->session->userdata('email')){
	  ?>
	 <div class="alert alert-block alert-error fade in">
		<button type="button" class="close" data-dismiss="alert">×</button>
		<strong>
      <?php 
			echo $this->session->userdata('email');
			$this->session->unset_userdata('email');
			?>
		
        
        </strong>
	 </div>
	 <?php }?>	
	<hr class="soft"/>
	
	<div class="row">
		<div class="span4">
			<div class="well">
			<h5>CREATE YOUR ACCOUNT</h5><br/>
			New User? Click To Create Account.<br/><br/>
            
            <?php echo anchor('reg','Create Your Account','class="btn block"'); ?>
            
			
		</div>
		</div>
		<div class="span1"> &nbsp;</div>
		<div class="span4">
			<div class="well">
			<h5>ALREADY REGISTERED ?</h5>
			<form class="loginFrm" method="post" action="<?php echo site_url('login/validate_form_page'); ?>">
			  <div class="control-group">
				<label class="control-label" for="inputEmail1">Username</label>
				<div class="controls">
				  <input class="span3" name="username" type="text" id="inputEmail1" placeholder="Username">
                     <span style="color:red">    <?php echo form_error('username'); ?></span>
				</div>
			  </div>
			  <div class="control-group">
				<label class="control-label" for="inputPassword1">Password</label>
				<div class="controls">
				  <input type="password" name="password" class="span3"  id="inputPassword1" placeholder="Password">
                     <span style="color:red">    <?php echo form_error('password'); ?></span>
				</div>
			  </div>
			  <div class="control-group">
				<div class="controls">
				  <button type="submit" class="btn">Sign in</button> <a href="<?php echo site_url('forget'); ?>">Forget password?</a>
				</div>
			  </div>
			</form>
		</div>
		</div>
	</div>	
	
</div>
</div></div>
</div>
<!-- MainBody End ============================= -->
<!-- Footer ================================================================== -->
