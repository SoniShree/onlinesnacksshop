<!-- Header End====================================================================== -->

<div id="mainBody">
	<div class="container">
	<div class="row">
<!-- Sidebar ================================================== -->
	<?php $this->load->view('template/sidebar') ?>
<!-- Sidebar end=============================================== -->
	<div class="span9">
    <ul class="breadcrumb">
		<li><a href="">Home</a> <span class="divider">/</span></li>
        <li><a href="">Cart</a><span class="divider">/</span></li>
		<li class="active"> Checkout</li>
    </ul>
    <h3> Checkout </h3>
	
    
    
	
			<div>
            <table style="float:left">
            <tr>
            <td colspan="2"><a href="<?php echo site_url('step/checkout'); ?>" class="btn btn-large pull-right" style="float:left;"> Change Address </a>	</td>
            </tr>
            <tr>
            <td>First Name:-&nbsp;</td>
            <td><?php echo $this->session->userdata('first_name'); ?></td>
            </tr>
            
            <tr>
            <td>Last Name:-&nbsp;</td>
            <td><?php echo $this->session->userdata('last_name'); ?></td>
            </tr>
            
            <tr>
            <td>Email:-&nbsp;</td>
            <td><?php echo $this->session->userdata('email'); ?></td>
            </tr>
            
            <tr>
            <td>Mobile No.:-&nbsp;</td>
            <td><?php echo $this->session->userdata('mobile'); ?></td>
            </tr>
            
            <tr>
            <td valign="top">Address-1:-&nbsp;</td>
            <td width="200px;"><?php echo $this->session->userdata('address1'); ?></td>
            </tr>
            
            <tr>
            <td valign="top">Address-2:-&nbsp;</td>
            <td width="200px;"><?php echo $this->session->userdata('address2'); ?></td>
            </tr>
            
            <tr>
            <td>City:-&nbsp;</td>
            <td><?php echo $this->session->userdata('city'); ?></td>
            </tr>
            
            <tr>
            <td>City Zipcode:-&nbsp;</td>
            <td><?php echo $this->session->userdata('zipcode'); ?></td>
            </tr>
            <tr>
            <td></td>
            </tr>
            </table>
            
            
            <table style="float:right;">
            <tr>
            <td colspan="2" ><a href="<?php echo site_url('step/checkout/shipping'); ?>" class="btn btn-large pull-right" style="float:left;"> Change Shipping Address </a></td>
            </tr>
            <tr>
            <td>First Name:-&nbsp;</td>
            <td><?php echo $this->session->userdata('ship_firstname'); ?></td>
            </tr>
            
            <tr>
            <td>Last Name:-&nbsp;</td>
            <td><?php echo $this->session->userdata('ship_lastname'); ?></td>
            </tr>
            
            <tr>
            <td>Email:-&nbsp;</td>
            <td><?php echo $this->session->userdata('ship_email'); ?></td>
            </tr>
            
            <tr>
            <td>Mobile No.:-&nbsp;</td>
            <td><?php echo $this->session->userdata('ship_phone'); ?></td>
            </tr>
            
            <tr>
            <td valign="top">Address-1:-&nbsp;</td>
            <td width="200px;"><?php echo $this->session->userdata('ship_address1'); ?></td>
            </tr>
            
            <tr>
            <td valign="top">Address-2:-&nbsp;</td>
            <td width="200px;"><?php echo $this->session->userdata('ship_address2'); ?></td>
            </tr>
            
            <tr>
            <td>City:-&nbsp;</td>
            <td><?php echo $this->session->userdata('ship_city'); ?></td>
            </tr>
            
            <tr>
            <td>City Zipcode:-&nbsp;</td>
            <td><?php echo $this->session->userdata('ship_zip'); ?></td>
            </tr>
            <tr>
            <td></td>
            </tr>
            </table></div>
            
	<p></p><br><br><br><br>
    <?php if ($cart = $this->cart->contents())
	{		
	?>		
	<table class="table table-bordered">
              <thead>
                <tr>
                <th>Serial No.</th>
                	<th>Product Title</th>
                  <th>Product</th>
                  
                  <th>Quantity/Update</th>
				  <th>Price</th>
                  <th>Discount</th>
                 
                  <th>Total</th>
				</tr>
              </thead>
 			   <tbody>
                           <?php
		echo form_open('cart/update_cart');
		$grand=0; $grand_total = 0; $i = 1;
		$cnt=0;
		$this->session->set_userdata('d_charg',50);
		foreach ($cart as $item)
		{
			$cnt=$cnt+1;
			echo form_hidden('cart['. $item['id'] .'][id]', $item['id']);
			echo form_hidden('cart['. $item['id'] .'][rowid]', $item['rowid']);
			echo form_hidden('cart['. $item['id'] .'][name]', $item['name']);
			echo form_hidden('cart['. $item['id'] .'][price]', $item['price']);
			echo form_hidden('cart['. $item['id'] .'][qty]', $item['qty']);
			
		?>
           
                <tr>
                <td><?php echo $cnt; ?></td>
                <td><?php echo $item['name']; ?></td>
                  <td> <img width="60" src="<?php echo base_url('uploads/product_image/thumbs').'/'.$item['img'] ?>" /></td>
                  
				  <td>
					
                    <label><?php echo $item['qty']?></label>
                    
				  </td>
                  <td>Rs.<?php echo $item['price'].'.00'; ?></td>
                  <td></td>
                  
                  <td>Rs.
					<?php echo $item['subtotal'].'.00'; ?>
                  </td>
                </tr>
                <?php $grand_total = $grand_total + $item['subtotal'];
				$d_charge=$this->session->userdata('d_charg');
				if($grand_total<1000)
				{
					$grand=$grand_total+$d_charge;
				}
				else
				{
					$grand=$grand_total;
				}
				
				
				$this->session->set_userdata('gtotal',$grand);
				?>
                
				<?php }
				
				 ?>
                <tr>
                  <td colspan="6" style="text-align:right">Total Price:	</td>
                  <td>Rs.<?php 
				  echo number_format($grand_total,2);
				  $this->session->set_userdata('grnd_total',$grand);
				  $grndtotal=number_format($grand,2);
				  
				  $this->session->set_userdata('grndtotal',$grndtotal);
				  
				   ?></td>
                </tr>
				 <tr>
                  <td colspan="6" style="text-align:right">Total Discount:	</td>
                  <td> </td>
                </tr>
                <tr>
                  <td colspan="6" style="text-align:right">Delivery Charge:	</td>
                  <td>
                  
                  <?php 
					if($grand_total<1000)
					{
						echo $d_charge.'.00';
					}
					else
					{
						echo "00.00";
					}
				?>
                  </td>
                </tr>
                 
				 <tr>
                  <td colspan="6" style="text-align:right"><strong>TOTAL ( Rs.<?php echo  number_format($grand,2)?> - __ + __) =</strong></td>
                  <td class="label label-important" style="display:block"> <strong>Rs. <?php echo  number_format($grand,2)?> </strong></td>
                </tr>
				</tbody>
            </table>
		    <?php 
			$arr=array(
			'id'=>'cart['. $item['id'] .'][id]', $item['id'],
			'row_id'=>'cart['. $item['id'] .'][rowid]', $item['rowid'],
			'name'=>'cart['. $item['id'] .'][name]', $item['name'],
			'price'=>'cart['. $item['id'] .'][price]', $item['price'],
			'qty'=>'cart['. $item['id'] .'][qty]', $item['qty'],
			);
			$this->input->set_cookie($arr);
			}?>
		<a href="<?php echo site_url('step/checkout/add_record') ?>" onclick="return alert('Your Oreder Done Completely   Thank You For Purchase');"  class="btn btn-large pull-right">Submit Order <i class="icon-arrow-right"></i></a>
</div>
</div></div>
</div>

<!-- MainBody End ============================= -->
