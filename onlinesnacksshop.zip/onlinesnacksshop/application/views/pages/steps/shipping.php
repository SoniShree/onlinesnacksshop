
<div id="mainBody">
	<div class="container">
	<div class="row">
<!-- Sidebar ================================================== -->
	<?php $this->load->view('template/sidebar') ?>
<!-- Sidebar end=============================================== -->
	<div class="span9">
    <ul class="breadcrumb">
		<li><a href="#">Home</a> <span class="divider">/</span></li>
        <li><a href="#">Cart</a> <span class="divider">/</span></li>
		<li class="active">Address Info.</li>
    </ul>
	<h3>Shipping Address</h3>	
	<div class="well">
	<!--
	<div class="alert alert-info fade in">
		<button type="button" class="close" data-dismiss="alert">×</button>
		<strong>Lorem Ipsum is simply dummy</strong> text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s
	 </div>
	<div class="alert fade in">
		<button type="button" class="close" data-dismiss="alert">×</button>
		<strong>Lorem Ipsum is simply dummy</strong> text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s
	 </div>
	 <div class="alert alert-block alert-error fade in">
		<button type="button" class="close" data-dismiss="alert">×</button>
		<strong>Lorem Ipsum is simply</strong> dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s
	 </div> -->
	<form class="form-horizontal" method="post" action="<?php echo site_url('step/checkout/ship_address'); ?>" >
		<h4>Your Address Information</h4>
	<br />
     
		<div class="control-group">
			<label class="control-label" for="inputFname1">First name:- <sup style="color:red">*</sup></label>
			<div class="controls">
			  <input type="text" name="shipfnm"  id="inputFname1" value="<?php 
			   if($this->session->userdata('ship_firstname'))
			   {
				   echo $this->session->userdata('ship_firstname');
			   }
			   else
			   {
				   echo $this->input->post('shipfnm');
			   }?>" placeholder="First Name" required>
              <span style="color:red"><?php echo form_error('shipfnm'); ?></span>
			</div>
		 </div>
         
         
		 <div class="control-group">
			<label class="control-label" for="inputLnam">Last name:- <sup style="color:red">*</sup></label>
			<div class="controls">
			  <input type="text" name="shiplnm" id="inputLnam" value="<?php 
			   if($this->session->userdata('ship_lastname'))
			   {
				   echo $this->session->userdata('ship_lastname');
			   }
			   else
			   {
				   echo $this->input->post('shiplnm');
			   }?>" required placeholder="Last Name">
                            <span style="color:red"><?php echo form_error('shiplnm'); ?></span>
			</div>
		 </div>
         
         
		<div class="control-group">
		<label class="control-label" for="input_email">Email:- <sup style="color:red">*</sup></label>
		<div class="controls">
		  <input type="text" id="input_email" value="<?php 
		   if($this->session->userdata('email'))
		   {
			   echo $this->session->userdata('ship_email');
		   }
		   else
		   {
			   echo $this->input->post('shipemail');
		   }?>" name="shipemail" placeholder="Email" required>
                        <span style="color:red"><?php echo form_error('shipemail'); ?></span>
		</div>
	  </div>	  
		  
		
		<div class="control-group">
			<label class="control-label" for="inputLname">Mobile No:- <sup style="color:red">*</sup></label>
			<div class="controls">
			  <input type="text" id="inputLname" value="<?php 
			   if($this->session->userdata('ship_phone'))
			   {
				   echo $this->session->userdata('ship_phone');
			   }
			   else
			   {
				   echo $this->input->post('shipmobile');
			   }?>" name="shipmobile" placeholder="Mobile No" required />
                            <span style="color:red"><?php echo form_error('shipmobile'); ?></span>
			</div>
		</div>	
		
        
        <div class="control-group">
			<label class="control-label" for="address">Address:- <sup style="color:red">*</sup></label>
			<div class="controls">
			  <textarea  name="shipadd" id="aditionalInfo" cols="26" rows="3" placeholder="Address"  required="required"><?php 
			   if($this->session->userdata('ship_address1'))
			   {
				   echo $this->session->userdata('ship_address1');
			   }
			   else
			   {
				   echo $this->input->post('shipadd');
			   }?></textarea>
                            <span style="color:red"><?php echo form_error('shipadd'); ?></span>
			</div>
		</div>
        <div class="control-group">
			<label class="control-label" for="address">Address-2:-</label>
			<div class="controls">
			  <textarea  name="shipadd2" id="aditionalInfo" cols="26" rows="3" placeholder="Address-2" ><?php 
			   if($this->session->userdata('ship_address2'))
			   {
				   echo $this->session->userdata('ship_address2');
			   }
			   else
			   {
				   echo $this->input->post('shipadd2');
			   }?></textarea>
                            <span style="color:red"><?php echo form_error('shipadd2'); ?></span>
			</div>
		</div>
		<div class="control-group">
		<label class="control-label" >City:- <sup style="color:red">*</sup></label>
		<div class="controls">
		  <!--<input type="text"  value="<?php 
		   if($this->session->userdata('ship_city'))
		   {
			   echo $this->session->userdata('ship_city');
		   }
		   else
		   {
			   echo $this->input->post('shipcity');
		   }?>" name="shipcity" placeholder="City" required>-->
           <select name="shipcity">
          <option value="surat">surat</option>
          <option value="vapi">vapi</option>
          <option value="valsad">valsad</option>
          </select>
                        <span style="color:red"><?php echo form_error('shipcity'); ?></span>
		</div>
	  </div>
      <div class="control-group">
		<label class="control-label" for="input_email">Zipcode:- <sup style="color:red">*</sup></label>
		<div class="controls">
		  <input type="text"  value="<?php 
		   if($this->session->userdata('ship_zip'))
		   {
			   echo $this->session->userdata('ship_zip');
		   }
		   else
		   {
			   echo $this->input->post('shipzipcode');
		   }?>" name="shipzipcode" placeholder="Zipcode" required>
                        <span style="color:red"><?php echo form_error('shipzipcode'); ?></span>
		</div>
	  </div>
			<p style="color:red; font-size:15px;" align="right">*&nbsp;Required field	</p>
	
    
    
		<br />
		  
    
	<div class="control-group">
			<div class="controls">
				<input class="btn btn-large btn-success" type="submit" value="Continue" name="shipping"/>
			</div>
		</div>		
	</form>
</div>

</div>
</div>
</div>
</div>
</div>
<!-- MainBody End ============================= -->
