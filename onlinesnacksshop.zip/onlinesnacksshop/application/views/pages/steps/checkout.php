
<div id="mainBody">
	<div class="container">
	<div class="row">

	  <?php $this->load->view('template/sidebar') ?>

	<div class="span9">
    <ul class="breadcrumb">
		<li><a href="#">Home</a> <span class="divider">/</span></li>
        <li><a href="#">Cart</a> <span class="divider">/</span></li>
		<li class="active">Address Info.</li>
    </ul>
	<h3>Billing Address</h3>	
	<div class="well">
	
	<form class="form-horizontal" method="post" action="<?php echo site_url('step/checkout/add_address'); ?>" >
		<h4>Your Address Information</h4>
	<br />
     
		<div class="control-group">
			<label class="control-label" for="inputFname1">First name:- <sup style="color:red">*</sup></label>
			<div class="controls">
			  <input type="text" name="txtfnm"  id="inputFname1" value="<?php 
			  if($this->session->userdata('first_name'))
			  {
			  	echo $this->session->userdata('first_name');
			  }
			  else
			  {
				  echo $this->input->post('txtfnm');
			  }?>" placeholder="First Name" required="required">
              <span style="color:red"><?php echo form_error('txtfnm'); ?></span>
			</div>
		 </div>
         
         
		 <div class="control-group">
			<label class="control-label" for="inputLnam">Last name:- <sup style="color:red">*</sup></label>
			<div class="controls">
			  <input type="text" name="txtlnm" id="inputLnam" value="<?php 
			  if($this->session->userdata('last_name'))
			  {
			  	echo $this->session->userdata('last_name');
			  }
			  else
			  {
				  echo $this->input->post('txtlnm');
			  }?>" required="required" placeholder="Last Name">
                            <span style="color:red"><?php echo form_error('txtlnm'); ?></span>
			</div>
		 </div>
         
         
		<div class="control-group">
		<label class="control-label" for="input_email">Email:- <sup style="color:red">*</sup></label>
		<div class="controls">
		  <input type="text" id="input_email" value="<?php 
		  if($this->session->userdata('email'))
		  {
				echo $this->session->userdata('email'); 
		  }
		  else
		  {
			  	echo $this->input->post('txtemail'); 
		  }?>" name="txtemail" placeholder="Email" required="required">
                        <span style="color:red"><?php echo form_error('txtemail'); ?></span>
		</div>
	  </div>	  
		  
		
		<div class="control-group">
			<label class="control-label" for="inputLname">Mobile No:- <sup style="color:red">*</sup></label>
			<div class="controls">
			  <input type="text" id="inputLname" value="<?php 
			   if($this->session->userdata('mobile'))
			   {
			  		echo $this->session->userdata('mobile');
			   }
			   else
			   {
				   echo $this->input->post('txtmobile');
			   }?>" name="txtmobile" placeholder="Mobile No" required="required" />
                            <span style="color:red"><?php echo form_error('txtmobile'); ?></span>
			</div>
		</div>	
		
        
        <div class="control-group">
			<label class="control-label" for="address">Address:- <sup style="color:red">*</sup></label>
			<div class="controls">
			  <textarea  name="txtadd" id="aditionalInfo" cols="26" rows="3" placeholder="Address"  required="required"><?php 
			   if($this->session->userdata('address1'))
			   {
			  		echo $this->session->userdata('address1');
			   }
			   else
			   {
				   echo $this->input->post('txtadd');
			   }?></textarea>
                            <span style="color:red"><?php echo form_error('txtadd'); ?></span>
			</div>
		</div>
        <div class="control-group">
			<label class="control-label" for="address">Address-2:-</label>
			<div class="controls">
			  <textarea  name="txtadd2" id="aditionalInfo" cols="26" rows="3" placeholder="Address-2"><?php 
			   if($this->session->userdata('address2'))
			   {
			  		echo $this->session->userdata('address2');
			   }
			   else
			   {
				   echo $this->input->post('txtadd2');
			   }?></textarea>
                            <span style="color:red"><?php echo form_error('txtadd2'); ?></span>
			</div>
		</div>
		<div class="control-group">
		<label class="control-label" >City:- <sup style="color:red">*</sup></label>
		<div class="controls">
		  <!--<input type="text"  value="<?php 
		  if($this->session->userdata('city'))
		  {
		  	echo $this->session->userdata('city');
		  }
		  else
		  {
			  echo $this->input->post('txtcity');
		  }
		  ?>" name="txtcity" placeholder="City" required="required">-->
          <select name="txtcity">
          <option value="surat">surat</option>
          <option value="vapi">vapi</option>
          <option value="valsad">valsad</option>
          </select>
                        <span style="color:red"><?php echo form_error('txtcity'); ?></span>
		</div>
	  </div>
      <div class="control-group">
		<label class="control-label" for="input_email">Zipcode:- <sup style="color:red">*</sup></label>
		<div class="controls">
		  <input type="text"  value="<?php 
		  if($this->session->userdata('email'))
		  {
			  echo $this->session->userdata('zipcode');
		  }
		  else
		  {
			  echo $this->input->post('txtzipcode');
		  }?>" name="txtzipcode" placeholder="Zipcode" required="required">
                        <span style="color:red"><?php echo form_error('txtzipcode'); ?></span>
		</div>
	  </div>
			<p style="color:red; font-size:15px;" align="right">*&nbsp;Required field	</p>
	
    <div class="controls">
    <table>
    <tr>
    
    <th>
    
    
    <span><input type="checkbox" name="ship" value="1" checked="checked" > Ship To This Address</span></th>
    </tr>
    </table>
    </div>
    
		<br />
		  
    
	<div class="control-group">
			<div class="controls">
				<input class="btn btn-large btn-success" type="submit" value="Continue" />
			</div>
		</div>		
	</form>
</div>

</div>
</div>
</div>
</div>
</div>
<!-- MainBody End ============================= -->
