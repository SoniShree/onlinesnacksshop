<!-- Header End====================================================================== -->
<div id="mainBody">
	<div class="container">
	<div class="row">
<!-- Sidebar ================================================== -->
	<?php $this->load->view('template/sidebar') ?>
<!-- Sidebar end=============================================== -->
	<div class="span9">
    <ul class="breadcrumb">
		<li><a href="index.html">Home</a> <span class="divider">/</span></li>
		<li class="active">Terms and Conditions</li>
    </ul>
	<h3> Terms and Conditions</h3>	
	<hr class="soft"/>
		<?php foreach($cms as $terms) { ?>
	
    <?php echo $terms->content ?>

<?php } ?>

		
</div>
</div></div>
</div>
<!-- MainBody End ============================= -->
<!-- Footer ================================================================== -->