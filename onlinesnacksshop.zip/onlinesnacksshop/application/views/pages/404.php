
<script>setTimeout("window.location.replace(\'<?php echo base_url('./') ?>')",5000);</script>
<script type = "text/javascript">
/*author Philip M. 2010*/

var timeInSecs;
var ticker;

function startTimer(secs){
timeInSecs = parseInt(secs)-1;
ticker = setInterval("tick()",1000);   // every second
}

function tick() {
var secs = timeInSecs;
if (secs>0) {
timeInSecs--;
}
else {
clearInterval(ticker); // stop counting at zero
// startTimer(60);  // remove forward slashes in front of startTimer to repeat if required
}

document.getElementById("countdown").innerHTML = secs;
}

startTimer(5);  // 60 seconds 

</script>

<!-- Header End====================================================================== -->
<div id="mainBody">
	<div class="container">
	<div class="row">
 	<div class="span9">
    <ul class="breadcrumb">
		<li><a href="index.html">Home</a> <span class="divider">/</span></li>
		<li class="active">404::Page Not Found</li>
    </ul>
	<h3> </h3>	
        <center><span>We're sorry, but the page you were looking for doesn't exist.</span>
    You Will Be Redirected To Home In 
<span id="countdown" style="font-weight: bold;">5</span> Secs.</center>

    <br /><br /><br /><br />
</div>
</div>
</div>

</div>
    </h3>
    
<!-- MainBody End ============================= -->
<!-- Footer ================================================================== -->
	
<!-- Placed at the end of the document so the pages load faster ============================================= -->
	<!--<script src="themes/js/jquery.js" type="text/javascript"></script>
	<script src="themes/js/bootstrap.min.js" type="text/javascript"></script>
	<script src="themes/js/google-code-prettify/prettify.js"></script>
	
	<script src="themes/js/bootshop.js"></script>
    <script src="themes/js/jquery.lightbox-0.5.js"></script>
	
	<!-- Themes switcher section ============================================================================================= -->

<span id="themesBtn"></span>
</body>
</html>