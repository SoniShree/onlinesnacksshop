<div id="mainBody">
	<div class="container">
	<div class="row">
<!-- Sidebar ================================================== -->
	<?php $this->load->view('template/sidebar') ?>
<!-- Sidebar end=============================================== -->
	<div class="span9">
    <ul class="breadcrumb">
		<li><a href="<?php echo site_url('');?>">Home</a> <span class="divider">/</span></li>
		<li class="active">Products Name</li>
    </ul>
	<h3><?php 
	
		echo $cat_name->category_title; 
	?> Products<small class="pull-right"> 
    <?php 
	$cnt=0;
	if($category_product)
	{
		foreach($category_product as $cn)
		{
			$cnt++;
		}
		echo $cnt;
		?>
        products are available </small></h3>	
        <?php
	}
	else
	{
		?>
        
    No products are available </small></h3>	
    <?php } ?>
     
    </small></h3>	
	<hr class="soft"/>
	
	  
<div id="myTab" class="pull-right">
 <a href="#listView" data-toggle="tab"><span class="btn btn-large"><i class="icon-list"></i></span></a>
 <a href="#blockView" data-toggle="tab"><span class="btn btn-large btn-primary"><i class="icon-th-large"></i></span></a>
</div>
<br />
<br class="clr"/>

<div class="tab-content">
	<div class="tab-pane" id="listView">
    <?php 
	if($category_product)
	{
		
	foreach($category_product as $p) {?>
    
		<div class="row">	  
			<div class="span2">
				<img src="
				<?php if(file_exists("./uploads/product_image/thumbs/".$p->product_img))
					{?>
					 <?php echo base_url("./uploads/product_image/thumbs/").'/'.$p->product_img ?>
					<?php 
					}
					else
					{
						?>
						 <?php echo base_url("images/comingsoon.jpg")?>
						<?php 
					
					}
					?>"
				 alt="<?php echo $p->product_img; ?>" height="200px;" width="200px;"/>
			</div>
			<div class="span4">
				<h3><?php echo $p->product_title ?></h3>				
				<hr class="soft"/>
				
				<p>
				<?php echo substr($p->product_desc,0,40);echo "...";?>
				</p>
				<br class="clr"/>
			</div>
			<div class="span3 alignR">
			<form class="form-horizontal qtyFrm">
			<h3><span class="btn btn-primary">Rs.&nbsp;<?php echo $p->product_price; ?></span></h3>
			<br/>
			
          			
                    
			 
			  <a href="<?php echo site_url('products/products_detail/'.$p->product_id.'/'.$p->category_id);?>" class="btn btn-large"><i class="icon-zoom-in"></i>&nbsp;View</a>
			
				</form>
			</div>
		</div>
		<hr class="soft"/>
        <?php } 
		}
		else
		{
			echo '<h3 style="padding-left:100px;">No Products In This category</h3>';
		}
		
		?>
		
	</div>
<br />
	<div class="tab-pane  active" id="blockView" >
		<ul class="thumbnails">
        <?php 
		if($category_product)
		{
			foreach($category_product as $p) {?>
			<li class="span3">
			  <div class="thumbnail" >
				<a href="<?php echo site_url('products/products_detail/'.$p->product_id.'/'.$p->category_id);?>" ><img src="
				<?php if(file_exists("./uploads/product_image/thumbs/".$p->product_img))
					{?>
					 <?php echo base_url("./uploads/product_image/thumbs/").'/'.$p->product_img ?>
					<?php 
					}
					else
					{
						?>
						 <?php echo base_url("images/comingsoon.jpg")?>
						<?php 
					
					}
					?>"
				
				alt="<?php echo $p->product_img; ?>" style="height:200px;width:220px;" /></a>
				<div class="caption">
				  <h5><?php echo $p->product_title ?></h5>
				  <p> 
					<?php echo substr($p->product_desc,0,30); echo "..."; ?>
				  </p>
					 <span class="btn btn-primary">Rs.&nbsp;<?php echo $p->product_price; ?></span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                  <span><a class="btn" href="<?php echo site_url('products/products_detail/'.$p->product_id.'/'.$p->category_id); ?>"><i class="icon-zoom-in"></i> &nbsp;View</a></span>

                   
                    <?php
					echo form_close(); ?>				
                    
				</div>
			  </div>
			</li>
            <?php } 
		}
		else
		{
			echo '<h3 style="padding-left:100px;">No Products</h3>';
		}
		
		?>
			
		  </ul>
	<hr class="soft"/>
	</div>
</div>

	<!--<a href="compair.html" class="btn btn-large pull-right">Compair Product</a>-->
	<div class="pagination">
    
			<ul>
          	
			
			</ul>
			</div>
			<br class="clr"/>
</div>
</div>
</div>
</div>
<!-- MainBody End ============================= -->
