<!-- Header End====================================================================== -->
<div id="mainBody">
	<div class="container">
	<div class="row">
<!-- Sidebar ================================================== -->
	<?php $this->load->view('template/sidebar') ?>
<!-- Sidebar end=============================================== -->
	<div class="span9">
    <ul class="breadcrumb">
		<li><a href="index.html">Home</a> <span class="divider">/</span></li>
        <li>
        <?php if($this->session->userdata('username'))
		 {
			 $msg=ucfirst($this->session->userdata('username'));
			  echo anchor('profile',$msg);;
		 }
		  ?>
        <span class="divider">/</span></li>
		<li class="active"> My Wishlist</li>
    </ul>
	<h3> MY WISHLIST [ <small>
				<?php if($wishlist_item)
				{
					$c=0;
					$m='No';
					foreach ($wishlist_item as $wl)
					{
						$c++;
					}
					$c1=$c;
					if($c1>=1)
					{
						echo $c;
					}
					else
					{
						echo $m;
					}
				}
				?> Item(s) </small>]<a href="<?php echo site_url('products');?>" class="btn btn-large pull-right"><i class="icon-arrow-left"></i> Continue Shopping </a></h3>	
	<hr class="soft"/>
			
	<?php if($this->session->userdata('del')){
	  ?>
	<div class="alert alert-info fade in">
		<button type="button" class="close" data-dismiss="alert">×</button>
		<strong>
      <?php 
			echo $this->session->userdata('del');
			$this->session->unset_userdata('del');
			?>
		
        
        </strong>
	 </div>
	 <?php }?>
	<table class="table table-bordered">
              <thead>
                <tr>
                	<th>Serial No.</th>
                  <th>Product Title</th>
                  <th>Product Image</th>
				  <th>Price</th>
                  <th>Added Date</th>
                  <th>Buy</th>
                  
				</tr>
              </thead>
              <tbody>
              <?php $i=0; ?>
              <?php 
			  if($wishlist_item)
			  {
			  foreach ($wishlist_item as $wl)
			  { $i=$i+1?>
              <?php  echo form_open('cart/add','class="form-horizontal qtyFrm"');?>
                    <?php 
					echo form_hidden('product_id', $wl->product_id);
					echo form_hidden('product_title', $wl->product_title);
					echo form_hidden('product_desc', $wl->product_desc);
					echo form_hidden('product_price', $wl->product_price);
					echo form_hidden('product_img', $wl->product_img);
					echo form_hidden('qty', 1);
					
					?>
                <tr>
                <td><?php echo $i; ?></td>
                <td><?php echo $wl->product_title; ?></td>
                  <td><img src="
				  <?php if(file_exists("./uploads/product_image/thumbs/".$wl->product_img))
				{?>
				 <?php echo base_url("./uploads/product_image/thumbs/").'/'.$wl->product_img ?>
				<?php 
				}
				else
				{
					?>
					 <?php echo base_url("images/comingsoon.jpg")?>
					<?php 
				
				}
				?>
				  " height="50" width="50" /> </td>
                  <td><?php echo $wl->product_price; ?></td>
				  
                  <td><?php echo $wl->created; ?></td>
                  
                  <td>
                 
                   
                  <input type="submit" value="BUY NOW" name="cartbtn" class="btn btn-mini btn-primary" >
                 
                  
                  
                  <a href="<?php echo site_url('wishlist/delete/'.$wl->wishlist_id); ?>" onclick="return confirm('Are You Sure?');"><button class="btn btn-danger" type="button"><i class="icon-remove icon-white"></i></button></a>
                  	</td>
                  
                </tr> <?php echo form_close(); ?>
				<?php } 
				
			    
			  }?>
				
				
               
				
              
              <?php 
			  if($wishlist_namkeen_item)
			  {
			  foreach ($wishlist_namkeen_item as $wl)
			  { $i=$i+1?>
              <?php  echo form_open('cart/add','class="form-horizontal qtyFrm"');?>
                    <?php 
					echo form_hidden('product_id', $wl->namkeen_id);
					echo form_hidden('product_title', $wl->namkeen_title);
					echo form_hidden('product_desc', $wl->namkeen_sort);
					echo form_hidden('product_price', $wl->namkeen_price);
					echo form_hidden('product_img', $wl->namkeen_images);
					echo form_hidden('qty', 1);
					
					?>
                <tr>
                <td><?php echo $i; ?></td>
                <td><?php echo $wl->namkeen_title; ?></td>
                  <td><img src="
				  
				   <?php if(file_exists("./uploads/product_image/thumbs/".$wl->namkeen_images))
				{?>
				 <?php echo base_url("./uploads/product_image/thumbs/").'/'.$wl->namkeen_images ?>
				<?php 
				}
				else
				{
					?>
					 <?php echo base_url("images/comingsoon.jpg")?>
					<?php 
				
				}
				?>
				  " height="50" width="50" /> </td>
                  <td><?php echo $wl->namkeen_price; ?></td>
				  
                  <td><?php echo $wl->created; ?></td>
                  
                  <td>
                 
                   
                  <input type="submit" value="BUY NOW" name="cartbtn" class="btn btn-mini btn-primary" >
                 
                  
                  
                  <a href="<?php echo site_url('wishlist/delete/'.$wl->wishlist_id); ?>" onclick="return confirm('Are You Sure?');"><button class="btn btn-danger" type="button"><i class="icon-remove icon-white"></i></button></a>
                  	</td>
                  
                </tr> <?php echo form_close(); ?>
				<?php } 
				
			    
			  }?>
              
				
				<tr><td colspan="6" style="text-align:center;"><strong><span style="color:#900;"><?php if($i<1){echo "No Records Found";}?></span></strong></td></tr>
               
				</tbody>
            </table>
            
			
					
	
	
</div>
</div></div>
</div>
</div>
<!-- MainBody End ============================= -->
