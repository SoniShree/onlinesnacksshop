﻿<div id="mainBody">
	<div class="container">
	<div class="row">
<!-- Sidebar ================================================== -->
	<?php $this->load->view('template/sidebar') ?>
<!-- Sidebar end=============================================== -->
	<div class="span9">
    <ul class="breadcrumb">
		<li><a href="index.html">Home</a> <span class="divider">/</span></li>
		<li class="active">Registration</li>
    </ul>
	<h3> Registration</h3>	
	<div class="well">
	<!--
	<div class="alert alert-info fade in">
		<button type="button" class="close" data-dismiss="alert">×</button>
		<strong>Lorem Ipsum is simply dummy</strong> text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s
	 </div>
	<div class="alert fade in">
		<button type="button" class="close" data-dismiss="alert">×</button>
		<strong>Lorem Ipsum is simply dummy</strong> text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s
	 </div>
	 <div class="alert alert-block alert-error fade in">
		<button type="button" class="close" data-dismiss="alert">×</button>
		<strong>Lorem Ipsum is simply</strong> dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s
	 </div> -->
	<form class="form-horizontal" method="post" action="<?php echo site_url('reg/signup'); ?>" >
		<h4>Your Personal Information <span style="float:right" ><a href="<?php echo site_url('login'); ?>" style="color:#09F">Already Registed ?</a></span></h4>
	<br />
     <span style="color:#0C0">
        <?php if($this->session->userdata('cust_add')){
			echo $this->session->userdata('cust_add');
			$this->session->unset_userdata('cust_add');
			
		}?>
        
        </span>
		<div class="control-group">
			<label class="control-label" for="inputFname1">First name:- <sup style="color:red">*</sup></label>
			<div class="controls">
			  <input type="text" name="txtfnm"  id="inputFname1" value="<?php echo $this->input->post('txtfnm')?>" placeholder="First Name" required="required">
              <span style="color:red"><?php echo form_error('txtfnm'); ?></span>
			</div>
		 </div>
		 <div class="control-group">
			<label class="control-label" for="inputLnam">Last name:- <sup style="color:red">*</sup></label>
			<div class="controls">
			  <input type="text" name="txtlnm" id="inputLnam" value="<?php echo $this->input->post('txtlnm')?>" required="required" placeholder="Last Name">
                            <span style="color:red"><?php echo form_error('txtlnm'); ?></span>
			</div>
		 </div>
         <div class="control-group">
		<label class="control-label" for="input_email">Username:- <sup style="color:red">*</sup></label>
		<div class="controls">
		  <input type="text" name="txtusernm" value="<?php echo $this->input->post('txtusernm')?>"  id="input_email" placeholder="Username" required="required">
                        <span style="color:red"><?php echo form_error('txtusernm'); ?></span>
		</div>
	  </div>
		<div class="control-group">
		<label class="control-label" for="input_email">Email:- <sup style="color:red">*</sup></label>
		<div class="controls">
		  <input type="text" id="input_email" value="<?php echo $this->input->post('txtemail')?>" name="txtemail" placeholder="Email" required="required">
                        <span style="color:red"><?php echo form_error('txtemail'); ?></span>
		</div>
	  </div>	  
	<div class="control-group">
		<label class="control-label" for="inputPassword1">Password:- <sup style="color:red">*</sup></label>
		<div class="controls">
		  <input type="password"  name="txtpwd"  id="inputPassword1" placeholder="Password" required="required">
                        <span style="color:red"><?php echo form_error('txtpwd'); ?></span>
		</div>
	  </div>	  
		<div class="control-group">
			<label class="control-label" for="inputFname">Confirm Password:- <sup style="color:red">*</sup></label>
			<div class="controls">
			  <input type="password" name="txtcpwd" id="inputFname" placeholder="Confirm Password" required="required">
                            <span style="color:red"><?php echo form_error('txtcpwd'); ?></span>
			</div>
		</div>
		<div class="control-group">
			<label class="control-label" for="inputLname">Mobile No:- <sup style="color:red">*</sup></label>
			<div class="controls">
			  <input type="text" id="inputLname" value="<?php echo $this->input->post('txtmobile')?>" name="txtmobile" placeholder="Mobile No" required="required" />
                            <span style="color:red"><?php echo form_error('txtmobile'); ?></span>
			</div>
		</div>	
		<div class="control-group">
			<label class="control-label" for="address">Address:- <sup style="color:red">*</sup></label>
			<div class="controls">
			  <textarea  name="txtadd" id="aditionalInfo" cols="26" rows="3" placeholder="Address"  required="required"><?php echo $this->input->post('txtadd')?></textarea>
                            <span style="color:red"><?php echo form_error('txtadd'); ?></span>
			</div>
		</div>
		
			<p style="color:red; font-size:15px;" align="right">*&nbsp;Required field	</p>
	
	<div class="control-group">
			<div class="controls">
				<input class="btn btn-large btn-success" type="submit" value="Register" />
			</div>
		</div>		
	</form>
</div>

</div>
</div>
</div>
</div>
<!-- MainBody End ============================= -->
