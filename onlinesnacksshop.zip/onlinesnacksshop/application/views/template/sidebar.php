<!-- Sidebar ================================================== -->
	
    
    <div id="sidebar" class="span3 test">
		<div class="well well-small"><a id="myCart" href="<?php echo site_url('cart'); ?>"><img src="<?php echo base_url() ?>bootstrap/themes/images/ico-cart.png" alt="cart">
		<?php if($this->session->userdata('count'))
		{
			$count=$this->session->userdata('count');
		}
		else
		{
			$count=0;
		} echo $count;?>  Items in your cart  <span class="badge badge-warning pull-right">
		<?php 
		if($this->session->userdata('grndtotal'))
		{
			echo $this->session->userdata('grndtotal');
		}
		else
		{
			echo "0";
		}?></span></a></div>
          <span style="font-size:20px;padding-bottom:5px;padding-top:10px; "><b>Categories</b></span>
          <span style="font-size:14px;padding-bottom:10px;float:right;padding-top:10px;" class="badge badge-warning pull-right"><a href="<?php echo site_url('categories/') ?>" style="color:#FFF">View All Categories</a></b></span>
          <hr />
		<ul id="sideManu" class="nav nav-tabs nav-stacked">
        
       <?php if(!empty($category)){foreach($category as $category) { ?>
                <li class="subMenu"><a> <?php echo ucfirst($category->category_title); ?></a><span style="float:right;margin: -28px 10px -22px -22px;"><a href="<?php echo site_url('categories/view_products/'.$category->category_id) ?>" style="width:30px;"  >All</a></span>
			<ul style="display:none">
            <?php
            	for($i=0;$i<count($productside[$category->category_id]);$i++)
				{
					?>
                    <li><a href="<?php echo site_url('products/products_detail/'.$productside[$category->category_id][$i]->product_id.'/'.$productside[$category->category_id][$i]->category_id); ?>"><i class="icon-chevron-right"></i><?php echo  $productside[$category->category_id][$i]->product_title?></a></li>
                    <?php 

				}
			?>					
			</ul>
			</li>
            <?php } } else { echo ""; }?>
	</ul>	

		

<!-- Sidebar end=============================================== -->
		
         <b><hr style="border:1px solid; padding:0px;" /></b>
         
         

        <?php if(!empty($news))
			{
				?>
                 <span style="font-size:14px;padding-bottom:5px; "><b>Latest News</b></span> 
                 <br />
                <?php
				 foreach($news as $news) {
			
			$desc=$news->news_desc;
			$des=substr($desc,0,20);
			 ?>
           <br /> 
		  <div class="thumbnail">

			<img src="<?php if(file_exists("./uploads/news_image/thumbs/".$news->news_img))
				{?>
				 <?php echo base_url("./uploads/news_image/thumbs/").'/'.$news->news_img ?>
				<?php 
				}
				else
				{
					?>
					 <?php echo base_url("images/comingsoon.jpg")?>
					<?php 
				
				}
				?>
			
			" alt="<?php echo $news->news_img; ?>" style="height:180px;;">
			<div class="caption">
			  <h5><?php echo ucfirst($news->news_title)	; ?></h5>
              <h6><?php echo ucfirst(substr($news->news_desc,0,20));; ?></h6>
				<h4 style="text-align:center"><a class="btn" href="<?php echo site_url('single_news/view/'.$news->news_id); ?>"><i class="icon-zoom-in"></i> Read More</a> </h4>
			</div>
		  </div>
          <?php  }
		  ?>
           <h4 style="text-align:center"><a class="btn" href="<?php echo site_url('single_news/view_news') ?>">View More News</a></h4> 
          <?php
		   }
		   ?>
    </div>
<!-- Sidebar end=============================================== -->