<!-- Footer ================================================================== -->
    <div  id="footerSection">
    
    
    <div class="container">
		<div class="row">
			<div class="span3">
				<h5>ACCOUNT</h5>
               <?php if($this->session->userdata('is_logged_in'))
			   {
				   echo "";
			   }
			   else
			  {
               echo anchor('login','YOUR ACCOUNT'); 
			  }
			   ?>
                
                 <?php echo anchor('about','ABOUT US'); ?>
                 <?php echo anchor('contact','CONTACT'); ?>
				
			 </div>
			<div class="span3">
				<h5>INFORMATION</h5>
                
				<?php if($this->session->userdata('is_logged_in'))
                {
                	echo "";
                }
                else
                {
                 	echo anchor('reg','REGISTRATION');
                }
                ?>
	
			   
				
				
		
				<!--<a href="legal_notice.html">LEGAL NOTICE</a>-->
				<?php echo anchor('terms','TERMS AND CONDITION'); ?>
				<a href="<?php echo site_url('feedback')?>">FEEDBACKS</a>
			 </div>
		<!--	<div class="span3">
				<h5>OUR OFFERS</h5>
				<a href="#">NEW PRODUCTS</a> 
				<a href="#">TOP SELLERS</a>  
				<a href="special_offer.html">SPECIAL OFFERS</a>  
				<a href="#">MANUFACTURERS</a> 
				<a href="#">SUPPLIERS</a> 
			 </div>
			<div id="socialMedia" class="span3 pull-right">
				<h5>SOCIAL MEDIA </h5>
				<a href="#"><img width="60" height="60" src="<?php echo base_url() ?>bootstrap/themes/images/facebook.png" title="facebook" alt="facebook"/></a>
				<a href="#"><img width="60" height="60" src="<?php echo base_url() ?>bootstrap/themes/images/twitter.png" title="twitter" alt="twitter"/></a>
				<a href="#"><img width="60" height="60" src="<?php echo base_url() ?>bootstrap/themes/images/youtube.png" title="youtube" alt="youtube"/></a>
			 </div> -->
             	<div class="span3">
				<h5>NEWS SUBSCRIPTION</h5>
                
			<span  id="subscribe" style="cursor:pointer"> News Subscribe
             <img src="<?php echo base_url() ?>images/subscription.png"  style="float:left;height:70px;width:70px;"></span>
		     	
			 </div>
               <div class="span3 pull-right">
               
				<h5>DEVELOPED BY,</h5>
	 
      <?php if($cms_footer){ foreach($cms_footer as $contact) { ?>
    		<?php echo $contact->content; ?>
	<?php } }?>	
			 </div>
    
        <br /><br />
       
	 </div> <br /><br />
      <p class="pull-left" style="text-align:center;">Copyrigth &copy; <?php echo date('Y') ?> All Rights Reserved</p>
    </div>

	<!-- Container End -->
	</div>
<!-- Placed at the end of the document so the pages load faster ============================================= -->
	<script src="<?php echo base_url() ?>bootstrap/themes/js/jquery.js" type="text/javascript"></script>
	<script src="<?php echo base_url() ?>bootstrap/themes/js/bootstrap.min.js" type="text/javascript"></script>
	<script src="<?php echo base_url() ?>bootstrap/themes/js/google-code-prettify/prettify.js"></script>
	
	<script src="<?php echo base_url() ?>bootstrap/themes/js/bootshop.js"></script>
    <script src="<?php echo base_url() ?>bootstrap/themes/js/jquery.lightbox-0.5.js"></script>
	
	<!-- Themes switcher section ============================================================================================= -->
<div id="secectionBox">
<link rel="stylesheet" href="themes/switch/themeswitch.css" type="text/css" media="screen" />
<script src="<?php echo base_url() ?>bootstrap/themes/switch/theamswitcher.js" type="text/javascript" charset="utf-8"></script>
	
</div>

</body>
</html>