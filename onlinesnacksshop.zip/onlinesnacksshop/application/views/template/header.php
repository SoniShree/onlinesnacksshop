﻿<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <title><?php echo "Onlinesnacksstore >> "; echo $title ?></title>
    <meta name="author" content="">
    <meta name="keywords" content="snacks, Buy snacks, Buy snacks in Surat, Online snacks Store,Online snacks shop,Online snacks Store in surat,Online snacks Shop in surat,good snacks,online snacks, etc">
  <meta name="description" content="Online Snacks Store...">
<!--Less styles -->
   <!-- Other Less css file //different less files has different color scheam
	<link rel="stylesheet/less" type="text/css" href="themes/less/simplex.less">
	<link rel="stylesheet/less" type="text/css" href="themes/less/classified.less">
	<link rel="stylesheet/less" type="text/css" href="themes/less/amelia.less">  MOVE DOWN TO activate
	-->
	<!--<link rel="stylesheet/less" type="text/css" href="themes/less/bootshop.less">
	<script src="themes/js/less.js" type="text/javascript"></script> -->
	
<!-- Bootstrap style --> 

<link href="<?php echo base_url() ?>bootstrap/themes/dist/sweetalert.css" rel="stylesheet" media="screen"/>
<script src="<?php echo base_url() ?>bootstrap/themes/dist/sweetalert-dev.js" type="text/javascript"></script>

    <link id="callCss" rel="stylesheet" href="<?php echo base_url() ?>bootstrap/themes/bootshop/bootstrap.min.css" media="screen"/>
    
    <link href="<?php echo base_url() ?>bootstrap/themes/css/base.css" rel="stylesheet" media="screen"/>
<!-- Bootstrap style responsive -->	
	<link href="<?php echo base_url() ?>bootstrap/themes/css/bootstrap-responsive.min.css" rel="stylesheet"/>
	<link href="<?php echo base_url() ?>bootstrap/themes/css/font-awesome.css" rel="stylesheet" type="text/css">
<!-- Google-code-prettify -->	
	<link href="<?php echo base_url() ?>bootstrap/themes/js/google-code-prettify/prettify.css" rel="stylesheet"/>
<!-- fav and touch icons -->
    <link rel="shortcut icon" href="<?php echo base_url() ?>bootstrap/themes/images/ico/favicon.ico">
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="<?php echo base_url() ?>bootstrap/themes/images/ico/apple-touch-icon-144-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="<?php echo base_url() ?>bootstrap/themes/images/ico/apple-touch-icon-114-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="<?php echo base_url() ?>bootstrap/themes/images/ico/apple-touch-icon-72-precomposed.png">
    <link rel="apple-touch-icon-precomposed" href="<?php echo base_url() ?>bootstrap/themes/images/ico/apple-touch-icon-57-precomposed.png">
    <link rel="stylesheet" href="<?php echo base_url() ?>bootstrap/themes/css/menu_style.css" type="text/css" media="screen">
	<style type="text/css" id="enject"></style>
    <script src="<?php echo base_url() ?>bootstrap/themes/js/jquery.js" type="text/javascript"></script>
    <script type="text/javascript">
$(document).ready(function() 
{
 
  $('#subscribe').click(function() 
  {
	   		swal({
  title: "Newsletter Subscription",
  text: "Enter Your Email-Id:",
  type: "input",
  showCancelButton: true,
  closeOnConfirm: false,
  animation: "slide-from-top",
  inputPlaceholder: "Enter Email Here"
},
function(inputValue){
  if (inputValue === false) return false;
  
  if (inputValue === "") {
    swal.showInputError("You need to write something!");
    return false
  }
  else
  {
	var UrlToPass = 'email='+inputValue;
	//alert(UrlToPass);
	$.ajax({ 
	type : 'POST',
	data : UrlToPass,
	url  : '<?php echo site_url(); ?>/newsletter/regemail',
	success: function(responseText){ 
	//alert(responseText);
		if(responseText == 0){
			swal.showInputError("Email Invalid !");
		}
		else if(responseText == 1){
			swal("Nice!", "You have successfully Subscribed.","success");
		}
		else if(responseText == 2){
			swal.showInputError("You Have Already Subsribed !");
		}
		else if(responseText == 3){
			swal("Nice!", "You have successfully Re-Subscribed.","success");
		}
		else{
			alert('Problem with sql query'+responseText);
		}
	}
	});
  }
  
});
	 	
  } 	);
  
 
} );
</script>
<script language="javascript" type="application/javascript">
$(document).ready(function(){
	$('#username').focus(); 
	$('#log').click(function(){
		document.getElementById('email').value="";
		document.getElementById('password').value="";
		document.getElementById('login_result').innerHTML="";
		$('#loginbox').show();
		$('.login_result').html('');
		$('#forgotbox').hide();
	});
	$('#loginbtn').click(function(){ 
		var email = $('#email'); 
		var password = $('#password'); 
		var login_result = $('.login_result'); 
		login_result.html('loading..');
		if(email.val() == ''){ 
			email.focus();
			login_result.html('<span class="error">Enter the Email</span>');
			return false;
		}
		if(password.val() == ''){ 
			password.focus();
			login_result.html('<span class="error">Enter the password</span>');
			return false;
		}
		if(email.val() != '' && password.val() != ''){ 
			var UrlToPass = 'username='+email.val()+'&password='+password.val();
			$.ajax({ 
			type : 'POST',
			data : UrlToPass,
			url  : '<?php echo site_url(); ?>/login/validate_form',
			success: function(responseText){ 
				if(responseText == 0){
					login_result.html('<span class="error">Email or Password Incorrect!</span>');
				}
				else if(responseText == 1){
					window.location = '<?php echo site_url(); ?>';
				}
				else{
					alert('Problem with sql query'+responseText);
				}
			}
			});
		}
		return false;
	});
});

</script>
  </head>
<body>

<div id="header">
<div class="container">
<div id="welcomeLine" class="row">
	<div class="span6">
    <div class="pull-left">
    <?php 
	if($this->session->userdata('is_logged_in'))
	{
		?>
		   <ul id="nav">
    
      <li><?php if($this->session->userdata('username'))
	 {
		 $msg="Hi,".ucfirst($this->session->userdata('username'))."&nbsp;<small>&#9660;</small>";
		  echo anchor('profile',$msg);;
	 }
	  ?>
      
            <ul style="padding-top:5px;z-index:50000000px;">
          <?php
		  if($this->session->userdata('count'))
		{
			$count=$this->session->userdata('count');
		}
		else
		{
			$count=0;
		}
		   ?>
                <li><a href="<?php echo site_url('profile'); ?>">Manage Profile</a></li>
                <li><a href="<?php echo site_url('cart'); ?>">Cart&nbsp;(<?php echo $count; ?>)</a></li>
                <li><?php echo anchor('wishlist/view_wishlist/'.$this->session->userdata('c_id'),'My Wishlist');?></li>
                <li><a href="<?php echo site_url('profile/order_details'); ?>">Track Order</a></li>
                <li><a href="<?php echo site_url('home/logout'); ?>">Logout</a></li>
            </ul>
            
        </li>
        </ul>
    <?php 
	}
        else
	 {
		 echo "Welcome, User";
	 }
	 ?>
        </div>
        
     </div>
	<div class="span6">
	<div class="pull-right">
		
		
        <?php if($this->session->userdata('is_logged_in'))
		 {?>
			  <span class="btn">
			  <?php echo anchor('wishlist/view_wishlist/'.$this->session->userdata('c_id'),'My Wishlist');?>
			  &nbsp;</span>
		<?php }
		if($this->session->userdata('count'))
		{
			$count=$this->session->userdata('count');
		}
		else
		{
			$count=0;
		}
        ?>
         
        <?php echo anchor('cart','<span class="btn btn-mini btn-primary"><i class="icon-shopping-cart icon-white"></i> [' .$count. '] Itemes in your cart </span>') ?>
		
	</div>
	</div>
</div>
<!-- Navbar ================================================== -->
<div id="logoArea" class="navbar">
<a id="smallScreen" data-target="#topMenu" data-toggle="collapse" class="btn btn-navbar">
	<span class="icon-bar"></span>
	<span class="icon-bar"></span>
	<span class="icon-bar"></span>
</a>
  <div class="navbar-inner">
    <a class="brand" href="<?php echo site_url('home') ?>"><img src="<?php echo base_url() ?>bootstrap/themes/images/logo.gif" alt="Onlinesnacksstore" width="200" style="height:30px;"/></a>
	<ul id="topMenu" class="nav pull-right">
     <li <?php echo $this->uri->segment(1)=='home'?"class='active'":"";?> <?php echo $this->uri->segment(1)==''?"class='active'":"";?>  > <?php echo anchor('home','Home'); ?></li>
     <li <?php echo $this->uri->segment(1)=='products'?"class='active'":"";?>> <?php echo anchor('products','Products'); ?></li>
     <li <?php echo $this->uri->segment(1)=='namkeen'?"class='active'":"";?>> <?php echo anchor('namkeen','Namkeen'); ?></li>
          <li <?php echo $this->uri->segment(1)=='contact'?"class='active'":"";?>> <?php echo anchor('contact','Contact'); ?></li>
           <?php if(!$this->session->userdata('is_logged_in'))
	 		{
				?>
           		<li > <?php echo anchor('reg','<span class="btn btn-large btn-success">Sign Up</span>'); ?></li>
           <?php } ?>
          
     
	 <li class="">
     <?php if($this->session->userdata('is_logged_in'))
	 {
		?><a href="<?php echo site_url('home/logout'); ?>" role="button" style="padding-right:0"><span class="btn btn-large btn-success">Logout</span></a>	 
		<?php
	 }
	 else
	 {
		 ?>
		 	 <a href="#login" role="button" data-toggle="modal" id="log" style="padding-right:0"><span class="btn btn-large btn-success">Login</span></a>
		 <?php
	 }
	 
	  ?>

	<div id="login" class="modal hide fade in" style="top:60%; padding:50px; width:400px; height:250px;" tabindex="-1" role="dialog" aria-labelledby="login" aria-hidden="false" >
    
		  <div class="modal-header">
			<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
			<h3>Login Here...</h3>
		  </div>
		  <div class="modal-body">
          <div id="login_result" class="login_result" style="color:#FF151C; background-color:#FF9799;width:100%;border-radius:5px;text-align:center;margin-bottom:5px;"></div>
			<?php /*?><form class="form-horizontal loginFrm" method="post" action="<?php echo site_url('login/validate_form'); ?>"><?php */?>
			  <div class="control-group">
             
              <?php echo form_input('email',set_value('email'),' id="email" class="form-control" style="width=100%;" placeholder="Username"  required '); ?>								
            
	            
			  </div>
			  <div class="control-group">
              <?php echo form_password('password','','id="password" class="form-control" placeholder="Password" style="width=100%;" required '); ?>
   	            
			  </div>
			  <div class="control-group">
				
			  </div>
			<br>
            <?php   echo form_button('login',"Submit",' id="loginbtn" class="btn btn-success"'); ?>
			<button class="btn" data-dismiss="modal" aria-hidden="true">Close</button>
            <?php /*?></form>	<?php */?>	
		  </div>
	</div>
	</li>
    </ul>
  </div>
</div>
</div>
</div>

<!-- Header End====================================================================== -->